QuestTrip::Application.routes.draw do

  resources :suggested_quests, :only => [:index, :create, :destroy]
  resources :reports

  resources :users, :except => [:new, :destroy] do
    member do
      put :is_blocked
    end

    resources :albums do
      resources :entries, :except => [:index]
    end
    resources :wishlists, :only => [:show] do
      resources :locals, :except => [:index, :show]
    end
    resources :completed_quests, :only => [:index]
  end

  resources :sessions, :only => [:new, :create, :destroy]

  # Routes for quests and all the nested associations
  resources :quests do
    resources :spots, :only => [] do
      resources :challenges, :only => [:show, :destroy]
      resources :visits, :only => [:new, :create, :edit, :update]
      resources :puzzles, :only => [:new, :create, :edit, :update]
      resources :quizzes, :only => [:new, :create, :edit, :update] do
        resources :quiz_options, :only => []
      end
    end

    resources :facebook_posts, :only => [:new, :create]

    resources :topics, :only => [:create, :destroy] do
      resources :comments, :only => [:create, :destroy]
    end

    member do
      post :rate
      put :block
    end
  end

  namespace :api do
    namespace :v1 do
      post 'sessions' => 'sessions#create', :as => 'login'
      post 'quests' => 'quests#process_request', :as => 'spotsByQuest'
      post 'challenges' => 'challenges#get_challenge', :as => 'getChallenge'
      post 'spots' => 'spots#process_request', :as => 'setCompletedSpots'
    end
  end

  root :to => 'static_pages#home'

  match '/rate' => 'rater#create', :as => 'rate'
  get '/sessionUpdate/:id/:quest_id', :to => 'sessions#update'
  match '/signup', :to => 'users#new'
  match '/signin',  :to => 'sessions#new'
  delete '/signout', :to => 'sessions#destroy' #[same as]: match '/signout', :to => 'sessions#destroy', via: :delete

  match '/', :to => 'static_pages#home'
  match '/help', :to => 'static_pages#help'
  match '/about', :to => 'static_pages#about'
end