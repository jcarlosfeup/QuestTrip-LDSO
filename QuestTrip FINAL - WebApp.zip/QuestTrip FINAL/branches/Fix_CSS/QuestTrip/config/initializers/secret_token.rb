# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
QuestTrip::Application.config.secret_token = '875bc5cab13b94d003c05281861822402c46cd2a4b18993e648daf5b6a27f40a7565ad4b6e173f2a9ed76583e8d50b085157449c694a81f9a8bbc54f1f625eca'
