require "spec_helper"

describe "Challenge pages" do

  subject { page }

  describe "authorization" do

    describe "as signed-in users" do

    end

    describe "for non-signed-in users" do
      let(:user) { FactoryGirl.create(:user) }
      before do
        @quest = user.quests.create(description: "quest1")
        @spot = @quest.spots.create(coordinates: "POINT(-100 0)", name: "spot1", sequence_order: 0)
        @challenge = @spot.challenges.create(description: "challenge1")
      end

      describe "in the Challenge controller" do

        describe "visit the new page" do
          before { visit new_challenge_path }
          it { should have_selector("title", text: "Sign in") }
        end

        describe "visit the edit page" do
          before { visit edit_challenge_path(challenge) }
          it { should have_selector("title", text: "Sign in") }
        end
      end
    end
  end

end