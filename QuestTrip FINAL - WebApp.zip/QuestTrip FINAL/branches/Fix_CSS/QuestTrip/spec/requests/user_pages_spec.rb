require 'spec_helper'

describe "User pages" do

  subject { page }

  describe "profile page" do
    let(:user) { FactoryGirl.create(:user) }
    before { visit user_path(user) }

    it { should have_selector("h1", text: user.email) }
    it { should have_selector("title", text: "Profile") }
  end

  describe "signup page" do
    before { visit signup_path }

    it { should have_selector("h1",    text: "Sign up") }
    it { should have_selector("title", text: "Sign up") }
  end

  describe "signup" do
    before { visit signup_path }

    let(:submit) { "Create my account" }

    describe "with invalid information" do
      it "should not create a user" do
        expect { click_button submit }.not_to change(User, :count)
      end
    end

    describe "with valid information" do
      before do
        fill_in "Email", with: "xpto@cenas.pt"
        fill_in "Password", with: "user.password"
        fill_in "Confirmation", with: "user.password"
      end

      it "should create a user" do
        expect { click_button submit }.to change(User, :count).by(1)
      end


      describe "after saving the user" do
        before { click_button submit }
        let(:user) { User.find_by_email("xpto@cenas.pt") }

        it { should have_selector("div.alert.alert-success", text: "Signup completed with success!") }
        it { should have_link("Sign out") }
      end

      describe "followed by signout" do
        before { click_button submit }
        before { click_link "Sign out" }
        it { should have_link("Sign in") }
      end
    end
  end

  describe "edit" do
    let(:user) { FactoryGirl.create(:user) }
    before do
      sign_in user
      visit edit_user_path(user)
    end

    describe "page" do
      it { should have_selector("h1", text: "Edit profile") }
      it { should have_selector("title", text: "QuestTrip | Edit profile") }
      it { should have_link("change", href: "#") }
    end

    describe "with invalid information" do
      before { click_button "Save changes" }
      it { should have_content("error") }
    end

    describe "with valid information" do
      let(:first_name) { "Eduardo" }
      let(:last_name) { "Alves" }

      before do
        fill_in "user_first_name", with: first_name
        fill_in "user_last_name", with: last_name
        fill_in "user_password", with: user.password
        fill_in "user_password_confirmation", with: user.password
        click_button "Save changes"
      end

      it { should have_selector("div.alert.alert-success") }
      it { should have_link("Sign out", href: signout_path) }

      specify { user.reload.first_name.should == first_name }
      specify { user.reload.last_name.should == last_name }
    end
  end

  describe "index" do
    before do
      sign_in FactoryGirl.create(:user)
      FactoryGirl.create(:user, email: "cenas1@teste.pt")
      FactoryGirl.create(:user, email: "cenas2@teste.pt")
      visit users_path
    end

    it { should have_selector("title", text: "QuestTrip | All users") }

    it "should list each user" do
      User.all.each do |user|
        page.should have_selector("li", text: user.email)
      end
    end
  end
end
