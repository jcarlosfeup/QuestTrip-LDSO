require 'spec_helper'

describe "Static Pages" do

  describe "Home Page" do
    it "should have the h1 'Welcome to QuestTrip'" do
      visit root_path
      page.should have_selector('h1', :text => 'Welcome to QuestTrip')
    end

    it "should have the title 'Home'" do
      visit root_path
      page.should have_selector('title', :text => 'QuestTrip | Home')
    end

    describe "with signed-in user" do
      before { sign_in FactoryGirl.create(:user) }

      describe "when visiting the Home Page" do
        it "should not have 'Sign up now!' button" do
          visit root_path
          page.should_not have_link("Sign up now!", href: signup_path)
        end
      end
    end
  end

  describe "Help Page" do
    it "should have the h1 'Help'" do
      visit help_path
      page.should have_selector('h1', :text => 'Help')
    end

    it "should have the title 'Help'" do
      visit help_path
      page.should have_selector('title', :text => 'QuestTrip | Help')
    end
  end

  describe "About Page" do
    it "should have the h1 'About'" do
      visit about_path
      page.should have_selector('h1', :text => 'About Us')
    end

    it "should have the title 'About Us'" do
      visit about_path
      page.should have_selector('title', :text => 'QuestTrip | About Us')
    end
  end

end
