require 'spec_helper'

describe ChallengesControllerOld do

end
