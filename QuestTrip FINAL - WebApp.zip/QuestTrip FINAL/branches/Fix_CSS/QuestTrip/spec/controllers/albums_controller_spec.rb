require 'spec_helper'

describe AlbumsController do

end
