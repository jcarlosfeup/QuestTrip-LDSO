require 'spec_helper'

describe QuizOptionsController do

end
