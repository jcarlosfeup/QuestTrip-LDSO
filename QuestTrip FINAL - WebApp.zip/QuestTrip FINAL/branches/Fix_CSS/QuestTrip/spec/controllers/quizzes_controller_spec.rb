require 'spec_helper'

describe QuizzesController do

end
