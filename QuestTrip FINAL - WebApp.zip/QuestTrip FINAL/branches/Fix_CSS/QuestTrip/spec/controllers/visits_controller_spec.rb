require 'spec_helper'

describe VisitsController do

end
