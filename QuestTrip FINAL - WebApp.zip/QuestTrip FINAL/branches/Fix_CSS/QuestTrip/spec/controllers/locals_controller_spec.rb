require 'spec_helper'

describe LocalsController do

end
