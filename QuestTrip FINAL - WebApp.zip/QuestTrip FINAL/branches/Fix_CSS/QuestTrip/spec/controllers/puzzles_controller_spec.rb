require 'spec_helper'

describe PuzzlesController do

end
