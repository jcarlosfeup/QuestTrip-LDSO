require 'spec_helper'

describe CompletedQuestsController do

end
