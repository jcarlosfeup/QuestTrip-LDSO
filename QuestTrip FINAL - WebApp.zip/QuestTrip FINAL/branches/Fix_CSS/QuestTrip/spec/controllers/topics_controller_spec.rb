require 'spec_helper'

describe TopicsController do

end
