require 'spec_helper'

describe EntriesController do

end
