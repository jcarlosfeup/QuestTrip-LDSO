require 'spec_helper'

describe WishlistsController do

end
