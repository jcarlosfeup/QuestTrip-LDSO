# == Schema Information
#
# Table name: users
#
#  id                 :integer          not null, primary key
#  email              :string(60)       not null
#  username           :string(20)
#  password_digest    :string(255)      not null
#  remember_token     :string(255)
#  first_name         :string(40)
#  last_name          :string(40)
#  is_admin           :boolean          default(FALSE), not null
#  is_blocked         :boolean          default(FALSE), not null
#  image_content_type :string(255)
#  image_file_size    :integer
#  image_file_name    :string(255)
#  image_updated_at   :datetime
#  facebook_id        :string(255)
#  access_token       :string(255)
#

require "spec_helper"

describe User do
  # execute this block before start the test
  before do
    @user = User.new(email: "test@fe.up.pt", password: "123456", password_confirmation: "123456")
  end

  # makes the @user object the default subject of the test
  subject { @user }

  it { should respond_to(:email) }
  it { should respond_to(:password_digest) }
  it { should respond_to(:password) }
  it { should respond_to(:password_confirmation) }
  it { should respond_to(:remember_token) }
  it { should respond_to(:authenticate) }

  # verify that the @user object is valid
  it { should be_valid }

  # is_admin tests

  describe "when is_admin is not present" do
    before { @user.is_admin = " " }
    it { should_not be_valid }
  end

  # Email tests

  describe "when email is not present" do
    before { @user.email = " " }
    it { should_not be_valid }
  end

  describe "when email is too long" do
    before { @user.email = "a" * 61 }
    it { should_not be_valid }
  end

  describe "when email format is not valid" do
    it "should be invalid" do
      addresses = %w[user@foo,com user_at_foo.org example.user@foo.foo@bar_baz.com foo@bar+bar.com]
      addresses.each do |address|
        @user.email = address
        @user.should_not be_valid
      end
    end
  end

  describe "when email format is valid" do
    it "should be valid" do
      addresses = %w[user@foo.COM A_US-ER@f.b.org frst.lst@foo.jp a+b@baz.cn xpto1234@cenas.pt]
      addresses.each do |address|
        @user.email = address
        @user.should be_valid
      end
    end
  end

  describe "when email address is already taken" do
    before do
      user_with_same_email = @user.dup
      user_with_same_email.email = @user.email.upcase
      user_with_same_email.save
    end

    it { should_not be_valid }
  end

  # Password tests

  describe "when password is not present" do
    before { @user.password = @user.password_confirmation = " " }
    it { should_not be_valid }
  end

  describe "when password confirmation is nil" do
    before { @user.password_confirmation = nil }
    it { should_not be_valid }
  end

  describe "when password doesn't match confirmation" do
    before { @user.password_confirmation = "mismatch" }
    it { should_not be_valid }
  end

  describe "return value of authenticate method" do
    before { @user.save }
    let(:found_user) { User.find_by_email(@user.email) }

    describe "with valid password" do
      it { should == found_user.authenticate(@user.password) }
    end

    describe "with invalid password" do
      let(:user_for_invalid_password) { found_user.authenticate("invalid") }

      it { should_not == user_for_invalid_password }
      specify { user_for_invalid_password.should be_false }
    end
  end

  # Username tests

  describe "when username is nil" do
    before { @user.username = nil }
    it { should be_valid }
  end

  describe "when username is empty" do
    before { @user.username = "" }
    it { should be_valid }
  end

  describe "when username is too long" do
    before { @user.username = "a" * 21 }
    it { should_not be_valid }
  end

  describe "when username is too short" do
    before { @user.username = "a" * 4 }
    it { should_not be_valid }
  end

  describe "when username format is not valid" do
    it "should be invalid" do
      names = %w[asg12~ xpto+ 1mazon whoami.? x..pto123]
      names.each do |username|
        @user.username = username
        @user.should_not be_valid
      end
    end
  end

  describe "when username format is valid" do
    it "should be valid" do
      names = %w[xpto1234 MoGAl e_alves.123]
      names.each do |username|
        @user.username = username
        @user.should be_valid
      end
    end
  end

  # First name tests

  describe "when first name is nil" do
    before { @user.first_name = nil}
    it { should be_valid }
  end

  describe "when first name is empty" do
    before { @user.first_name = ""}
    it { should be_valid }
  end

  describe "when first name format is valid" do
    it "should be valid" do
      names = %w[Eduardo Alves Miguel]
        names.each do |name|
          @user.first_name = name
          @user.should be_valid
        end
    end
  end

  describe "when first name format is not valid" do
    it "should be invalid" do
      names = %w[eDuardo EDuardo AlveS M1guel]
      names.each do |name|
        @user.first_name = name
        @user.should_not be_valid
      end
    end
  end

  # Last name tests

  describe "when last name is nil" do
    before { @user.last_name = nil }
    it { should be_valid }
  end

  describe "when last name is empty" do
    before { @user.last_name = "" }
    it { should be_valid }
  end

  describe "when last name format is valid" do
    it "should be valid" do
      names = %w[Eduardo Alves Miguel]
      names.each do |name|
        @user.last_name = name
        @user.should be_valid
      end
    end
  end

  describe "when last name format is not valid" do
    it "should be invalid" do
      names = %w[eDuardo EDuardo AlveS M1guel]
      names.each do |name|
        @user.last_name = name
        @user.should_not be_valid
      end
    end
  end

  # Remember token tests

  describe "remember token" do
    before { @user.save }
    its(:remember_token) { should_not be_blank }
  end
end
