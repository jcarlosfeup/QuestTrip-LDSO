# == Schema Information
#
# Table name: topics
#
#  id       :integer          not null, primary key
#  quest_id :integer          not null
#  user_id  :integer          not null
#  question :string(100)      not null
#

require 'spec_helper'

describe Topic do
  pending "add some examples to (or delete) #{__FILE__}"
end
