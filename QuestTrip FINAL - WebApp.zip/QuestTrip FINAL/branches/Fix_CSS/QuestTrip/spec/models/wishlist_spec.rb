# == Schema Information
#
# Table name: wishlists
#
#  id         :integer          not null, primary key
#  user_id    :integer          not null
#  is_private :boolean          default(FALSE), not null
#

require 'spec_helper'

describe Wishlist do
  pending "add some examples to (or delete) #{__FILE__}"
end
