# == Schema Information
#
# Table name: entries
#
#  id                 :integer          not null, primary key
#  album_id           :integer          not null
#  subtitle           :string(150)
#  photo_file_name    :string(255)
#  photo_content_type :string(255)
#  photo_file_size    :integer
#  photo_updated_at   :datetime
#

require 'spec_helper'

describe Entry do
  pending "add some examples to (or delete) #{__FILE__}"
end
