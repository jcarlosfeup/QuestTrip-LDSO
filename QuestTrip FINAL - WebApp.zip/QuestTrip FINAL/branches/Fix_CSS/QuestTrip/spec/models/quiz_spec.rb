# == Schema Information
#
# Table name: challenges
#
#  id                        :integer          not null, primary key
#  spot_id                   :integer          not null
#  challenge_type            :string(255)
#  is_blocked                :boolean          default(FALSE), not null
#  description               :string(255)
#  question                  :string(255)
#  puzzle_image_content_type :string(255)
#  puzzle_image_file_size    :integer
#  puzzle_image_file_name    :string(255)
#  puzzle_image_updated_at   :datetime
#  vertical_split            :integer          default(4)
#  horizontal_split          :integer          default(4)
#

require 'spec_helper'

describe Quiz do
  before do
    @quiz = Quiz.new
    @quiz.spot_id = 0
    @quiz.challenge_type = "Quiz"
    @quiz.question = "What is your name?"
  end

  subject { @quiz }

  it { should respond_to :question }

  it { should be_valid }

  # foreign keys test

  describe "when spot_id is not present" do
    before { @quiz.spot_id = " " }
    it { should_not be_valid }
  end

  # question tests

  describe "when question is not present" do
    before { @quiz.question = " " }
    it { should_not be_valid }
  end

  describe "when question is too long" do
    before { @quiz.question = "a" * 256 }
    it { should_not be_valid }
  end
end
