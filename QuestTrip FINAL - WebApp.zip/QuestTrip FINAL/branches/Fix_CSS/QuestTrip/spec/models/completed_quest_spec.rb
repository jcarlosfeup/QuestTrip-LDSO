# == Schema Information
#
# Table name: completed_quests
#
#  id       :integer          not null, primary key
#  user_id  :integer          not null
#  quest_id :integer          not null
#  score    :integer          not null
#

require 'spec_helper'

describe CompletedQuest do
  pending "add some examples to (or delete) #{__FILE__}"
end
