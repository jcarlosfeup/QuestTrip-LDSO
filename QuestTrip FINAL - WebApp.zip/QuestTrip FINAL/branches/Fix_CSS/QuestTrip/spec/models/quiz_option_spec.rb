# == Schema Information
#
# Table name: quiz_options
#
#  id           :integer          not null, primary key
#  challenge_id :integer          not null
#  option       :string(255)      not null
#  is_correct   :boolean          default(FALSE), not null
#

require 'spec_helper'

describe QuizOption do
  before do
    @quiz_option = QuizOption.new
    @quiz_option.quiz_id = 0
    @quiz_option.option = "Resposta"
    @quiz_option.is_correct = true
  end

  subject { @quiz_option }

  it { should respond_to :option }
  it { should respond_to :is_correct }

  it { should be_valid }

  # foreign key tests

  describe "when quiz_id is not present" do
    before { @quiz_option.quiz_id = " " }
    it { should_not be_valid }
  end

  # option tests

  describe "when option is not present" do
    before { @quiz_option.option = " " }
    it { should_not be_valid }
  end

  describe "when options is too long" do
    before { @quiz_option.option = "a" * 256 }
    it { should_not be_valid }
  end

  # is_correct tests

  describe "when is_correct is not present" do
    before { @quiz_option.is_correct = " " }
    it { should_not be_valid }
  end
end
