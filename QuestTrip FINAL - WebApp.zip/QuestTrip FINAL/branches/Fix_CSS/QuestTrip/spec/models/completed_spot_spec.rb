# == Schema Information
#
# Table name: completed_spots
#
#  id      :integer          not null, primary key
#  user_id :integer          not null
#  spot_id :integer          not null
#  score   :integer          default(0), not null
#

require 'spec_helper'

describe CompletedSpot do
  pending "add some examples to (or delete) #{__FILE__}"
end
