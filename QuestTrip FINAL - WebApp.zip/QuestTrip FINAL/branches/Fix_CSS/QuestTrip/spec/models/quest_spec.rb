# == Schema Information
#
# Table name: quests
#
#  id                 :integer          not null, primary key
#  user_id            :integer          not null
#  name               :string(50)       not null
#  description        :string(250)      not null
#  image_content_type :string(255)
#  image_file_size    :integer
#  image_file_name    :string(255)
#  image_updated_at   :datetime
#  is_blocked         :boolean          default(FALSE), not null
#  is_linear          :boolean          default(FALSE), not null
#

require 'spec_helper'

describe Quest do
  pending "add some examples to (or delete) #{__FILE__}"
end
