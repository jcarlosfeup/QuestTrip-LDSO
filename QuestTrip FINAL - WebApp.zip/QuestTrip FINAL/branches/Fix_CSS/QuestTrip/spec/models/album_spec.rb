# == Schema Information
#
# Table name: albums
#
#  id                 :integer          not null, primary key
#  user_id            :integer          not null
#  name               :string(35)       not null
#  description        :string(255)
#  image_content_type :string(255)
#  image_file_size    :integer
#  image_file_name    :string(255)
#  image_updated_at   :datetime
#  is_private         :boolean          default(FALSE), not null
#  is_blocked         :boolean          default(FALSE), not null
#

require "spec_helper"

describe Album do
  before do
    @album = Album.new(description: "Album 1")
  end

  subject { @album }

  it { should respond_to(:description) }
  it { should respond_to(:is_private) }

  it { should be_valid }

  # Description tests
  describe "when description is not present" do
    before { @album.description = " " }
    it { should_not be_valid }
  end

  describe "when description is too long" do
    before { @album.description = "a" * 256 }
    it { should_not be_valid }
  end

  # is_private flag
  describe "when is_private is not present" do
    before { @album.is_private = " " }
    it { should_not be_valid }
  end
end
