# == Schema Information
#
# Table name: spots
#
#  id                 :integer          not null, primary key
#  quest_id           :integer          not null
#  name               :string(30)       not null
#  description        :string(75)       not null
#  coordinates        :string           not null
#  latitude           :decimal(, )      not null
#  longitude          :decimal(, )      not null
#  sequence_order     :integer          not null
#  radius             :integer          default(10), not null
#  image_content_type :string(255)
#  image_file_size    :integer
#  image_file_name    :string(255)
#  image_updated_at   :datetime
#

require 'spec_helper'

describe Spot do
  pending "add some examples to (or delete) #{__FILE__}"
end
