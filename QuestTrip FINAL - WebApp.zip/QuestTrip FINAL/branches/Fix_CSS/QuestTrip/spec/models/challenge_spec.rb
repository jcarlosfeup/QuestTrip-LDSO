# == Schema Information
#
# Table name: challenges
#
#  id                        :integer          not null, primary key
#  spot_id                   :integer          not null
#  challenge_type            :string(255)
#  is_blocked                :boolean          default(FALSE), not null
#  description               :string(255)
#  question                  :string(255)
#  puzzle_image_content_type :string(255)
#  puzzle_image_file_size    :integer
#  puzzle_image_file_name    :string(255)
#  puzzle_image_updated_at   :datetime
#  vertical_split            :integer          default(4)
#  horizontal_split          :integer          default(4)
#

require 'spec_helper'

describe Challenge do
  before do
    @challenge = Challenge.new
    @challenge.description = "Ola mundo!"
    @challenge.challenge_type = "Quiz"
    @challenge.spot_id = 0
  end

  subject { @challenge }

  it { should respond_to(:challenge_type) }
  it { should respond_to(:description) }
  it { should respond_to(:image_path) }

  it { should be_valid }

  # description tests

  describe "when description is not present" do
    before { @challenge.description = " " }
    it { should_not be_valid }
  end

  describe "when description is too long" do
    before { @challenge.description = "a" * 256 }
    it { should_not be_valid }
  end

  # type tests

  describe "when challenge type is not present" do
    before { @challenge.challenge_type = " " }
    it { should_not be_valid }
  end

  describe "when challange_type is not valid" do
    before { @challenge.challenge_type = "lolada" }
    it { should_not be_valid }
  end

  # image_path tests

  describe "when image is not jpg nor png" do
    it "should not be valid" do
      images = %w[public/images/img1.bmp public/images/img2.pdf img3.jpg.gif]
      images.each do |image|
        @challenge.image_path = image
        @challenge.should_not be_valid
      end
    end
  end

  describe "when image is jpg or png" do
    it "should be valid" do
      images = %w[public/images/img1.jpg img2.png img/imgpdf/img.jpg]
      images.each do |image|
        @challenge.image_path = image
        @challenge.should be_valid
      end
    end
  end
end
