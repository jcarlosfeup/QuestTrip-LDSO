# == Schema Information
#
# Table name: locals
#
#  id          :integer          not null, primary key
#  wishlist_id :integer          not null
#  name        :string(255)      not null
#  coordinates :string
#  latitude    :decimal(, )      not null
#  longitude   :decimal(, )      not null
#

require 'spec_helper'

describe Local do
  pending "add some examples to (or delete) #{__FILE__}"
end
