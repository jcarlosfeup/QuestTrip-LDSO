FactoryGirl.define do
  factory :user do
    email "eduardo.alves@fe.up.pt"
    password "foobar"
    password_confirmation "foobar"
  end
end