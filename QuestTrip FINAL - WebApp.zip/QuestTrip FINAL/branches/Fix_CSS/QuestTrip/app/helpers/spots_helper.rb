module SpotsHelper
end
