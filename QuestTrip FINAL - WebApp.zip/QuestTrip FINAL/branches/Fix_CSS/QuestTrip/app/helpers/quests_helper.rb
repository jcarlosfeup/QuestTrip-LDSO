module QuestsHelper

  def has_permissions(quest)
    unless current_user.quests.exists?(quest.id)
      return false
    end
    true
  end
end
