module UsersHelper

  def pick_image_for(user)
    # The gravatar type can be a :monsterid, :identicon, :wavatar
    gravatar_image_tag(user.email, :alt => 'Profile Image', :gravatar => { :default => :identicon })
  end
end
