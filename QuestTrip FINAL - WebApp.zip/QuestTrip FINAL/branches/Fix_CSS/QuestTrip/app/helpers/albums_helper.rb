module AlbumsHelper

  def album_has_permissions(album)
    unless current_user.albums.exists?(album.id)
      return false
    end
    true
  end
end
