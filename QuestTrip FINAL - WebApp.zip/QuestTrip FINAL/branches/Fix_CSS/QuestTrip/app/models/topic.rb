# == Schema Information
#
# Table name: topics
#
#  id       :integer          not null, primary key
#  quest_id :integer          not null
#  user_id  :integer          not null
#  question :string(100)      not null
#

class Topic < ActiveRecord::Base
  attr_accessible :question, :user_id
  validates_presence_of :question, :quest_id

  validates :question, :length => { :maximum => 100 }, :allow_blank => false

  belongs_to :quest
  belongs_to :user

  has_many :comments, :dependent => :destroy
end
