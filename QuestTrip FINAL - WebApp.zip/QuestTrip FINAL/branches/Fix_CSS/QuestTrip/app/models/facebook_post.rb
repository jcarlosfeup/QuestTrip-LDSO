class FacebookPost
  cattr_accessor :message
end
