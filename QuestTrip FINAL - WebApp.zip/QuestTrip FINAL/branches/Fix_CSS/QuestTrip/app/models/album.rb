# == Schema Information
#
# Table name: albums
#
#  id                 :integer          not null, primary key
#  user_id            :integer          not null
#  name               :string(35)       not null
#  description        :string(255)
#  image_content_type :string(255)
#  image_file_size    :integer
#  image_file_name    :string(255)
#  image_updated_at   :datetime
#  is_private         :boolean          default(FALSE), not null
#  is_blocked         :boolean          default(FALSE), not null
#

class Album < ActiveRecord::Base
  attr_accessible :name, :description, :is_private, :image

  # Description validation
  validates :name, :presence => true, :length => { :maximum => 35 }
  validates :description, :length => { :maximum => 255 }
  validates_inclusion_of :is_private, :in => [true,false]

  # Create validations for the image
  has_attached_file :image, :styles => { :thumb => "160x160!" }
  validates_attachment_size :image, :less_than => 10.megabytes
  validate :file_dimensions, :unless => "errors.any?"
  before_create :randomize_file_name

  # Relationship with other entities
  belongs_to :user
  has_many :entries, :dependent => :destroy

private
  def randomize_file_name
    unless image_file_name.nil?
      extension = File.extname(image_file_name).downcase
      self.image.instance_write(:file_name, "#{SecureRandom.hex(16)}#{extension}")
    end
  end

  def file_dimensions
    unless image.queued_for_write[:original].nil?
      dimensions = Paperclip::Geometry.from_file(image.queued_for_write[:original].path)
      if dimensions.width < 180 || dimensions.height < 180
        errors.add(:image, "Width and Height must be at least 180px!")
      end
    end
  end
end
