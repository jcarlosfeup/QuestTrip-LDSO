# == Schema Information
#
# Table name: completed_spots
#
#  id      :integer          not null, primary key
#  user_id :integer          not null
#  spot_id :integer          not null
#  score   :integer          default(0), not null
#

class CompletedSpot < ActiveRecord::Base
  attr_accessible :score,:user_id,:spot_id

  belongs_to :user
  belongs_to :spot
end
