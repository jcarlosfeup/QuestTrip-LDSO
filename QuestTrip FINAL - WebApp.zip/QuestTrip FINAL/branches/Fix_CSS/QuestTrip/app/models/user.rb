# == Schema Information
#
# Table name: users
#
#  id                 :integer          not null, primary key
#  email              :string(60)       not null
#  username           :string(20)
#  password_digest    :string(255)      not null
#  remember_token     :string(255)
#  first_name         :string(40)
#  last_name          :string(40)
#  is_admin           :boolean          default(FALSE), not null
#  is_blocked         :boolean          default(FALSE), not null
#  image_content_type :string(255)
#  image_file_size    :integer
#  image_file_name    :string(255)
#  image_updated_at   :datetime
#  facebook_id        :string(255)
#  access_token       :string(255)
#

class User < ActiveRecord::Base
  attr_accessible :email, :username, :first_name, :last_name, :password, :password_confirmation, :image, :access_token

  has_secure_password
  validates_uniqueness_of :email
  validates_presence_of :email, :password, :password_confirmation

  before_save { |user| user.email = email.downcase }
  before_save :create_remember_token

  # Email validation
  VALID_EMAIL_REGEX = /^([\w+]+)@[a-z\.]+\.[a-z]+$/
  validates :email, :length => { :maximum => 60 }, :format => { :with => VALID_EMAIL_REGEX }

  # Password validation
  validates :password, :length => { :minimum => 6 }

  # Username validation
  VALID_USERNAME_REGEX = /^(([a-zA-Z])((\_|\.)?[a-zA-Z\d])+)$/
  validates :username, :allow_blank => true, :length => { :minimum => 5, :maximum => 20 }, :format => { :with => VALID_USERNAME_REGEX }

  # First and Last name validation
  VALID_NAME_REGEX = /^[A-Z][a-z]+$/
  validates :first_name, :allow_blank => true, :format => { :with => VALID_NAME_REGEX }
  validates :last_name, :allow_blank => true, :format => { :with => VALID_NAME_REGEX }

  # Username is administrator
  validates_inclusion_of :is_admin, :in => [true,false]

  # Validate user avatar
  has_attached_file :image, :styles => { :thumb => "80x80!" }
  validates_attachment_size :image, :less_than => 10.megabytes
  validate :image_dimensions, :unless => "errors.any?"
  before_create :randomize_file_name

  # Relationships with other tables

  # Quests that the user owns
  has_many :quests, :dependent => :destroy
  # Quests that the user is running
  has_many :users_playing_quests, :dependent => :destroy
  # Quests that the user has rated
  ajaxful_rater
  # User wishlist
  has_one :wishlist, :dependent => :destroy
  # User albums
  has_many :albums, :dependent => :destroy
  # User completed spots
  has_many :completed_spots, :dependent => :destroy
  # User completed quests
  has_many :completed_quests, :dependent => :destroy
  # User topics
  has_many :topics, :dependent => :destroy
  # User comments
  has_many :comments, :dependent => :destroy
  # User reports
  has_many :reports, :dependent => :destroy

  def self.load_authentication(email)
    user = User.find_by_email(email)
    unless user.nil?
      return user
    end
    return nil
  end

private
  def randomize_file_name
    unless image_file_name.nil?
      extension = File.extname(image_file_name).downcase
      self.image.instance_write(:file_name, "#{SecureRandom.hex(16)}#{extension}")
    end
  end

  def image_dimensions
    unless image_file_name.nil?
      unless image.queued_for_write[:original].nil?
        dimensions = Paperclip::Geometry.from_file(image.queued_for_write[:original].path)
        if dimensions.width < 180 || dimensions.height < 180
          errors.add(:image, "Width and Height must be at least 180px!")
        end
      end
    end
  end

  def create_remember_token
    self.remember_token = SecureRandom.base64.tr("+/", "-_")
  end
end
