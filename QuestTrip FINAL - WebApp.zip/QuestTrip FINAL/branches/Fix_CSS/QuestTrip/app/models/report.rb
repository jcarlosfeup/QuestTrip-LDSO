# == Schema Information
#
# Table name: reports
#
#  id          :integer          not null, primary key
#  subject     :string(255)
#  report_text :text
#  user_id     :integer          not null
#

class Report < ActiveRecord::Base
  attr_accessible :report_text, :subject , :user_id

  validates :report_text, :length => { :maximum => 150 }, :allow_blank => false
  validates :subject, :length => {:maximum => 50}, :allow_blank => false

  belongs_to :user
end
