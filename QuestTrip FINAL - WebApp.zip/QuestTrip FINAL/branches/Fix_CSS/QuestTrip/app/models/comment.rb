# == Schema Information
#
# Table name: comments
#
#  id       :integer          not null, primary key
#  topic_id :integer          not null
#  user_id  :integer          not null
#  answer   :string(100)      not null
#

class Comment < ActiveRecord::Base
  attr_accessible :answer

  validates_presence_of :answer

  validates :answer, :length => { :maximum => 100 }, :allow_blank => false

  belongs_to :topic
  belongs_to :user
end
