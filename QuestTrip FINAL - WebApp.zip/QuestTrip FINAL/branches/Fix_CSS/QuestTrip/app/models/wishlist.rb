# == Schema Information
#
# Table name: wishlists
#
#  id         :integer          not null, primary key
#  user_id    :integer          not null
#  is_private :boolean          default(FALSE), not null
#

class Wishlist < ActiveRecord::Base
  attr_accessible :is_private

  validates_inclusion_of :is_private, :in => [true,false]

  belongs_to :user
  has_many :locals
end
