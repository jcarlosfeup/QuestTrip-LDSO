# == Schema Information
#
# Table name: entries
#
#  id                 :integer          not null, primary key
#  album_id           :integer          not null
#  subtitle           :string(150)
#  photo_file_name    :string(255)
#  photo_content_type :string(255)
#  photo_file_size    :integer
#  photo_updated_at   :datetime
#

class Entry < ActiveRecord::Base
  attr_accessible :subtitle, :photo

  validates :subtitle, :length => { :maximum => 150 }

  # paperclip stuff
  has_attached_file :photo, :styles => { :thumb => "160x160" }
  validates_attachment_size :photo, :less_than => 10.megabytes
  validates_attachment_presence :photo
  #validates_attachment_content_type :photo, content_type: %w( image/png image/jpg image/gif ), message: "file type is not allowed only (jpg/png images)"
  validate :file_dimensions, :unless => "errors.any?"
  before_create :randomize_file_name

  belongs_to :album

private
  def randomize_file_name
    extension = File.extname(photo_file_name).downcase
    self.photo.instance_write(:file_name, "#{SecureRandom.hex(16)}#{extension}")
  end

  def file_dimensions
    unless photo.queued_for_write[:original].nil?
      dimensions = Paperclip::Geometry.from_file(photo.queued_for_write[:original].path)
      if dimensions.width < 180 || dimensions.height < 180
        errors.add(:photo, "Width and Height must be at least 180px!")
      end
    end
  end
end
