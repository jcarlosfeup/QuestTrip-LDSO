# == Schema Information
#
# Table name: suggested_quests
#
#  id       :integer          not null, primary key
#  quest_id :integer          not null
#

# == Schema Information
#
# Table name: suggested_quest
#
#  id           :integer          not null, primary key
#  quest_id      :integer          not null
#
class SuggestedQuest < ActiveRecord::Base
  attr_accessible :quest_id

  belongs_to :quest

end
