# == Schema Information
#
# Table name: challenges
#
#  id                        :integer          not null, primary key
#  spot_id                   :integer          not null
#  challenge_type            :string(255)
#  is_blocked                :boolean          default(FALSE), not null
#  description               :string(255)
#  question                  :string(255)
#  puzzle_image_content_type :string(255)
#  puzzle_image_file_size    :integer
#  puzzle_image_file_name    :string(255)
#  puzzle_image_updated_at   :datetime
#  vertical_split            :integer          default(4)
#  horizontal_split          :integer          default(4)
#

class Visit < Challenge
  attr_accessible :description

  validates_presence_of :description
  validates :description, :length => { :maximum => 255 }, :allow_blank => false
end
