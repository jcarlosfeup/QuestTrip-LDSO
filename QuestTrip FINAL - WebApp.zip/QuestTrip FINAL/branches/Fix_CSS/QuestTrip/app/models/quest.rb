# == Schema Information
#
# Table name: quests
#
#  id                 :integer          not null, primary key
#  user_id            :integer          not null
#  name               :string(50)       not null
#  description        :string(250)      not null
#  image_content_type :string(255)
#  image_file_size    :integer
#  image_file_name    :string(255)
#  image_updated_at   :datetime
#  is_blocked         :boolean          default(FALSE), not null
#  is_linear          :boolean          default(FALSE), not null
#

class Quest < ActiveRecord::Base
  attr_accessible :name, :description, :image, :spots_attributes, :topics_attributes, :is_linear, :is_blocked

  # Validate fields
  validates :user_id, :presence => true
  validates :name, :presence => true, :length => { :maximum => 50 }
  validates :description, :presence => true, :length => { :maximum => 250 }

  validates_inclusion_of :is_linear, :in => [true, false]
  validates_inclusion_of :is_blocked, :in => [true, false]

  # Convert all the given images to 849x312 size and save the image as png
  has_attached_file :image, :styles => { :thumb => "160x160!", :original => "849x312!", :android_image => "450x165!" }
  validates_attachment_size :image, :less_than => 10.megabytes
  before_create :randomize_file_name

  # Relationships with other tables
  belongs_to :user
  # Spots that belong to the quest
  has_many :spots, :dependent => :destroy
  accepts_nested_attributes_for :spots, :reject_if => proc { |attribute| attribute[:name].blank? }, :allow_destroy => true

  # Users that are playing this quest
  has_many :users_playing_quests, :dependent => :destroy
  # Users that completed this quest
  has_many :completed_quests, :dependent => :destroy
  # Suggested quests
  has_many :suggested_quests, :dependent => :destroy

  # Rating the quest
  ajaxful_rateable :stars => 5

  # Mini-forum stuff
  has_many :topics, :dependent => :destroy

private
  def randomize_file_name
    unless image_file_name.nil?
      extension = File.extname(image_file_name).downcase
      self.image.instance_write(:file_name, "#{SecureRandom.hex(16)}#{extension}")
    end
  end
end
