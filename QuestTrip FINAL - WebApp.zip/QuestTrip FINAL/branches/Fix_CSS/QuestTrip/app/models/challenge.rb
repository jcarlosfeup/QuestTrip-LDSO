# == Schema Information
#
# Table name: challenges
#
#  id                        :integer          not null, primary key
#  spot_id                   :integer          not null
#  challenge_type            :string(255)
#  is_blocked                :boolean          default(FALSE), not null
#  description               :string(255)
#  question                  :string(255)
#  puzzle_image_content_type :string(255)
#  puzzle_image_file_size    :integer
#  puzzle_image_file_name    :string(255)
#  puzzle_image_updated_at   :datetime
#  vertical_split            :integer          default(4)
#  horizontal_split          :integer          default(4)
#

class Challenge < ActiveRecord::Base
  self.inheritance_column = 'challenge_type'

  validates_presence_of :spot_id
  attr_accessible :quiz_options_attributes

  # Validates challenge_type attribute
  validates :challenge_type, :length => { :maximum => 6 }
  validates_inclusion_of :challenge_type, :in => %w( Quiz Visit Puzzle )

  # Associations
  belongs_to :spot
  has_many :quiz_options, :dependent => :destroy
  accepts_nested_attributes_for :quiz_options, :reject_if => proc { |a| a[:option].blank? }, :allow_destroy => true

private
  def randomize_file_name
    unless image_file_name.nil?
      extension = File.extname(image_file_name).downcase
      self.image.instance_write(:file_name, "#{SecureRandom.hex(16)}#{extension}")
    end
  end

  def image_dimensions
    unless image_file_name.nil?
      dimensions = Paperclip::Geometry.from_file(image.queued_for_write[:original].path)
      if dimensions.width < 180 || dimensions.height < 180
        errors.add(:image, "Width and Height must be at least 180px!")
      end
    end
  end
end
