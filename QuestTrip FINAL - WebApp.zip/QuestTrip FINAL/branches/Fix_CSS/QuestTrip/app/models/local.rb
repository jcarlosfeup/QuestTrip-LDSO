# == Schema Information
#
# Table name: locals
#
#  id          :integer          not null, primary key
#  wishlist_id :integer          not null
#  name        :string(255)      not null
#  coordinates :string
#  latitude    :decimal(, )      not null
#  longitude   :decimal(, )      not null
#

class Local < ActiveRecord::Base
  attr_accessible :name, :latitude, :longitude

  before_save :save_coordinates

  validates_presence_of :latitude, :longitude
  validates :latitude, :numericality => { :only_integer => false }
  validates :longitude, :numericality => { :only_integer => false }

  belongs_to :wishlist

private

  def save_coordinates
    self.coordinates = "(#{self.longitude},#{self.latitude})"
  end
end
