# == Schema Information
#
# Table name: spots
#
#  id                 :integer          not null, primary key
#  quest_id           :integer          not null
#  name               :string(30)       not null
#  description        :string(75)       not null
#  coordinates        :string           not null
#  latitude           :decimal(, )      not null
#  longitude          :decimal(, )      not null
#  sequence_order     :integer          not null
#  radius             :integer          default(10), not null
#  image_content_type :string(255)
#  image_file_size    :integer
#  image_file_name    :string(255)
#  image_updated_at   :datetime
#

class Spot < ActiveRecord::Base
  acts_as_gmappable :process_geocoding => false
  validates_presence_of :name, :sequence_order, :latitude, :longitude, :radius, :description
  attr_accessible :name, :sequence_order, :radius, :image, :latitude, :longitude, :coordinates, :description

  before_save :save_coordinates
  before_update :save_coordinates

  validates :name, :length => { :maximum => 30}, :allow_blank => false
  validates :description, :length => { :maximum => 75 }, :allow_blank => false
  validates :sequence_order, :allow_blank => false, :numericality => { :only_integer => true }

  validates :radius, :numericality => { :only_integer => true, :greater_than_or_equal_to => 10 }
  validates :latitude, :numericality => { :only_integer => false }
  validates :longitude, :numericality => { :only_integer => false }

  has_attached_file :image, :styles => { :thumb => "160x160!", :original => "849x312!", :android_image => "300x" }
  validates_attachment_size :image, :less_than => 10.megabytes
  validate :image_dimensions, :unless => "errors.any?"
  before_create :randomize_file_name

  # Associations
  belongs_to :quest
  has_one :challenge, :dependent => :destroy
  has_many :completed_spots, :dependent => :destroy

private

  def save_coordinates
    logger.debug "Saving coordinates"
    self.coordinates = "(#{self.longitude},#{self.latitude})"
  end

  def randomize_file_name
    unless image_file_name.nil?
      extension = File.extname(image_file_name).downcase
      self.image.instance_write(:file_name, "#{SecureRandom.hex(16)}#{extension}")
    end
  end

  def image_dimensions
    unless image_file_name.nil?
      unless image.queued_for_write[:original].nil?
        dimensions = Paperclip::Geometry.from_file(image.queued_for_write[:original].path)
        if dimensions.width < 180 || dimensions.height < 180
          errors.add(:image, "Width and Height must be at least 180px!")
        end
      end
    end
  end
end
