# == Schema Information
#
# Table name: completed_quests
#
#  id       :integer          not null, primary key
#  user_id  :integer          not null
#  quest_id :integer          not null
#  score    :integer          not null
#

class CompletedQuest < ActiveRecord::Base
  attr_accessible :score,:user_id,:quest_id

  validates_presence_of :score
  validates :score, :numericality => { :only_integer => true }

  belongs_to :user
  belongs_to :quest
end
