# == Schema Information
#
# Table name: challenges
#
#  id                        :integer          not null, primary key
#  spot_id                   :integer          not null
#  challenge_type            :string(255)
#  is_blocked                :boolean          default(FALSE), not null
#  description               :string(255)
#  question                  :string(255)
#  puzzle_image_content_type :string(255)
#  puzzle_image_file_size    :integer
#  puzzle_image_file_name    :string(255)
#  puzzle_image_updated_at   :datetime
#  vertical_split            :integer          default(4)
#  horizontal_split          :integer          default(4)
#

class Puzzle < Challenge
  attr_accessible :horizontal_split, :vertical_split, :puzzle_image

  # Validates image type
  has_attached_file :puzzle_image, :styles => { :original => "400x400" }
  validates_attachment_size :puzzle_image, :less_than => 10.megabytes
  validates_attachment_presence :puzzle_image
  before_create :randomize_puzzle_file_name

  # Validates image splits
  validates :horizontal_split, :numericality => { :only_integer => true, :greater_than_or_equal_to => 4 }, :allow_blank => true
  validates :vertical_split, :numericality => { :only_integer => true, :greater_than_or_equal_to => 4 }, :allow_blank => true

private
  def randomize_puzzle_file_name
    unless puzzle_image_file_name.nil?
      extension = File.extname(puzzle_image_file_name).downcase
      self.puzzle_image.instance_write(:file_name, "#{SecureRandom.hex(16)}#{extension}")
    end
  end
end
