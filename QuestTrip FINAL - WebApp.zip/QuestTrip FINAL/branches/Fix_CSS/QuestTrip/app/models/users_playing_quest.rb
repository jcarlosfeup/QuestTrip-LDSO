# == Schema Information
#
# Table name: users_playing_quests
#
#  id       :integer          not null, primary key
#  user_id  :integer          not null
#  quest_id :integer          not null
#

class UsersPlayingQuest < ActiveRecord::Base
  attr_accessible :user_id, :quest_id

  belongs_to :user
  belongs_to :quest
end
