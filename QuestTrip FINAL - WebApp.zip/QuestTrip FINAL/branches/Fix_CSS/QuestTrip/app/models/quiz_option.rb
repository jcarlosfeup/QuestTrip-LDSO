# == Schema Information
#
# Table name: quiz_options
#
#  id           :integer          not null, primary key
#  challenge_id :integer          not null
#  option       :string(255)      not null
#  is_correct   :boolean          default(FALSE), not null
#

class QuizOption < ActiveRecord::Base
  attr_accessible :option, :is_correct

  # Validates option attribute
  validates :option, :length => { :maximum => 255 }, :allow_blank => false
  validates_inclusion_of :is_correct, :in => [true,false]

  # Associations
  belongs_to :challenge
end
