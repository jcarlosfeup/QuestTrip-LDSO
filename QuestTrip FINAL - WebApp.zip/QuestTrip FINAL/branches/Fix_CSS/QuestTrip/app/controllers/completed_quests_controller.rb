class CompletedQuestsController < ApplicationController
  before_filter :signed_in_user, :only => [:index]

  def index
    @completed_quests = User.find(params[:user_id]).completed_quests
  end
end
