class SpotsController < ApplicationController
  before_filter :signed_in_user, :quest_owner, :only => [:new, :create]
  before_filter :signed_in_user, :correct_user, :only => [:edit, :update]

  def new
    @spot = Spot.new
  end

  def edit
    @spot = Spot.find(params[:id])
  end

  def create
    @spot = Quest.find(params[:quest_id]).spots.build(params[:spot])
    if @spot.save
      redirect_to @spot, :notice => 'Spot was successfully created.'
    else
      render :action => "new"
    end
  end

  def update
    @spot = Spot.find(params[:id])

    if @spot.update_attributes(params[:spot])
      redirect_to @spot, :success => 'Spot was successfully updated.'
    else
      render :action => "edit"
    end
  end

  def destroy
    @spot = Spot.find(params[:id])
    @spot.destroy
    redirect_to spots_url
  end

private

  def quest_owner
    if current_user.quests.exists?(params[:quest_id])
      return true
    end
    redirect_to quest_path(:id => params[:quest_id])
  end

  def correct_user
    redirect_to quest_path(:id => params[:quest_id]) unless is_owner
  end

  def is_owner
    if current_user.quests.exists?(params[:quest_id])
      quest = Quest.find(params[:quest_id])
      if quest.spots.exists?(params[:spot_id])
        return true
      end
    end
    false
  end
end
