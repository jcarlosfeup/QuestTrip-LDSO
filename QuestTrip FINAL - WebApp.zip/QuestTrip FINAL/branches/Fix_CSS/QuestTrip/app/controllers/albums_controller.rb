class AlbumsController < ApplicationController
  before_filter :signed_in_user, :only => [:new, :create, :index]
  before_filter :signed_in_user, :can_be_shown, :only => [:show]
  before_filter :signed_in_user, :correct_user, :only => [:edit, :update]
  before_filter :has_permissions, :only => [:destroy]

  def index
    @albums = User.find(params[:user_id]).albums.paginate(:page => params[:page], :per_page => 10)
  end

  def show
    @data = {}
    @data[:album] = Album.find(params[:id])
    @data[:entries] = @data[:album].entries.paginate(:page => params[:page], :per_page => 10)
    @data[:is_owner] = is_owner
  end

  def new
    @album = Album.new
  end

  def create
    @user = User.find(params[:user_id])
    @album = Album.new(params[:album])
    if @user.albums << @album
      flash[:success] = "Album created!"
      redirect_to user_albums_path(:user_id => params[:user_id])
    else
      render 'new'
    end
  end

  def edit
    @album = Album.find(params[:id])
  end

  def update
    @album = Album.find(params[:id])
    @album.update_attributes(params[:album])
    if @album.save
      flash[:success] = "Changes saved!"
      redirect_to user_album_path(:user_id => params[:user_id], :id => params[:id])
    else
      render 'edit'
    end
  end

  def destroy
    @album = Album.find(params[:id])
    if @album.destroy
      flash[:success] = "Album removed!"
    else
      flash[:error] = "Album not removed!"
    end
    redirect_to user_albums_path(:user_id => params[:user_id])
  end

private

  def can_be_shown
    if Album.find(params[:id]).is_private?
      unless current_user.albums.exists?(params[:id])
        unless current_user.is_admin?
          redirect_to root_path
        end
      end
    end
  end

  def correct_user
    unless is_owner
      redirect_to root_path
    end
  end

  def is_owner
    unless current_user.albums.exists?(params[:id])
      return false
    end
    true
  end

  # Check if the user is either admin or the object owner
  def has_permissions
    unless current_user.is_admin?
      unless current_user.albums.exists?(params[:id])
        redirect_to root_path
      end
    end
  end
end
