class CommentsController < ApplicationController
  before_filter :signed_in_user, :only => [:create]
  before_filter :signed_in_user, :correct_user, :only => [:destroy]

  def create
    @topic = Topic.find(params[:topic_id])
    @quest = Quest.find(@topic.quest_id)
    @comment = @topic.comments.new(params[:comment])
    @comment.user_id = current_user.id

    if @comment.save
      redirect_to @quest, :notice => 'Comment was successfully created.'
    else
      render :action => "new"
    end
  end

  def destroy
    @comment = Comment.find(params[:id])
    @comment.destroy

    @topic = Topic.find(params[:topic_id])
    redirect_to quest_path(:id => @topic.quest_id), :notice => 'Topic deleted'
  end

private

  def is_owner
    if current_user.comments.exists?(params[:id])
      return true
    end
    false
  end

  def correct_user
    redirect_to root_path unless is_owner
  end
end