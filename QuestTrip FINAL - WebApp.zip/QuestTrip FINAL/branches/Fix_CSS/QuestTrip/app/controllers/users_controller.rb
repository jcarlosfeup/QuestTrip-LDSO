class UsersController < ApplicationController
  before_filter :signed_in_user, :only => [:show]
  before_filter :signed_in_user, :correct_user, :only => [:edit, :update]
  before_filter :signed_in_user, :has_admin_permissions, :only => [:index, :is_blocked]

  def index
    @users = User.all
  end

  def is_blocked
    @user = User.find(params[:id])
    if @user.is_blocked
      @user.update_attribute(:is_blocked , false)
      redirect_to user_path(:id => @user.id), :notice=> 'User was successfully unlocked.'
    else
      @user.update_attribute(:is_blocked, true)
      redirect_to user_path(:id => @user.id), :notice=> 'User was successfully blocked.'
    end
  end

  def show
    @user = User.find(params[:id])

    @data = {}
    q = "SELECT * FROM users_playing_quests,quests WHERE users_playing_quests.quest_id= quests.id AND users_playing_quests.user_id = #{params[:id]}"
    @data[:playing_quests] = UsersPlayingQuest.find_by_sql q

    @list = {}
    @data[:playing_quests].each do |q|
      @list[q.quest_id] = {}
      @quest = Quest.find(q.quest_id)
      @list[q.quest_id][:image] = @quest.image
    end

    q = "SELECT * FROM completed_quests,quests WHERE completed_quests.quest_id= quests.id AND completed_quests.user_id = #{params[:id]}"
    @data[:completed_quests] = CompletedQuest.find_by_sql q
    @list2 = {}
    @data[:completed_quests].each do |q|
      @list2[q.quest_id] = {}
      @quest = Quest.find(q.quest_id)
      @list2[q.quest_id][:image] = @quest.image
    end

    @data[:is_owner] = is_owner
    @data[:is_admin] = is_admin
  end

  def new
    if signed_in?
      redirect_to current_user
    else
      @user = User.new
    end
  end

  def create
    @user = User.new(params[:user])
    if @user.save
      User.find(@user.id).wishlist = Wishlist.new
      sign_in @user
      flash[:success] = "Signup completed with success!"
      redirect_to @user
    else
      render 'new'
    end
  end

  def edit
    # @user = User.find(params[:id]) can be omitted thanks to the correct_user filter
  end

  def update
    # @user = User.find(params[:id]) can be omitted thanks to the correct_user filter
    if @user.update_attributes(params[:user])
      flash[:success] = "Profile updated!"
      sign_in @user
      redirect_to @user
    else
      render 'edit'
    end
  end

private

  def correct_user
    redirect_to root_path unless is_owner
  end

  def is_owner
    @user = User.find(params[:id])
    current_user?(@user)
  end
end
