class SuggestedQuestsController < ApplicationController
  before_filter :signed_in_user, :has_admin_permissions, :only => [:new,:create,:destroy]

  def index
    @suggested_quests = SuggestedQuest.all

    @list = {}

    @suggested_quests.each do |q|
      @list[q.quest_id] = {}
      @quest = Quest.find(q.quest_id)
      @list[q.quest_id][:name] = @quest.name
      @list[q.quest_id][:description] = @quest.description
      @list[q.quest_id][:image] = @quest.image
    end
  end

  def new
    @suggested_quest = SuggestedQuest.new
  end

  def create
    @suggested_quest = SuggestedQuest.new
    @suggested_quest.quest_id = params[:quest_id]
    if @suggested_quest.save
      redirect_to quests_path, :notice => 'That quest was successfully added to suggested Quests.'
    else
      render :action => "new"
    end
  end

  def destroy
    @suggested_quest = SuggestedQuest.find(params[:id])
    @suggested_quest.destroy

    redirect_to suggested_quests_url
  end

end
