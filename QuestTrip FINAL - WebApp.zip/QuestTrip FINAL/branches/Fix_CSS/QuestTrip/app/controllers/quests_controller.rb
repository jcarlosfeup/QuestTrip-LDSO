class QuestsController < ApplicationController

  before_filter :signed_in_user, :only => [:new, :create]
  before_filter :signed_in_user, :correct_user, :only => [:edit, :update, :destroy]
  before_filter :signed_in_user, :has_admin_permissions, :only => [:block]

  def new
    if signed_in?
      @quest = Quest.new
      @markers = @quest.spots.all.to_gmaps4rails
    else
      redirect_to signin_path
    end
  end

  def create
    if signed_in?
      @quest = Quest.new(params[:quest])
      if current_user.quests << @quest
        flash[:success] = "Quest created!"
        redirect_to @quest
      else
        render "new"
      end
    else
      redirect_to signin_path
    end
  end

  def index
    @quests = Quest.paginate(:page => params[:page], :per_page => 10)
    @data = {}
    @data[:is_admin] = is_admin
  end

  def show
    @data = {}
    @quest = Quest.find(params[:id])

    # Get all the quest's spots
    @data[:spots] = Spot.find_by_sql "SELECT * FROM spots WHERE spots.quest_id = #{@quest.id} ORDER BY spots.sequence_order ASC;"

    @data[:markers] = @quest.spots.all.to_gmaps4rails

    q = "SELECT COUNT(*) FROM rates WHERE rateable_id = #{@quest.id};"
    result = Rate.find_by_sql q
    @data[:total_rates] = result[0].count

    fb_app_id = 110619985774776
    #Necessario mudar o redirect uri se tiver a usar localhost
    @data[:oauth_url] = MiniFB.oauth_url(fb_app_id, # your Facebook App ID (NOT API_KEY)
                                  "https://questtrip.herokuapp.com/sessionUpdate/" + @quest.user_id.to_s + "/" + @quest.id.to_s, # redirect url
                                  :scope=>MiniFB.scopes.join(",")) # This asks for all permissions

    q = " SELECT quests.id as quest_id,completed_quests.score,users.*
          FROM quests,completed_quests,users
          WHERE quests.id = completed_quests.quest_id
            AND quests.id = #{params[:id]}
            AND completed_quests.user_id = users.id
          ORDER BY completed_quests.score DESC LIMIT 5;"
    @data[:hi_scores] = Quest.find_by_sql q

    q = "SELECT COUNT(*) as completed FROM quests, completed_quests WHERE quests.id = #{params[:id]} AND quests.id = completed_quests.quest_id"
    @data[:completesQuests] = Quest.find_by_sql q

    q = "SELECT COUNT(*) as playing FROM quests, users_playing_quests WHERE quests.id = #{params[:id]} AND quests.id = users_playing_quests.quest_id"
    @data[:playingQuests] = Quest.find_by_sql q

    @data[:is_owner] = is_owner
    @data[:is_admin] = is_admin

  end

  def edit
    @quest = Quest.find(params[:id])
    @markers = @quest.spots.all.to_gmaps4rails
  end

  def update
    @quest = Quest.find(params[:id])
    if @quest.update_attributes(params[:quest])
      redirect_to @quest, :success => 'Quest was successfully updated.'
    else
      render :action => "edit"
    end
  end

  def destroy
    @quest = Quest.find(params[:id])
    @quest.destroy
    redirect_to quests_url
  end

  def rate
    @quest = Quest.find(params[:id])
    params[:dimension].blank? ? dimension = nil : dimension = params[:dimension]

    respond_to do |format|
      if @quest.rate(params[:stars], current_user, dimension)
        format.js { render :partial => "rating" }
      else
        format.js { render :partial => "rating" }
      end
    end
  end

  def block
    @quest = Quest.find(params[:id])
    if @quest.is_blocked?
      if @quest.update_attributes(:is_blocked => 'false')
        redirect_to quests_path, :notice => 'Quest was successfully unlocked.'
      end
    else
      if @quest.update_attributes(:is_blocked => 'true')
        redirect_to quests_path, :notice => 'Quest was successfully blocked.'
      end
    end
  end

private

  def correct_user
    redirect_to root_path unless is_owner
  end

  def is_owner
    if current_user.quests.exists?(params[:id])
      return true
    end
    false
  end
end
