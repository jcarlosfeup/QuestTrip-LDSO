class Api::V1::SpotsController < ApplicationController

  def process_request

    if params.has_key?(:spot) && params.has_key?(:method)

      if params[:method] == "setSpotCompleted"
        set_spot_completed params[:spot]
      else
        render_error_message("Unknown method.")
      end
    else
      render_error_message("Error parsing message.")
    end

  end

private

  def set_spot_completed(data)
    if data.has_key?(:spot_id)
      challenge = Challenge.find(data[:spot_id])
      spot = Spot.find(challenge.spot_id)
      quest = Quest.find(spot.quest_id)

      if data.has_key?(:email)
        user = User.find_by_email(data[:email])
        if data.has_key?(:score)
          score = data[:score]

          if spot.nil?
            render_success_message "No spot found", {}
          elsif user.nil?
            render_success_message "No user found", {}
          else

            obj = { :user_id => user.id,
                    :spot_id => spot.id,
                    :score => score,
            }

            q = " SELECT *
                FROM completed_spots
                WHERE user_id = #{user.id} AND spot_id = #{spot.id};"

            result = CompletedSpot.find_by_sql q

            # Para actualizar e nao criar um novo rate
            if result.count == 0
              @spot_completed = CompletedSpot.new(obj)
              if @spot_completed.save


                # Se ainda nao acabou a quest GRAVA
                if finishedQuest(quest.id,user.id) == -1
                  q2 = " SELECT *
                  FROM users_playing_quests
                  WHERE user_id = #{user.id} AND quest_id = #{quest.id};"
                  result2 = UsersPlayingQuest.find_by_sql q2
                  if result2.count == 0
                      obj2 = { :user_id=> user.id,
                              :quest_id => quest.id,
                    }
                    @user_playing = UsersPlayingQuest.new(obj2)
                    @user_playing.save
                  end
                  render_success_message "Completed Spot saved", {}
                else
                 # sum = finishedQuest(quest.id,user.id)
                 # render_success_message sum, {}

                  obj2 = { :user_id => user.id,
                          :quest_id => quest.id,
                          :score => finishedQuest(quest.id,user.id),
                  }
                  @quest_completed = CompletedQuest.new(obj2)
                  @quest_completed.save
                  @playing_quest = UsersPlayingQuest.find_by_quest_id(quest.id)
                  if !@playing_quest.nil?
                    @playing_quest.destroy
                  end
                  render_success_message "Completed Spot saved", {}

                end
              else
                render_error_message "Error saving Completed Spot"
              end
            else
              result.each do |r|
                @spot_completed = CompletedSpot.find(r[:id])

                if @spot_completed.update_attributes(obj)
                  if finishedQuest(quest.id,user.id) > -1
                    obj = { :user_id => user.id,
                            :quest_id => quest.id,
                            :score => finishedQuest(quest.id,user.id),
                    }
                    @quest_completed = CompletedQuest.new(obj)
                    @quest_completed.save
                    @playing_quest = UsersPlayingQuest.find_by_quest_id(quest.id)
                    if !@playing_quest.nil?
                      @playing_quest.destroy
                    end
                  end
                  render_success_message "Completed Spot saved", {}
                else
                  render_error_message "Error saving Completed Spot"
                end
              end
            end


          end
        else
          render_error_message "Error parsing message."
        end
      else
        render_error_message "Error parsing message."
      end
    else
      render_error_message "Error parsing message."
    end
  end


end


# RETORNA -1 NO CASO DA QUEST NAO ESTAR COMPLETA E O SCORE NO CASO DE ESTAR COMPLETA
def finishedQuest(quest_id,user_id)

  q = " SELECT SUM(score),COUNT(*) FROM completed_spots, (SELECT * FROM spots WHERE spots.quest_id = #{quest_id}) AS spt
          WHERE completed_spots.spot_id = spt.id AND completed_spots.user_id = #{user_id}"
  q2 = "SELECT COUNT(*) FROM spots WHERE quest_id = #{quest_id}"

  result = CompletedSpot.find_by_sql q
  result2 = Spot.find_by_sql q2

  sum = 0
  count = 0
  count2 = 0
  result.each do |r|
    sum = r[:sum]
    count = r[:count]
  end
  result2.each do |r2|
    count2 = r2[:count]
  end

  if count == count2
    return sum.to_i;
  else
    return -1.to_i;
  end

end
