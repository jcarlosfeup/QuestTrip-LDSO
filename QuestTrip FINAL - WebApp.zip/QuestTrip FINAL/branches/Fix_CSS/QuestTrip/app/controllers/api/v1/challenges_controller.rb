class Api::V1::ChallengesController < ApplicationController

  def get_challenge

    if params.has_key?(:challenge)
      if params[:challenge].has_key?(:id)
        challenge = Challenge.find(params[:challenge][:id])
        if challenge.nil?
          render_success_message "Challenge not found!", {}
        else
          process_challenge challenge
        end
      else
        render_error_message "Error parsing message."
      end
    else
      render_error_message "Error parsing message"
    end
  end

  private
  def process_challenge(data)
    challenge_type = data[:challenge_type]
    json = {}

    # Pick challenge type
    unless data[:challenge_type].nil?
      json[:challenge_type] = data[:challenge_type]
    end

    # Pick challenge description
    unless data[:description].nil?
      json[:description] = data[:description]
    end

    if challenge_type == "Visit"
      logger.debug "VISIT"
      # At this point does nothing because the only attribute here is the description loaded previously
    elsif challenge_type == "Quiz"
      json[:question] = data[:question]
      answers = Challenge.find(data[:id]).quiz_options
      json[:answers] = answers
    elsif challenge_type == "Puzzle"
      # Load the puzzle_image_path (never nil)
      json[:puzzle_image] = data.puzzle_image.url
      # TODO brute force value fix this
      json[:size] = 3
    end

    render_success_message "Challenge found!", json
  end
end
