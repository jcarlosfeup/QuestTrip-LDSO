class Api::V1::SessionsController < ApplicationController
  helper UsersHelper

  def create
    json = params[:user]

    if json.has_key?(:email)
      user = User.load_authentication(json[:email].downcase)


      if user && user.authenticate(json[:password])
        data = { :email => user[:email],
                 :username => user[:username],
                 :image => user.image.url,
                 :first_name => user[:first_name],
                 :last_name => user[:last_name],
                 :remember_token => user[:remember_token] }
        render_success_message "Logged in", data
      else
        render_error_message "Error authenticating"
      end
    else
      render_error_message "Error parsing message"
    end
  end
end