class Api::V1::QuestsController < ApplicationController

  def process_request

    if params.has_key?(:quest) && params.has_key?(:method)
      if params[:method] == "spotsByQuest"
        spots_by_quest params[:quest]
      elsif params[:method] == "questsByCoords"
        quests_by_coords params[:quest]
      elsif params[:method] == "rating"
        rating params[:quest]
      elsif params[:method] == "getImage"
        get_image params[:quest]
      elsif params[:method] == "getRating"
        get_rating params[:quest]
      elsif params[:method] == "questsByName"
        quest_by_name params[:quest]
      elsif params[:method] == "setQuestCompleted"
        set_quest_completed params[:quest]
      elsif params[:method] == "setPlayingQuest"
        set_playing_quest params[:quest]
      elsif params[:method] == "getQuestInfo"
        get_quest_info params[:quest]
      elsif params[:method] == "getUserAllQuests"
        get_user_all_quests params[:quest]
      else
        render_error_message("Unknown method.")
      end
    else
      render_error_message("Error parsing message.")
    end
  end

private

  def get_user_all_quests(data)
    if data.has_key?(:email)
      user = User.find_by_email(data[:email])

      if user.nil?
        render_success_message "No user found", {}
      else
        # Para as quest que estao a ser jogadas

        q = "  SELECT total.q_id as quest_id, total.spotsDone as spots_done,total.totalSpots as total_spots,total.score , quests.name FROM quests,
                (SELECT COUNT(totalSpots.quest_id) as spotsDone,totalSpots.quest_id as q_id,totalSpots.*,SUM(score) as score FROM completed_spots,spots,
                  (SELECT COUNT(spots.id) as totalSpots, spots.quest_id
                    FROM spots,
                    (SELECT users_playing_quests.quest_id
                    FROM users_playing_quests
                    WHERE users_playing_quests.user_id = #{user.id}) AS questPlaying
                  WHERE questPlaying.quest_id = spots.quest_id GROUP BY spots.quest_id) AS totalSpots
                WHERE completed_spots.spot_id = spots.id AND spots.quest_id = totalSpots.quest_id AND completed_spots.user_id = #{user.id} GROUP BY totalSpots.quest_id,totalSpots.totalSpots) AS total
              WHERE total.q_id = quests.id;"

        # Para as quests terminadas
        q2 = "  SELECT total.q_id as quest_id, total.spotsDone as spots_done,total.totalSpots as total_spots,total.score , quests.name FROM quests,
                (SELECT COUNT(totalSpots.quest_id) as spotsDone,totalSpots.quest_id as q_id,totalSpots.*,SUM(score) as score FROM completed_spots,spots,
                  (SELECT COUNT(spots.id) as totalSpots, spots.quest_id
                    FROM spots,
                    (SELECT completed_quests.quest_id
                    FROM completed_quests
                    WHERE completed_quests.user_id = #{user.id}) AS questPlaying
                  WHERE questPlaying.quest_id = spots.quest_id GROUP BY spots.quest_id) AS totalSpots
                WHERE completed_spots.spot_id = spots.id AND spots.quest_id = totalSpots.quest_id AND completed_spots.user_id = #{user.id} GROUP BY totalSpots.quest_id,totalSpots.totalSpots) AS total
              WHERE total.q_id = quests.id;"

        result = Quest.find_by_sql q
        result2 = Quest.find_by_sql q2

        if result.count == 0
          if result2.count == 0
            obj = { :name=> nil,
                    :score => 0,
                    :total_spots => 0,
                    :quest_id => nil,
                    :spots_done => 0
            }
            result.push obj
            render_success_message "No spots completed.",result
          else
            result2.each do |r|
              result.push r
            end
            render_success_message "Quest Info", result
          end

        else
          if result2.count != 0
            result2.each do |r|
              result.push r
            end
          end
          render_success_message "Quest Info", result
        end

      end

    else
      render_error_message "Error parsing message."
    end
  end

  def get_quest_info(data)

    if data.has_key?(:quest_id)
      quest = Quest.find(data[:quest_id])
      if data.has_key?(:email)
        user = User.find_by_email(data[:email])

        if quest.nil?
          render_success_message "No quest found", {}
        elsif user.nil?
          render_success_message "No user found", {}
        else

          q = "SELECT challenges.id as chg_id, comp.score FROM challenges,
                (SELECT completed_spots.score,completed_spots.spot_id FROM completed_spots,
                  (SELECT id as spot_id FROM spots,
                    (SELECT id as quest_id FROM quests,
                      (SELECT id as user_id FROM users
                      WHERE users.id = #{user.id}) AS u
                    WHERE quests.id = #{quest.id}) AS q
                  WHERE spots.quest_id = q.quest_id) AS s
                WHERE s.spot_id = completed_spots.spot_id AND completed_spots.user_id = #{user.id}) AS comp
              WHERE comp.spot_id = challenges.spot_id"

          result = Challenge.find_by_sql q

          # Para actualizar e nao criar um novo rate
          if result.count == 0
            obj = { :chg_id => nil,
                    :completed => 0,
                    :score => 0
            }
            result.push obj
            render_success_message "No spots completed.",result
          else
            result.each do |r|
                r[:completed] = 1
            end
            render_success_message "Quest Info", result

          end
        end
      else
        render_error_message "Error parsing message."
    end
    else
      render_error_message "Error parsing message."
    end
  end



  def set_playing_quest(data)
    if data.has_key?(:quest_id)
      quest = Quest.find(data[:quest_id])
      if data.has_key?(:email)
        user = User.find_by_email(data[:email])

          if quest.nil?
            render_success_message "No quest found", {}
          elsif user.nil?
            render_success_message "No user found", {}
          else

            obj = { :user_id => user.id,
                    :quest_id => quest.id,
            }

            q = " SELECT *
                FROM users_playing_quests
                WHERE user_id = #{user.id} AND quest_id = #{quest.id};"

            result = UsersPlayingQuest.find_by_sql q

            # Para actualizar e nao criar um novo rate
            if result.count == 0
              @playing_quest = UsersPlayingQuest.new(obj)
              if @playing_quest.save
                render_success_message "Playing Quest saved", {}
              else
                render_error_message "Error saving Playing Quest"
              end
            else
              result.each do |r|
                @playing_quest = UsersPlayingQuest.find(r[:id])
                if @playing_quest.update_attributes(obj)
                  render_success_message "Playing Quest saved", {}
                else
                  render_error_message "Error saving Playing Quest"
                end
              end
            end

          end
      else
        render_error_message "Error parsing message."
      end
    else
      render_error_message "Error parsing message."
    end
  end

  def set_quest_completed(data)
    if data.has_key?(:quest_id)
      quest = Quest.find(data[:quest_id])
      if data.has_key?(:email)
        user = User.find_by_email(data[:email])
        if data.has_key?(:score)
          if quest.nil?
          render_success_message "No quest found", {}
          elsif user.nil?
            render_success_message "No user found", {}
          else

          obj = { :user_id => user.id,
                  :quest_id => quest.id,
                  :score => data[:score],
          }

          q = " SELECT *
                FROM completed_quests
                WHERE user_id = #{user.id} AND quest_id = #{quest.id};"

          result = CompletedQuest.find_by_sql q

          # Para actualizar e nao criar um novo rate
          if result.count == 0
            @quest_completed = CompletedQuest.new(obj)
            if @quest_completed.save
              @playing_quest = UsersPlayingQuest.find_by_quest_id(quest.id)

              @playing_quest.destroy
              render_success_message "Completed Quest saved", {}
            else
              render_error_message "Error saving Completed Quest"
            end
          else
            result.each do |r|
              @quest_completed = CompletedQuest.find(r[:id])
              if @quest_completed.update_attributes(obj)
                @playing_quest = UsersPlayingQuest.find_by_quest_id(quest.id)

                render_success_message "Completed Quest saved", {}
              else
                render_error_message "Error saving Completed Quest"
              end
            end
          end


          end
        else
          render_error_message "Error parsing message."
        end
      else
        render_error_message "Error parsing message."
      end
    else
      render_error_message "Error parsing message."
    end
  end


  def quest_by_name(data)
    if data.has_key?(:name)
      name = data[:name]
      q = " SELECT quests.id, quests.name,quests.is_linear
            FROM quests
            WHERE lower(name) LIKE lower('%#{name}%');"

      result = Rate.find_by_sql q

      if result.count == 0
         obj = {:quests_id => nil,
                     :name => nil,
                      :is_linear => nil,
                      :rating => 0,
                      :category => nil}
         result.push obj
        render_success_message "Quest found", result
      else
        result.each do |r|
          if r[:is_linear] == "f"
            r[:is_linear] = "false"
          else
            r[:is_linear] = "true"
          end

          q2 = "  SELECT avg(stars)
                  FROM rates
                  WHERE rates.rateable_id = #{r.id};"
          result2 = Rate.find_by_sql q2
          result2.each do |r2|
            r[:rating] = r2[:avg]
          end
        end
        render_success_message "Quest found", result
      end
    else
      render_error_message "Error parsing message."
    end
  end


  def get_rating(data)
    if data.has_key?(:quest_id)
      quest = Quest.find(data[:quest_id])
      if data.has_key?(:email)
        user = User.find_by_email(data[:email])

          if quest.nil?
            render_success_message "No quest found", {}
          elsif user.nil?
            render_success_message "No user found", {}
          else

            q = " SELECT *
                  FROM rates
                  WHERE rates.rater_id = #{user.id} AND rates.rateable_id = #{quest.id};"

            result = Rate.find_by_sql q

            q2 = "  SELECT avg(stars)
                  FROM rates
                  WHERE rates.rateable_id = #{quest.id};"
            result2 = Rate.find_by_sql q2
            obj = {}

            # Para actualizar e nao criar um novo rate
            if result.count == 0
                render_error_message "Not rated"
            else
              result.each do |r|
                result2.each do |r2|
                  obj = {:rating => r[:stars],
                         :avg => r2[:avg]
                  }
                end
                  render_success_message "Rating", obj
              end
            end
          end
      else
        render_error_message "Error parsing message."
      end
    else
      render_error_message "Error parsing message."
    end
  end

  def rating(data)
    if data.has_key?(:quest_id)
      quest = Quest.find(data[:quest_id])
      if data.has_key?(:email)
        user = User.find_by_email(data[:email])
        if data.has_key?(:rating)

          if quest.nil?
            render_success_message "No quest found", {}
          elsif user.nil?
            render_success_message "No user found", {}
          else
            obj = { :rater_id => user.id,
                     :rateable_id => quest.id,
                     :stars => data[:rating],
                     :rateable_type => 'Quest',
                     }

            q = " SELECT *
                  FROM rates
                  WHERE rates.rater_id = #{user.id} AND rates.rateable_id = #{quest.id};"

            result = Rate.find_by_sql q

            # Para actualizar e nao criar um novo rate
            if result.count == 0
              @rate = Rate.new(obj)
              if @rate.save
                render_success_message "Rate saved", {}
              else
                render_error_message "Error saving rate"
              end
            else
              result.each do |r|
                @rate = Rate.find(r[:id])
                if @rate.update_attributes(obj)
                  render_success_message "Rate saved", {}
                else
                  render_error_message "Error saving rate"
                end
              end
            end
          end
        else
          render_error_message "Error parsing message."
        end
      else
        render_error_message "Error parsing message."
      end
    else
      render_error_message "Error parsing message."
    end
  end

  def get_image(data)
    if data.has_key?(:id)
      if Quest.exists?(data[:id])
      quest = Quest.find(data[:id])
      if quest.nil?
        render_success_message "No quest found", {}
      else
        if quest.image.exists?
          data = { :image => quest.image.url(:android_image) }
          render_success_message "Quest Image", data
        else
          render_error_message "No quest image"
        end

        end
      else
        render_error_message "Wrong quest id."
      end
    else
      render_error_message "Error parsing message."
    end
  end

  def spots_by_quest(data)
    if data.has_key?(:id)
      if Quest.exists?(data[:id])
        quest = Quest.find(data[:id])
        if quest.nil?
          render_success_message "No quest found", {}
        else
          q = "SELECT spots.id, spots.description, spots.name, spots.sequence_order, spots.latitude, spots.longitude, spots.radius, spots.image_file_name, spots.image_updated_at, challenges.id AS challenge_id, challenges.challenge_type FROM spots LEFT JOIN challenges ON spots.id = challenges.spot_id WHERE spots.quest_id = #{data[:id]};"
          spot = Spot.find_by_sql q
          if spot.nil?
            render_success_message "No spots found", {}
          else
            array = Array.new
            spot.each do |s|
              aux = {}

              aux[:id] = s.id
              aux[:description] = s.description
              aux[:name] = s.name
              aux[:sequence_order] = s.sequence_order
              aux[:latitude] = s.latitude
              aux[:longitude] = s.longitude
              aux[:radius] = s.radius
              aux[:challenge_id] = s.challenge_id
              aux[:challenge_type] = s.challenge_type

              if s.image.exists?
                aux[:image] = s.image.url(:android_image)
                logger.debug "#{s.image.url(:android_image)}"
              else
                aux[:image] = nil
                logger.debug "No image to show"
              end
              array.push aux
            end
            render_success_message "Spots found", array
          end
        end
      else
        render_error_message "Wrong quest id."
      end
    else
      render_error_message "Error parsing message."
    end
  end

  def quests_by_coords(data)
    if data.has_key?(:latitude)
      latitude = data[:latitude]
      if data.has_key?(:longitude)
        longitude = data[:longitude]

        if data.has_key?(:radius)
          radius = data[:radius] / 1000
        else
          radius = 5
        end

        if data.has_key?(:limit)
          limit = data[:limit]
        else
          limit = 10
        end

        q = " SELECT quests.id, quests.name, quests.is_linear
              FROM quests,
              (
                        SELECT DISTINCT quest_id
                        FROM    (
                                  SELECT *,  (6371 * 2 * ATAN2(SQRT(POWER(SIN(RADIANS(#{latitude} - spots.latitude)/2), 2) + COS(RADIANS(#{latitude})) * COS(RADIANS(spots.latitude)) * POWER(SIN(RADIANS(#{longitude} - spots.longitude)/2),2)), SQRT(1 - POWER(SIN(RADIANS(#{latitude} - spots.latitude)/2), 2) + COS(RADIANS(#{latitude})) * COS(RADIANS(spots.latitude)) * POWER(SIN(RADIANS(#{longitude} - spots.longitude)/2),2)))) AS distance
                                  FROM spots
                                  ORDER BY distance
                                ) AS SEARCH
                        WHERE distance < #{radius}
                        LIMIT #{limit}
              ) AS result
              WHERE quests.id = result.quest_id AND quests.is_blocked IS FALSE;"

        result = Quest.find_by_sql q

        result.each do |r|
          q2 = "  SELECT avg(stars)
                  FROM rates
                  WHERE rates.rateable_id = #{r.id};"
          result2 = Rate.find_by_sql q2
          result2.each do |r2|
            r[:rating] = r2[:avg]
          end
        end

        render_success_message "Quests near location", result

      else
        render_error_message "Error parsing message."
      end
    else
      render_error_message "Error parsing message."
    end
  end
end
