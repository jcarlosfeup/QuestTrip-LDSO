class SessionsController < ApplicationController

  def new
    if signed_in?
      redirect_to current_user
    end
  end

  def create
    user = User.load_authentication(params[:session][:email].downcase)
    if user && user.authenticate(params[:session][:password])
      sign_in user
      redirect_back_or user
    else
      flash[:error] = "Invalid email/password combination"
      redirect_to signin_path
    end
  end

  def update

    fb_app_id = 110619985774776
    fb_secret = 'ca811b84161f68a7420ad9d16588a3d0'

    # Then in your /sessions/update
    @user = User.find(params[:id])
    unless @user.access_token
      access_token_hash = MiniFB.oauth_access_token(fb_app_id, "https://questtrip.herokuapp.com/sessionUpdate/" + params[:id] + "/" + params[:quest_id], fb_secret, params[:code])
      @access_token = access_token_hash["access_token"]
      @response_hash = MiniFB.get(@access_token, "me", :type=>nil)
      @user.update_attribute(:facebook_id, @response_hash["uid"])
      @user.update_attribute(:access_token, @access_token)
      @user.save
    end
    redirect_to new_quest_facebook_post_path
  end

  def destroy
    sign_out
    redirect_to root_url
  end
end
