class StaticPagesController < ApplicationController
  def home
    q = "SELECT quests.* FROM quests,suggested_quests WHERE quests.id = suggested_quests.quest_id;"
    @suggestedQuests = Quest.find_by_sql q

    q = "SELECT quests.*,AVG(stars) as average FROM quests,rates WHERE rates.rateable_id = quests.id GROUP BY quests.id ORDER BY average DESC;"
    @bestRatedQuests = Quest.find_by_sql q

    q = "SELECT quests.*,COUNT(*) as soma FROM quests,completed_quests,users_playing_quests WHERE quests.id = completed_quests.quest_id OR quests.id = users_playing_quests.quest_id GROUP BY quests.id ORDER BY soma DESC;"
    @mostPlayed = Quest.find_by_sql q

    q = "SELECT * FROM quests ORDER BY id DESC;"
    @newestQuests = Quest.find_by_sql q
  end

  def help
  end

  def about
  end
end
