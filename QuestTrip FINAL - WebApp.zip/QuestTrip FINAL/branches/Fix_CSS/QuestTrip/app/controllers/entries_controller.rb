class EntriesController < ApplicationController
  before_filter :signed_in_user, :can_be_shown, :only => [:show]
  before_filter :signed_in_user, :album_owner, :only => [:new, :create]
  before_filter :signed_in_user, :correct_user, :only => [:edit, :update]

  def show
    @entry = Entry.find(params[:id])
    @data = {}
    @data[:is_owner] = is_owner
  end

  def new
    @entry = Entry.new
  end

  def create
    @album = Album.find(params[:album_id])
    @entry = Entry.new(params[:entry])

    if @album.entries << @entry
      flash[:success] = "Photo added!"
      redirect_to  user_album_path(:user_id => params[:user_id], :id => params[:album_id])
    else
      render 'new'
    end
  end

  def edit
    @entry = Entry.find(params[:id])
  end

  def update
    @entry = Entry.find(params[:id])
    @entry.update_attributes(params[:entry])
    if @entry.save
      flash[:success] = "Changes saved!"
      redirect_to  user_album_entry_path(:user_id => params[:user_id], :album_id => params[:album_id], :id => params[:id])
    else
      render 'edit'
    end
  end

  def destroy
    @entry = Entry.find(params[:id])
    if @entry.destroy
      flash[:success] = "Photo removed!"
    else
      flash[:error] = "Photo not removed!"
    end
    redirect_to user_album_path(:user_id => params[:user_id], :id => params[:album_id])
  end

private

  def can_be_shown
    if Album.find(params[:album_id]).is_private?
      unless current_user.albums.exists?(params[:album_id])
        unless current_user.is_admin?
          redirect_to root_path
        end
      end
    end
  end

  def album_owner
    unless current_user.albums.exists?(params[:album_id])
      redirect_to root_path
    end
  end

  def correct_user
    redirect_to root_path unless is_owner
  end

  def is_owner
    if current_user.albums.exists?(params[:album_id])
      album = current_user.albums.find(params[:album_id])
      if album.entries.exists?(params[:id])
        return true
      end
    end
    false
  end
end
