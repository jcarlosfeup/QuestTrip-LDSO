class WishlistsController < ApplicationController
  before_filter :signed_in_user, :only => [:show]

  def show
    @wishlist = Wishlist.find(params[:id])
    @data = {}
    @data[:is_owner] = is_owner
  end

private

  def is_owner
    if current_user.wishlist.id.to_s() == params[:id]
      return true
    end
    false
  end
end