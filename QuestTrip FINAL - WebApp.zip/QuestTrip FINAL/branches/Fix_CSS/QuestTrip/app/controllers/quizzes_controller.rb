class QuizzesController < ApplicationController
  before_filter :signed_in_user, :spot_owner, :only => [:new, :create]
  before_filter :signed_in_user, :correct_user, :only => [:edit, :update]

  def new
    if signed_in?
      @challenge = Quiz.new
      render 'challenges/new'
    else
      render signin_path
    end
  end

  def create
    # Pick the quiz data
    @challenge = Quiz.new(params[:quiz])
    @challenge.valid?
    if @challenge.errors.size == 1 and @challenge.errors.messages.has_key?(:spot_id)
      @spot = Spot.find(params[:spot_id])
      if (@spot.challenge = @challenge)
        flash[:success] = "Quiz created with success"
      else
        flash[:error] = "Quiz not created!"
      end
      redirect_to quest_path(:id => params[:quest_id])
    else
      render 'challenges/new'
    end
  end

  def edit
    @challenge = Quiz.find(params[:id])
    render 'challenges/edit'
  end

  def update
    @spot = Spot.find(params[:spot_id])
    if @spot.challenge.update_attributes(params[:quiz])
      flash[:success] = "Challenge Updated!"
      redirect_to quest_path(:id => params[:quest_id])
    else
      @challenge = @spot.challenge
      render 'challenges/edit'
    end
  end

private

  def spot_owner
    if current_user.quests.exists?(params[:quest_id])
      quest = Quest.find(params[:quest_id])
      if quest.spots.exists?(params[:spot_id])
        return true
      end
    end
    redirect_to quest_path(:id => params[:quest_id])
  end

  def correct_user
    redirect_to quest_path(:id => params[:quest_id]) unless is_owner
  end

  def is_owner
    if current_user.quests.exists?(params[:quest_id])
      quest = Quest.find(params[:quest_id])
      if quest.spots.exists?(params[:spot_id])
        challenge = Spot.find(params[:spot_id]).challenge
        if challenge.id.to_s() == params[:id]
          return true
        end
      end
    end
    false
  end
end
