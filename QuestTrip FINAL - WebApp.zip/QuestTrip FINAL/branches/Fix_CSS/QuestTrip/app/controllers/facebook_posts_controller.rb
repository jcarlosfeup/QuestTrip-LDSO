class FacebookPostsController < ApplicationController
  before_filter :signed_in_user, :only => [:new, :create]

  def new
    @facebook_post = FacebookPost.new
  end

  def create

    @message = params[:message]

    @quest = Quest.find(params[:quest_id])
    @id = current_user.facebook_id
    @type = "feed" # required here

    @response_hash = MiniFB.post(current_user.access_token, @id, :type=>@type, :params => {:message => @message, :name => @quest.name, :description => @quest.description, :picture => "http://i46.tinypic.com/wik6yo.pngl", :link => "https://questtrip.herokuapp.com/" + @quest.id.to_s})

    redirect_to quest_path(:id => params[:quest_id])
  end

end
