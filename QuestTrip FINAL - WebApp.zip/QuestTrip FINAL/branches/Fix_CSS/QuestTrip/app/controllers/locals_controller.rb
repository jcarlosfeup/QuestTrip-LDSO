class LocalsController < ApplicationController
  before_filter :signed_in_user, :only => [:show]
  before_filter :signed_in_user, :wishlist_owner, :only => [:new, :create]
  before_filter :signed_in_user, :correct_user, :only => [:edit, :update, :destroy]

  def show
    @local = Local.find(params[:id])
  end

  def new
    @local = Local.new
  end

  def create
    @wishlist = Wishlist.find(params[:wishlist_id])
    @local = Local.new(params[:local])

    if @wishlist.locals << @local
      flash[:success] = "Local was successfully created"
    else
      flash[:error] = "Error!"
    end

    redirect_to user_wishlist_path(:user_id => params[:user_id], :id => params[:wishlist_id])
  end

  def edit
    @local = Local.find(params[:id])
  end

  def update
    @local = Local.find(params[:id])
    @local.update_attributes(params[:local])
    if @local.save
      flash[:success] = "Local was successfully updated"
      redirect_to user_wishlist_path(:user_id => params[:user_id], :id => params[:wishlist_id])
    else
      render 'edit'
    end
  end

  def destroy
    @wishlist = Wishlist.find(params[:wishlist_id])
    @local = Local.find(params[:id])

    if @local.destroy
      flash[:success] = "Local was successfully deleted"
    else
      flash[:error] = "Local was not deleted!"
    end
    redirect_to user_wishlist_path(:user_id => params[:user_id], :id => params[:wishlist_id])
  end

private

  def is_owner
    if current_user.wishlist.id.to_s() == params[:wishlist_id]
      unless current_user.wishlist.locals.exists?(params[:id])
        return false
      end
    end
    true
  end

  def correct_user
    redirect_to root_path unless is_owner
  end

  def wishlist_owner
    unless current_user.wishlist.id.to_s() == params[:wishlist_id]
      redirect_to root_path
    end
  end

end