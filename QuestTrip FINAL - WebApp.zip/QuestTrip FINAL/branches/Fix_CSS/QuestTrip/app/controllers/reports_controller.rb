class ReportsController < ApplicationController
  before_filter :signed_in_user, :only => [:show, :new, :create]
  before_filter :signed_in_user, :has_admin_permissions, :only => [:index, :edit, :update, :destroy]

  def index
    @reports = Report.all
  end

  def show
    @report = Report.find(params[:id])
  end

  def new
    @report = Report.new
  end

  def edit
    @report = Report.find(params[:id])
  end

  def create
    @report = Report.new(params[:report])
    @report.save

    if @report.save
      redirect_to @report, :notice => 'Report was successfully created.'
    else
      render :action => "new"
    end
  end

  def update
    @report = Report.find(params[:id])
    if @report.update_attributes(params[:report])
      redirect_to @report, :notice => 'Report was successfully updated.'
    else
      render :action => "edit"
    end
  end

  def destroy
    @report = Report.find(params[:id])
    @report.destroy
    redirect_to reports_path
  end

end
