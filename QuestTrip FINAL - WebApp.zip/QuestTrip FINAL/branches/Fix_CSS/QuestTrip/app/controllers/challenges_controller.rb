class ChallengesController < ApplicationController
  before_filter :signed_in_user, :only => [:show]
  before_filter :signed_in_user, :has_permissions, :only => [:destroy]

  def show
    if signed_in?
      @challenge = Challenge.find(params[:id])

      @flags = {}
      @flags[:can_edit] = is_owner
      @flags[:can_destroy] = is_admin || is_owner

      if @challenge.challenge_type == "Visit"
        render 'visits/_challenge_info'
      elsif @challenge.challenge_type == "Quiz"
        render 'quizzes/_challenge_info'
      elsif @challenge.challenge_type == "Puzzle"
        render 'puzzles/_challenge_info'
      end
    else
      redirect_to signin_path
    end
  end

  def destroy
    if signed_in?
      @challenge = Challenge.destroy(params[:id])
      redirect_to quest_path(params[:quest_id])
    else
      redirect_to signin_path
    end
  end

private

  def has_permissions
    unless current_user.is_admin?
      unless is_owner
        redirect_to root_path
      end
    end
  end

  def is_owner
    if current_user.quests.exists?(params[:quest_id])
      quest = Quest.find(params[:quest_id])
      if quest.spots.exists?(params[:spot_id])
        challenge = Spot.find(params[:spot_id]).challenge
        if challenge.id.to_s() == params[:id]
          return true
        end
      end
    end
    false
  end
end