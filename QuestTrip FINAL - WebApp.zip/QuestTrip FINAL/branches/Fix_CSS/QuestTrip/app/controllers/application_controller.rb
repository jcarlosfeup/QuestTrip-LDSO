class ApplicationController < ActionController::Base
  protect_from_forgery
  include SessionsHelper # By default all the helpers are available in the views but not in the controllers

private
  # Check if the user is logged in
  def signed_in_user
    unless signed_in?
      store_location
      flash[:notice] = "Please sign in."
      redirect_to signin_url
    end
  end

  # Check if the current user has admin permissions
  def has_admin_permissions
    unless is_admin
      redirect_to root_path
    end
  end

  # Check if the current user is admin
  def is_admin
    current_user.is_admin ? true : false
  end

  def render_success_message(info_message, data)
    render :status => 200, :json => { :success => true,
                                :info => info_message,
                                :data => data }
  end

  def render_error_message(info_message)
    render :status => 200, :json => { :success => false,
                                :info => info_message,
                                :data => {} }
  end

end
