/**
 * Created with JetBrains RubyMine.
 * User: eduardo
 * Date: 12/30/12
 * Time: 3:11 AM
 * To change this template use File | Settings | File Templates.
 */
var used_coord_fields = {};
var unused_coord_fields = [];
var markersArrayHash = {};
var fieldsCount = 0;

$(function() {
    var maxFieldsCount = 8,
        $addLink = $('a.add_nested_fields');

    function toggleAddLink() {
        $addLink.toggle(fieldsCount <= maxFieldsCount)
    }

    $(document).on('nested:fieldAdded', function(event) {
        fieldsCount += 1;
        add_dynamic_coord_field(fieldsCount-1, event.field.find(".sequence_order"), event.field.find(".latitude"), event.field.find(".longitude"));
        toggleAddLink();
    });

    $(document).on('nested:fieldRemoved', function(event) {
        fieldsCount -= 1;
        removeMarker(event.field.find(".sequence_order").val());
        toggleAddLink();
    });

    // count existing nested fields after page was loaded
    fieldsCount = $('form .fields').length;
    toggleAddLink();
});

// On page load verifies the existence of spots and add them to the list
function findExistingFields() {
    var lat_fields = $(".latitude");
    var lon_fields = $(".longitude");
    var seq_fields = $(".sequence_order");

    for (var i=0; i<lat_fields.length; i++) {
        add_static_coord_field(i, seq_fields[i], lat_fields[i], lon_fields[i]);
    }
}

// Adds all the existing fields when the page is loaded
function add_static_coord_field(sequence_order, seq_field, lat_field, lon_field) {
    var coord = {};
    coord.id = [lat_field.value, lon_field.value];
    seq_field.value = sequence_order;
    coord.sequence_order = seq_field;
    coord.lat = lat_field;
    coord.lon = lon_field;
    coord.dynamic = false;
    used_coord_fields[coord.id] = coord;
}

// When fields to add a new spot are created call this method to save them for input
function add_dynamic_coord_field(sequence_order, seq_field, lat_field, lon_field) {
    var coord = {};
    // No id yet
    seq_field.val(sequence_order);
    coord.sequence_order = seq_field;
    coord.lat = lat_field;
    coord.lon = lon_field;
    coord.dynamic = true;
    unused_coord_fields.push(coord);
}

// Get the object with unused coords
function getUnusedCoords() {
    if (unused_coord_fields.length > 0) {
        return unused_coord_fields.pop();
    }
    return null;
}

// Update the marker information
function updateMarker(id, latLng) {
    // Check if the coord is a static field or a dynamic field
    if (used_coord_fields[id].dynamic) {
        used_coord_fields[id].lat.val(latLng.lat());
        used_coord_fields[id].lon.val(latLng.lng());
    }
    else {
        used_coord_fields[id].lat.value = latLng.lat();
        used_coord_fields[id].lon.value = latLng.lng();
    }
}

// Add a marker to the first available place
function addMarker(latLng) {
    // Pick an unused coord
    var coord = getUnusedCoords();
    if (coord != null) {
        // Add the id
        coord.id = [latLng.lat(), latLng.lng()];
        // Add the coord object to the used_coord_fields
        used_coord_fields[coord.id] = coord;
        // Add the latitude and longitude to the fields
        if (used_coord_fields[coord.id].dynamic) {
            used_coord_fields[coord.id].lat.val(latLng.lat());
            used_coord_fields[coord.id].lon.val(latLng.lng());
        }
        else {
            used_coord_fields[coord.id].lat.value = latLng.lat();
            used_coord_fields[coord.id].lon.value = latLng.lng();
        }

        // Create the marker
        var marker = new google.maps.Marker({
            position: latLng,
            map: Gmaps.map.serviceObject,
            draggable: true,
            id: coord["id"]
        });

        // Add the marker to the hash map
        markersArrayHash[coord["id"]] = marker;

        // Listen to drag & drop
        google.maps.event.addListener(marker, 'dragend', function() {
            updateMarker(this.id, this.getPosition());
        });
    }
}

// Remove a single marker
function removeMarker(sequenceOrder) {
    for (var i = 0; i<Gmaps.map.markers.length; i++) {
        var marker = Gmaps.map.markers[i].serviceObject;

        var marker_seq_order;
        if (used_coord_fields[marker.id].dynamic) {
            marker_seq_order = used_coord_fields[marker.id].sequence_order.val();
        }
        else {
            marker_seq_order = used_coord_fields[marker.id].sequence_order.value;
        }

        if (marker_seq_order == sequenceOrder)
            Gmaps.map.clearMarker(Gmaps.map.markers[i]);
    }
}


// Add info window
/*
 var infoWindow = new google.maps.InfoWindow({
 content: '<div class="popup">' +
 '<h2>Spot</h2>' +
 '<p>Latitude</p>' +
 '</div>'
 });
 infoWindow.open(Gmaps.map.serviceObject, marker);
 */