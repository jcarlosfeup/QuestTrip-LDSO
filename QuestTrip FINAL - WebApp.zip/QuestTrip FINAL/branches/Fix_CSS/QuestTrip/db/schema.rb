# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20121227144637) do

  create_table "albums", :force => true do |t|
    t.integer  "user_id",                                             :null => false
    t.string   "name",               :limit => 35,                    :null => false
    t.string   "description"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.string   "image_file_name"
    t.datetime "image_updated_at"
    t.boolean  "is_private",                       :default => false, :null => false
    t.boolean  "is_blocked",                       :default => false, :null => false
  end

  create_table "challenges", :force => true do |t|
    t.integer  "spot_id",                                      :null => false
    t.string   "challenge_type"
    t.boolean  "is_blocked",                :default => false, :null => false
    t.string   "description"
    t.string   "question"
    t.string   "puzzle_image_content_type"
    t.integer  "puzzle_image_file_size"
    t.string   "puzzle_image_file_name"
    t.datetime "puzzle_image_updated_at"
    t.integer  "vertical_split",            :default => 4
    t.integer  "horizontal_split",          :default => 4
  end

  create_table "comments", :force => true do |t|
    t.integer "topic_id",                :null => false
    t.integer "user_id",                 :null => false
    t.string  "answer",   :limit => 100, :null => false
  end

  create_table "completed_quests", :force => true do |t|
    t.integer "user_id",  :null => false
    t.integer "quest_id", :null => false
    t.integer "score",    :null => false
  end

  create_table "completed_spots", :force => true do |t|
    t.integer "user_id",                :null => false
    t.integer "spot_id",                :null => false
    t.integer "score",   :default => 0, :null => false
  end

  create_table "entries", :force => true do |t|
    t.integer  "album_id",                          :null => false
    t.string   "photo_content_type"
    t.integer  "photo_file_size"
    t.string   "photo_file_name"
    t.datetime "photo_updated_at"
    t.string   "subtitle",           :limit => 150
  end

  create_table "locals", :force => true do |t|
    t.integer "wishlist_id",                :null => false
    t.string  "name",                       :null => false
    t.string  "coordinates", :limit => nil
    t.decimal "latitude",                   :null => false
    t.decimal "longitude",                  :null => false
  end

  create_table "quests", :force => true do |t|
    t.integer  "user_id",                                              :null => false
    t.string   "name",               :limit => 50,                     :null => false
    t.string   "description",        :limit => 250,                    :null => false
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.string   "image_file_name"
    t.datetime "image_updated_at"
    t.boolean  "is_blocked",                        :default => false, :null => false
    t.boolean  "is_linear",                         :default => false, :null => false
  end

  create_table "quiz_options", :force => true do |t|
    t.integer "challenge_id",                    :null => false
    t.string  "option",                          :null => false
    t.boolean "is_correct",   :default => false, :null => false
  end

  create_table "rates", :force => true do |t|
    t.integer  "rater_id"
    t.integer  "rateable_id"
    t.string   "rateable_type"
    t.integer  "stars",         :null => false
    t.string   "dimension"
    t.datetime "created_at",    :null => false
    t.datetime "updated_at",    :null => false
  end

  add_index "rates", ["rateable_id", "rateable_type"], :name => "index_rates_on_rateable_id_and_rateable_type"
  add_index "rates", ["rater_id"], :name => "index_rates_on_rater_id"

  create_table "reports", :force => true do |t|
    t.string  "subject"
    t.text    "report_text"
    t.integer "user_id",     :null => false
  end

  create_table "spots", :force => true do |t|
    t.integer  "quest_id",                                          :null => false
    t.string   "name",               :limit => 30,                  :null => false
    t.string   "description",        :limit => 75,                  :null => false
    t.string   "coordinates",        :limit => nil,                 :null => false
    t.decimal  "latitude",                                          :null => false
    t.decimal  "longitude",                                         :null => false
    t.integer  "sequence_order",                                    :null => false
    t.integer  "radius",                            :default => 10, :null => false
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.string   "image_file_name"
    t.datetime "image_updated_at"
  end

  create_table "suggested_quests", :force => true do |t|
    t.integer "quest_id", :null => false
  end

  create_table "topics", :force => true do |t|
    t.integer "quest_id",                :null => false
    t.integer "user_id",                 :null => false
    t.string  "question", :limit => 100, :null => false
  end

  create_table "users", :force => true do |t|
    t.string   "email",              :limit => 60,                    :null => false
    t.string   "username",           :limit => 20
    t.string   "password_digest",                                     :null => false
    t.string   "remember_token"
    t.string   "first_name",         :limit => 40
    t.string   "last_name",          :limit => 40
    t.boolean  "is_admin",                         :default => false, :null => false
    t.boolean  "is_blocked",                       :default => false, :null => false
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.string   "image_file_name"
    t.datetime "image_updated_at"
    t.string   "facebook_id"
    t.string   "access_token"
  end

  add_index "users", ["email"], :name => "index_users_on_email", :unique => true
  add_index "users", ["remember_token"], :name => "index_users_on_remember_token", :unique => true
  add_index "users", ["username"], :name => "index_users_on_username", :unique => true

  create_table "users_playing_quests", :force => true do |t|
    t.integer "user_id",  :null => false
    t.integer "quest_id", :null => false
  end

  create_table "wishlists", :force => true do |t|
    t.integer "user_id",                       :null => false
    t.boolean "is_private", :default => false, :null => false
  end

  add_foreign_key "albums", "users", :name => "albums_user_id_fk"

  add_foreign_key "challenges", "spots", :name => "challenges_spot_id_fk"

  add_foreign_key "comments", "topics", :name => "comments_topic_id_fk"
  add_foreign_key "comments", "users", :name => "comments_user_id_fk"

  add_foreign_key "completed_quests", "quests", :name => "completed_quests_quest_id_fk"
  add_foreign_key "completed_quests", "users", :name => "completed_quests_user_id_fk"

  add_foreign_key "completed_spots", "spots", :name => "completed_spots_spot_id_fk"
  add_foreign_key "completed_spots", "users", :name => "completed_spots_user_id_fk"

  add_foreign_key "entries", "albums", :name => "entries_album_id_fk"

  add_foreign_key "locals", "wishlists", :name => "locals_wishlist_id_fk"

  add_foreign_key "quests", "users", :name => "quests_user_id_fk"

  add_foreign_key "quiz_options", "challenges", :name => "quiz_options_challenge_id_fk"

  add_foreign_key "reports", "users", :name => "reports_user_id_fk"

  add_foreign_key "spots", "quests", :name => "spots_quest_id_fk"

  add_foreign_key "suggested_quests", "quests", :name => "suggested_quests_quest_id_fk"

  add_foreign_key "topics", "quests", :name => "topics_quest_id_fk"
  add_foreign_key "topics", "users", :name => "topics_user_id_fk"

  add_foreign_key "users_playing_quests", "quests", :name => "users_playing_quests_quest_id_fk"
  add_foreign_key "users_playing_quests", "users", :name => "users_playing_quests_user_id_fk"

  add_foreign_key "wishlists", "users", :name => "wishlists_user_id_fk"

end
