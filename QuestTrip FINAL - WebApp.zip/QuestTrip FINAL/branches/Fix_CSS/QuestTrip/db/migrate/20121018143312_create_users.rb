class CreateUsers < ActiveRecord::Migration
  def self.up
    create_table :users do |t|
      t.string :email, :limit => 60, :null => false
      t.string :username, :limit => 20, :null => true
      t.string :password_digest, :null => false
      t.string :remember_token, :null => true
      t.string :first_name, :limit => 40 , :null => true
      t.string :last_name, :limit => 40 , :null => true
      t.boolean :is_admin, :default => false, :null => false
      t.boolean :is_blocked, :default => false, :null => false
      t.has_attached_file :image
      t.string :facebook_id, :limit => 255, :null => true
      t.string :access_token, :limit => 255, :null => true
    end
    add_index :users, :email, :unique => true
    add_index :users, :username, :unique => true
    add_index :users, :remember_token, :unique => true
  end

  def self.down
    drop_attached_file :users, :image
    drop_table :users
  end
end

