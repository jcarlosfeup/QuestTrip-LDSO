class CreateQuizOptions < ActiveRecord::Migration
  def self.up
    create_table :quiz_options do |t|
      t.integer :challenge_id, :references => :challenges, :null => false
      t.string :option, :null => false
      t.boolean :is_correct, :null => false, :default => false
    end
    add_foreign_key :quiz_options, :challenges
  end

  def self.down
    remove_foreign_key :quiz_options, :challenges
    drop_table :quiz_options
  end
end