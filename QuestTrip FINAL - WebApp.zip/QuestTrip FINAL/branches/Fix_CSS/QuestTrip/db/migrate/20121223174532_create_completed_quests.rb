class CreateCompletedQuests < ActiveRecord::Migration
  def self.up
    create_table :completed_quests do |t|
      t.integer :user_id, :references => :users, :null => false
      t.integer :quest_id, :references => :quests, :null => false
      t.integer :score, :null => false
    end
    add_foreign_key :completed_quests, :users
    add_foreign_key :completed_quests, :quests
  end

  def self.down
    remove_foreign_key :completed_quests, :users
    remove_foreign_key :completed_quests, :quests
    drop_table :completed_quests
  end
end
