class CreateAlbums < ActiveRecord::Migration
  def self.up
    create_table :albums do |t|
      t.integer :user_id, :references => :users, :null => false
      t.string :name, :null => false, :limit => 35
      t.string :description
      t.has_attached_file :image
      t.boolean :is_private, :null => false, :default => false
      t.boolean :is_blocked, :default => false, :null => false
    end
    add_foreign_key :albums, :users
  end

  def self.down
    drop_attached_file :albums, :image
    remove_foreign_key :albums, :users
    drop_table :albums
  end
end
