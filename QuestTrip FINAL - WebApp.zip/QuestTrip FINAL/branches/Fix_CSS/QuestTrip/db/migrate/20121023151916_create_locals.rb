class CreateLocals < ActiveRecord::Migration
  def self.up
    create_table :locals do |t|
      t.integer :wishlist_id, :references => :wishlists, :null => false
      t.string :name, :null => false
      t.column :coordinates, :point
      t.column :latitude, 'decimal', :null => false
      t.column :longitude, 'decimal',:null => false
    end
    add_foreign_key :locals, :wishlists
  end

  def self.down
    remove_foreign_key :locals, :wishlists
    drop_table :locals
  end
end
