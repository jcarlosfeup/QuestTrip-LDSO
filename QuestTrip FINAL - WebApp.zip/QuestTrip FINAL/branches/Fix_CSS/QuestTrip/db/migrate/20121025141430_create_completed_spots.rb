class CreateCompletedSpots < ActiveRecord::Migration
  def self.up
    create_table :completed_spots do |t|
      t.integer :user_id, :references => :users, :null => false
      t.integer :spot_id, :references => :spots, :null => false
      t.integer :score, :null => false, :default => 0
    end
    add_foreign_key :completed_spots, :users
    add_foreign_key :completed_spots, :spots
  end

  def self.down
    remove_foreign_key :completed_spots, :users
    remove_foreign_key :completed_spots, :spots
    drop_table :completed_spots
  end
end
