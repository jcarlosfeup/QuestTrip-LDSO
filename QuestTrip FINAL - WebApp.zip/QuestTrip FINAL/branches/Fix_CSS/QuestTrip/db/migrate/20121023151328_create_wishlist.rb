class CreateWishlist < ActiveRecord::Migration
  def self.up
    create_table :wishlists do |t|
      t.integer :user_id, :references => :users, :null => false
      t.boolean :is_private, :null => false, :default => false
    end
    add_foreign_key :wishlists, :users
  end

  def self.down
    remove_foreign_key :wishlists, :users
    drop_table :wishlists
  end
end
