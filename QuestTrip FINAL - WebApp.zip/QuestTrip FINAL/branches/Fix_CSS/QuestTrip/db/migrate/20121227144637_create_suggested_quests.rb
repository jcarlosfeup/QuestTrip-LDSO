class CreateSuggestedQuests < ActiveRecord::Migration
  def self.up
    create_table :suggested_quests do |t|

      t.integer :quest_id, :references => :quests, :null => false
    end
    add_foreign_key :suggested_quests, :quests
  end

  def self.down
    remove_foreign_key :suggested_quests, :quests
    drop_table :suggested_quests
  end
end

