class CreateSpots < ActiveRecord::Migration
  def self.up
    create_table :spots do |t|
      t.integer :quest_id, :references => :quests, :null => false
      t.string :name, :limit => 30, :null => false
      t.string :description, :limit => 75, :null => false
      t.column :coordinates, :point, :null => false
      t.column :latitude, 'decimal', :null => false
      t.column :longitude, 'decimal',:null => false
      t.integer :sequence_order, :null => false
      t.integer :radius, :null => false, :default => 10
      t.has_attached_file :image
    end
    add_foreign_key :spots, :quests
  end

  def self.down
    drop_attached_file :spots, :image
    remove_foreign_key :spots, :quests
    drop_table :spots
  end
end