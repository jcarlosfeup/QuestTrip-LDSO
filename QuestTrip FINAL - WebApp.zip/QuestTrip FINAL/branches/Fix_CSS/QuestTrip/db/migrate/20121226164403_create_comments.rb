class CreateComments < ActiveRecord::Migration
  def self.up
    create_table :comments do |t|
      t.integer :topic_id, :references => :topics , :null => false
      t.integer :user_id, :references => :users, :null => false
      t.string :answer, :limit => 100, :null => false
    end
    add_foreign_key :comments, :topics
    add_foreign_key :comments, :users
  end

  def self.down
    remove_foreign_key :comments, :topics
    remove_foreign_key :comments, :users
    drop_table :comments
  end
end