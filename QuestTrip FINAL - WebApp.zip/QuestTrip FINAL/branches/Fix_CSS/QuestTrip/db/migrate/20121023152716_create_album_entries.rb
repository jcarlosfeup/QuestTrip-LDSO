class CreateAlbumEntries < ActiveRecord::Migration
  def self.up
    create_table :entries do |t|
      t.integer :album_id, :references => :albums, :null => false
      t.has_attached_file :photo
      t.string :subtitle, :limit => 150
    end
    add_foreign_key :entries, :albums
  end

  def self.down
    drop_attached_file :entries, :photo
    remove_foreign_key :entries, :albums
    drop_table :entries
  end
end
