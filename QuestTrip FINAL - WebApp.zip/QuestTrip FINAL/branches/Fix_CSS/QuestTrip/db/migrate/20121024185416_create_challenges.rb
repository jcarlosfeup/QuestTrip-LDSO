class CreateChallenges < ActiveRecord::Migration
  def self.up
    create_table :challenges do |t|
      t.integer :spot_id, :references => :spots, :null => false
      t.string :challenge_type
      t.boolean :is_blocked, :default => false, :null => false
      # If the challenge is just visit the spot
      t.string :description
      # If the challenge is a quiz
      t.string :question
      # If the challenge is a puzzle
      t.has_attached_file :puzzle_image
      t.integer :vertical_split, :default => 4
      t.integer :horizontal_split, :default => 4
    end
    add_foreign_key :challenges, :spots
  end

  def self.down
    drop_attached_file :challenges, :puzzle_image
    remove_foreign_key :challenges, :spots
    drop_table :challenges
  end
end
