class CreateTopics < ActiveRecord::Migration
  def self.up
    create_table :topics do |t|
      t.integer :quest_id, :references => :quests, :null => false
      t.integer :user_id, :references => :users, :null => false
      t.string :question, :limit => 100, :null => false
    end
    add_foreign_key :topics, :quests
    add_foreign_key :topics, :users
  end

  def self.down
    remove_foreign_key :topics, :quests
    remove_foreign_key :topics, :users
    drop_table :topics
  end
end
