class CreateUsersPlayingQuests < ActiveRecord::Migration
  def up
    create_table :users_playing_quests do |t|
      t.integer :user_id, :references => :users, :null => false
      t.integer :quest_id, :references => :quests, :null => false
    end
    add_foreign_key :users_playing_quests, :users
    add_foreign_key :users_playing_quests, :quests
  end

  def down
    remove_foreign_key :users_playing_quests, :users
    remove_foreign_key :users_playing_quests, :quests
    drop_table :users_playing_quests
  end
end
