class CreateQuests < ActiveRecord::Migration
  def self.up
    create_table :quests do |t|
      t.integer :user_id, :references => :users, :null => false
      t.string :name, :limit => 50, :null => false
      t.string :description, :limit => 250, :null => false
      t.has_attached_file :image
      t.boolean :is_blocked, :default => false, :null => false
      t.boolean :is_linear, :default => false, :null => false
    end
    add_foreign_key :quests, :users
  end

  def self.down
    drop_attached_file :quests, :image
    remove_foreign_key :quests, :users
    drop_table :quests
  end
end
