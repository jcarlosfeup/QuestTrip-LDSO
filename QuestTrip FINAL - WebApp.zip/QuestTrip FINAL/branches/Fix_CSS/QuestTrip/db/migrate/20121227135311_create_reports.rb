class CreateReports < ActiveRecord::Migration
  def self.up
    create_table :reports do |t|
      t.string :subject
      t.text :report_text
      t.integer :user_id, :references => :users, :null => false
    end
    add_foreign_key :reports, :users
  end



  def self.down
    remove_foreign_key :reports, :users
    drop_table :reports
  end
end
