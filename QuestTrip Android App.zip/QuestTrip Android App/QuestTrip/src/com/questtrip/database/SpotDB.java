package com.questtrip.database;

public class SpotDB {

	private int id;
	private String chg_id = null; // Na DB guarda o Challenge ID
	private int completed = 0;
	private int score = 0;
	
	public SpotDB(int id, String spot_id, int completed,int score) {
		this.id = id;
		this.chg_id = spot_id;
		this.completed = completed;
		this.setScore(score);
	}
		
	public SpotDB(String spot_id, int completed,int score) {
		this.chg_id = spot_id;
		this.completed = completed;
		this.setScore(score);
	}

	public SpotDB() {
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSpot_id() {
		return chg_id;
	}
	public void setSpot_id(String chg_id) {
		this.chg_id = chg_id;
	}
	public int getCompleted() {
		return completed;
	}
	public void setCompleted(int completed) {
		this.completed = completed;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	
}
