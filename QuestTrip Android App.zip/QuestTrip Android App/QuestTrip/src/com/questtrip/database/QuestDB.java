/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.database;

import com.questtrip.models.challenge.Challenge;
import com.questtrip.models.challenge.Question_Option;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author Filipe Rodrigues
 *
 */
public class QuestDB implements Parcelable {
	
	private int id;
	private String quest_id, name;
	private int total_spots, spots_done;
	private int score = 0;
	private int hiScore = 0;
	
	public QuestDB(int id, String quest_id, String name, int totalSpots, int spotsDone, int score, int hiScore) {
		this.id = id;
		this.quest_id = quest_id;
		this.setName(name);
		this.setTotalSpots(totalSpots);
		this.setCompleteSpots(spotsDone);
		this.score = score;
		this.setHiScore(hiScore);
	}
		
	public QuestDB(String quest_id, String name, int totalSpots, int spotsDone, int score, int hiScore) {
		this.quest_id = quest_id;
		this.setName(name);
		this.setTotalSpots(totalSpots);
		this.setCompleteSpots(spotsDone);
		this.score = score;
		this.setHiScore(hiScore);
	}
	
	public QuestDB(){
	}
	
	private QuestDB(Parcel source) {
		this.id = source.readInt();
		this.quest_id = source.readString();
		this.name = source.readString();
		this.total_spots = source.readInt();
		this.spots_done = source.readInt();
		this.score = source.readInt();
		this.hiScore = source.readInt();
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getQuest_id() {
		return quest_id;
	}
	public void setQuest_id(String quest_id) {
		this.quest_id = quest_id;
	}
	public boolean isCompleted() {
		return getTotalSpots() == getCompleteSpots();
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public int getTotalSpots() {
		return total_spots;
	}

	public void setTotalSpots(int totalSpots) {
		this.total_spots = totalSpots;
	}

	public int getCompleteSpots() {
		return spots_done;
	}

	public void setCompleteSpots(int spotsDone) {
		this.spots_done = spotsDone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getHiScore() {
		return hiScore;
	}

	public void setHiScore(int hiScore) {
		this.hiScore = hiScore;
	}

	/* (non-Javadoc)
	 * @see android.os.Parcelable#describeContents()
	 */
	@Override
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see android.os.Parcelable#writeToParcel(android.os.Parcel, int)
	 */
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(this.id);
		dest.writeString(this.quest_id);
		dest.writeString(this.name);
		dest.writeInt(this.total_spots);
		dest.writeInt(this.spots_done);
		dest.writeInt(this.score);
		dest.writeInt(this.hiScore);
	}
	
	/**
	 * Regenerate the object. All Parcelables must have a CREATOR that implements this two methods
	 */
	public static final Parcelable.Creator<QuestDB> CREATOR = new Parcelable.Creator<QuestDB>() {

		@Override
		public QuestDB createFromParcel(Parcel source) {
			return new QuestDB(source);
		}

		@Override
		public QuestDB[] newArray(int size) {
			return new QuestDB[size];
		}
		
	};

}
