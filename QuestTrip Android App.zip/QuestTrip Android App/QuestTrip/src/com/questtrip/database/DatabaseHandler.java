package com.questtrip.database;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHandler extends SQLiteOpenHelper {
	 
    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;
 
    // Database Name
    private static final String DATABASE_NAME = "questtrip";
 
    // Spots table name
    private static final String TABLE_SPOTS = "spots";
    // Spots Table Columns names
    private static final String KEY_ID = "id";
    private static final String KEY_SPOT_ID = "spot_id";
    private static final String KEY_COMPLETED = "completed";
    private static final String KEY_SCORE = "score";
    
    // Quests table name
    private static final String TABLE_QUESTS = "quests";
    // Spots Table Columns names
    private static final String KEY_QUEST_ID = "quest_id";
    private static final String KEY_NAME_QUEST_ID = "name";
    private static final String KEY_QUEST_TOTAL_SPOTS = "total_spots";
    private static final String KEY_QUEST_COMPLETE_SPOTS = "complete_spots";
    private static final String KEY_QUEST_HISCORE = "hiscore";
 
    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
 
    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_SPOTS_TABLE = "CREATE TABLE " + TABLE_SPOTS + "("
                + KEY_ID + " INTEGER PRIMARY KEY," 
        		+ KEY_SPOT_ID + " STRING UNIQUE,"
                + KEY_COMPLETED + " INTEGER," 
                + KEY_SCORE + " INTEGER"
        		+ ")";
        db.execSQL(CREATE_SPOTS_TABLE);
        
        String CREATE_QUESTS_TABLE = "CREATE TABLE " + TABLE_QUESTS + "("
                + KEY_ID + " INTEGER PRIMARY KEY," 
        		+ KEY_QUEST_ID + " STRING UNIQUE,"
        		+ KEY_NAME_QUEST_ID + " STRING UNIQUE,"
                + KEY_QUEST_TOTAL_SPOTS + " INTEGER," 
                + KEY_QUEST_COMPLETE_SPOTS + " INTEGER,"
                + KEY_SCORE + " INTEGER,"
                + KEY_QUEST_HISCORE + " INTEGER"
        		+ ")";
        db.execSQL(CREATE_QUESTS_TABLE);
    }
 
    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SPOTS);
        
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTS);
 
        // Create tables again
        onCreate(db);
    }
    
    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */
    
    public int addSpot(SpotDB spot) {
        SQLiteDatabase db = this.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(KEY_SPOT_ID, spot.getSpot_id()); 
        values.put(KEY_COMPLETED, spot.getCompleted()); 
        values.put(KEY_SCORE, spot.getScore()); 

        // Inserting Row
        if(getSpot(spot.getSpot_id()) == null){
	        db.insert(TABLE_SPOTS, null, values);
	        db.close();
	    	return 0;
        }
        else {
        	db.close();
        	return -1;
        }
    }
    
    public SpotDB getSpot(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
 
        Cursor cursor = db.query(TABLE_SPOTS, new String[] {KEY_ID,KEY_SPOT_ID, KEY_COMPLETED,KEY_SCORE}, KEY_SPOT_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        
        if (cursor.getCount() > 0){
            cursor.moveToFirst();
        }
        else {
        	return null;
        }
 
        SpotDB spot = new SpotDB(Integer.parseInt(cursor.getString(0)),cursor.getString(1), cursor.getInt(2), cursor.getInt(3));
        return spot;
    }
    
    public List<SpotDB> getAllSpots() {
        List<SpotDB> spotsList = new ArrayList<SpotDB>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_SPOTS;
 
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
 
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                SpotDB spot = new SpotDB();
                spot.setId(Integer.parseInt(cursor.getString(0)));
                spot.setSpot_id(cursor.getString(1));
                spot.setCompleted(cursor.getInt(2));
                spot.setScore(cursor.getInt(3));
                // Adding spot to list
                spotsList.add(spot);
            } while (cursor.moveToNext());
        }
 
        // return spot list
        return spotsList;
    }
    
    public int updateSpot(SpotDB spot) {
        SQLiteDatabase db = this.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(KEY_SPOT_ID, spot.getSpot_id());
        values.put(KEY_COMPLETED, spot.getCompleted());
        values.put(KEY_SCORE, spot.getScore());
 
        // updating row
        return db.update(TABLE_SPOTS, values, KEY_SPOT_ID + " = ?",
                new String[] { String.valueOf(spot.getSpot_id()) });
    }
    
    public void deleteSpot(SpotDB spot) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_SPOTS, KEY_ID + " = ?",
                new String[] { String.valueOf(spot.getId())});
        db.close();
    }
    
    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */
    
    public int addQuest(QuestDB quest) {
        SQLiteDatabase db = this.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(KEY_QUEST_ID, quest.getQuest_id()); 
        values.put(KEY_NAME_QUEST_ID, quest.getName());
        values.put(KEY_QUEST_TOTAL_SPOTS, quest.getTotalSpots()); 
        values.put(KEY_QUEST_COMPLETE_SPOTS, quest.getCompleteSpots()); 
        values.put(KEY_SCORE , quest.getScore()); 
        values.put(KEY_QUEST_HISCORE , quest.getHiScore()); 

        // Inserting Row
        if(getQuest(quest.getQuest_id()) == null){
	        db.insert(TABLE_QUESTS, null, values);
	        db.close();
	    	return 0;
        }
        else {
        	db.close();
        	return -1;
        }
    }
    
    public QuestDB getQuest(String id) {
        SQLiteDatabase db = this.getReadableDatabase();
 
        Cursor cursor = db.query(TABLE_QUESTS, new String[] {KEY_ID, KEY_QUEST_ID, KEY_NAME_QUEST_ID, KEY_QUEST_TOTAL_SPOTS, KEY_QUEST_COMPLETE_SPOTS, KEY_SCORE, KEY_QUEST_HISCORE}, KEY_QUEST_ID + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        
        if (cursor.getCount() > 0){
            cursor.moveToFirst();
        }
        else {
        	return null;
        }
 
        QuestDB quest = new QuestDB(Integer.parseInt(cursor.getString(0)),cursor.getString(1), cursor.getString(2), cursor.getInt(3), cursor.getInt(4), cursor.getInt(5), cursor.getInt(6));
        return quest;
    }
    
    public int updateQuest(QuestDB quest) {
        SQLiteDatabase db = this.getWritableDatabase();
 
        ContentValues values = new ContentValues();
        values.put(KEY_QUEST_ID, quest.getQuest_id()); 
        values.put(KEY_NAME_QUEST_ID, quest.getName()); 
        values.put(KEY_QUEST_TOTAL_SPOTS, quest.getTotalSpots()); 
        values.put(KEY_QUEST_COMPLETE_SPOTS, quest.getCompleteSpots()); 
        values.put(KEY_SCORE , quest.getScore()); 
        values.put(KEY_QUEST_HISCORE , quest.getHiScore()); 
 
        // updating row
        return db.update(TABLE_QUESTS, values, KEY_QUEST_ID + " = ?",
                new String[] { String.valueOf(quest.getQuest_id()) });
    }
    
    public void deleteQuest(QuestDB quest) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_QUESTS, KEY_ID + " = ?",
                new String[] { String.valueOf(quest.getId())});
        db.close();
    }
    
    
    public List<QuestDB> getAllQuests() {
        List<QuestDB> questsList = new ArrayList<QuestDB>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_QUESTS;
 
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
 
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                QuestDB quest = new QuestDB();
                quest.setId(Integer.parseInt(cursor.getString(0)));
                quest.setQuest_id(cursor.getString(1));
                quest.setName(cursor.getString(2));
                quest.setTotalSpots(cursor.getInt(3));
                quest.setCompleteSpots(cursor.getInt(4));
                quest.setScore(cursor.getInt(5));
                quest.setHiScore(cursor.getInt(6));
                // Adding spot to list
                questsList.add(quest);
            } while (cursor.moveToNext());
        }
 
        // return spot list
        return questsList;
    }
    
}