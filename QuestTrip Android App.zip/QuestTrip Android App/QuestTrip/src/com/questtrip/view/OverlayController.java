package com.questtrip.view;

import java.util.ArrayList;
import java.util.Vector;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.OverlayItem;
import com.questtrip.models.BoundingBox;
import com.questtrip.models.Spot;
import com.questtrip.models.variables.Variables;
import com.questtrip.puzzle.Choose_Game;


/**
 * Class que permite interac��o com os v�rios Spots colocados neste Overlay
 * 
 * @author Filipe Rodrigues
 *
 */
@SuppressWarnings("rawtypes")
public class OverlayController extends ItemizedOverlay {

	// Items utilizados no mapa
	private ArrayList<Spot> spots = new ArrayList<Spot>();
	

	Context mContext;

	public OverlayController(Drawable defaultMarker, Context context) {
		super(boundCenterBottom(defaultMarker));
		mContext = context;
	}

	/* Adiciona items ao array
	 * NOTA: Necess�rio chamar "populate()" ap�s adicionar item
	 */
	public void addOverlay(Spot overlay) {
		spots.add(overlay);
		populate();
	}


	/*
	 * Este m�todo � chamado com o "populate()"
	 * @see com.google.android.maps.ItemizedOverlay#createItem(int)
	 */
	@Override
	protected OverlayItem createItem(int i) {
		return spots.get(i);
	}

	/*
	 * Retorna o tamanho do Array de items
	 */
	@Override
	public int size() {
		return spots.size();
	}

	/*
	 * Este m�todo � chamado quando o utilizador toca no ecr�
	 */
	@Override
	protected boolean onTap(final int index) {

		//		Toast.makeText(mContext, mOverlays.get(index).getSnippet(), Toast.LENGTH_LONG).show();
		OverlayItem item = spots.get(index);
		AlertDialog.Builder dialog = new AlertDialog.Builder(mContext);
		dialog.setTitle(item.getTitle());
		dialog.setMessage(item.getSnippet() + "\n\n Lat = " + item.getPoint().getLatitudeE6() + " \n Long = " + item.getPoint().getLongitudeE6());

		// Cria bot�es se estiver dentro do raio e Challenge ainda n�o estiver completo
		if(spots.get(index).isStayingOnSpot() && !spots.get(index).getChallenge().isComplete()){
			dialog.setPositiveButton("Enter Challenge", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					callChallenge(index);
				}
			});
			dialog.setNegativeButton("Cancel", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
				}

			});
		}

		dialog.show();
		return true;
	}
	
	/**
	 * Permite lan�ar o Challenge
	 * @param index 
	 * @param 
	 */
	public void callChallenge(int index) {  
		
		if(spots.get(index).getChallenge().getChallengeType().equals(Variables.CHALLENGE_PUZZLE)){
			Intent intentPuzzle = new Intent(mContext, Choose_Game.class); 
			intentPuzzle.putExtra("chg", spots.get(index).getChallenge());
		//	intentPuzzle.putExtra("image", spots.get(index).getImage());
		//	intentPuzzle.putExtra("size", spots.get(index).getChallenge().getSize());
			intentPuzzle.putExtra("index", index); // Utilizado na QuestActivity para actualizar OverlayItem
			
			((QuestActivity) mContext).startActivityForResult(intentPuzzle, 1);
		}
		else{
			Intent intentChallenge = new Intent(mContext, Challenge_Display.class); 
			
			// Se houver Spot e o mesmo possuir um Challenge
		/*	if (spotIndex != -1 && overlayController.getSpots().get(spotIndex).hasChallenge()) {
				// Envia o Challenge
				intentChallenge.putExtra("chg", overlayController.getSpots().get(spotIndex).getChallenge());
			}
		*/	
			
			intentChallenge.putExtra("chg", spots.get(index).getChallenge());
			intentChallenge.putExtra("index", index); // Utilizado na QuestActivity para actualizar OverlayItem
			
			((QuestActivity) mContext).startActivityForResult(intentChallenge, 1);
		}
	}
	
	public void setSpotImage(Drawable d, int index){
		//Set the bounding for the drawable
		d.setBounds(0 - d.getIntrinsicWidth() / 2, 0 - d.getIntrinsicHeight(), d.getIntrinsicWidth() / 2, 0);
		spots.get(index).setMarker(d);
	}

	public ArrayList<Spot> getSpots() {
		return spots;
	}

}
