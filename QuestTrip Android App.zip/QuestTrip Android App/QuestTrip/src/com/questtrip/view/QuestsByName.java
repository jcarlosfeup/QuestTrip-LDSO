/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.view;

import java.util.List;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;
import com.questtrip.api.ApiQuestTrip;
import com.questtrip.api.responses.QuestsByCoordResponse;
import com.questtrip.api.responses.QuestsByNameResponse;
import com.questtrip.database.QuestDB;
import com.questtrip.models.Quest;
import com.questtrip.models.SearchSpotController;
import com.questtrip.models.listview.QuestAdapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

/**
 * @author Filipe Rodrigues
 *
 */
public class QuestsByName extends Activity {
	
	Context mContext = null;

	// Quests
	private ProgressDialog questsByNameProgressDialog = null;
	private ImageButton searchQuestsRefreshButton = null;
	private ListView searchQuestsListView = null;
	private QuestsByNameResponse questsByNameResponse = null;
	private TextView searchQuestsHeader = null;
	private TableLayout searchQuests = null;
	private TableLayout searchQuestsButton = null;
	
	private String searchName = "";
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.quests_by_name);

		mContext = this;
		
		
		Bundle info = getIntent().getExtras();
		this.searchName = info.getString("searchName");
		
		searchQuestsListView = (ListView) findViewById(R.id.listView);
		
		// Bot�o para efectuar refresh das "Quests"
		searchQuestsRefreshButton = (ImageButton) findViewById(R.id.refreshQuests);
		this.searchQuestsRefreshButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				questsByNameProgressDialog = ProgressDialog.show(mContext, "", "Loading Quests...", true, false);
				new questsByNameQueryAPITask().execute(searchName);
			}
		});


		// Bot�o que permite ocultar as "Near Quests"
		searchQuests = (TableLayout) findViewById(R.id.questsFound);
		searchQuestsHeader = (TextView) findViewById(R.id.questsFoundHeader);
		this.searchQuestsHeader.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if(searchQuests.isColumnCollapsed(0))
					searchQuests.setColumnCollapsed(0, false);
				else
					searchQuests.setColumnCollapsed(0, true);
			}
		});
		
		final AlertDialog getByName = createGetByNameDialog();
		searchQuestsButton = (TableLayout)findViewById(R.id.searchQuestsButton);
		searchQuestsButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				getByName.show();
			}
		});

		
		new questsByNameQueryAPITask().execute(searchName);
	}
	
	/**
	 * Fun��o que inicializa o Dialog de pesquisa de Quest por nome
	 * @return
	 */
	private AlertDialog createGetByNameDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		// use a custom View defined in xml
		final View view = LayoutInflater.from(this).inflate(R.layout.questbyname_dialog, null);
		builder.setTitle("Quest By Name");
		builder.setView(view);
		builder.setPositiveButton("Search", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				EditText nameToSearch = (EditText)view.findViewById(R.id.nameToSearch);
				searchName = nameToSearch.getText().toString();
				
				questsByNameProgressDialog = ProgressDialog.show(mContext, "", "Loading Quests...", true, false);
				new questsByNameQueryAPITask().execute(searchName);
			}

		});
		builder.setNegativeButton("Cancel", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {	        	
			}

		});
		final AlertDialog alertDialog = builder.create();
		return alertDialog;
	}

  
	/**
	 *  AsyncTask que acede � API e vai buscar as Quests pelo nome
	 *  
	 *  Gera uma QuestsByCoordResponse
	 */
	private class questsByNameQueryAPITask extends AsyncTask<String, Void, QuestsByNameResponse> {

		@Override
		protected QuestsByNameResponse doInBackground(String... params) {
			return ApiQuestTrip.questsByName(params[0]);
		}


		@Override
		protected void onPostExecute(final QuestsByNameResponse result) {
			super.onPostExecute(result);
			
			if (questsByNameProgressDialog != null) {
				questsByNameProgressDialog.dismiss();
			}

			if(result.getQuests() != null && result.getQuests().length > 0 && result.getQuests()[0].getID() != null){
				QuestAdapter adapter = new QuestAdapter(mContext,
						R.layout.nearquests_item_row, result.getQuests());

				searchQuestsListView = (ListView)findViewById(R.id.listView);
				searchQuestsListView.setAdapter(adapter);

				// Coloca o listener que invoca a QuestActivity
				searchQuestsListView.setOnItemClickListener(new OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position,
							long id) {
							startQuestActivity(result.getQuests()[position]);
					}
				});
			}
		}

	}
	
	/**
	 * M�todo que invoca uma QuestActivity
	 * @param quest
	 */
	private void startQuestActivity(Quest quest) {
		Intent questIntent = new Intent(this, QuestActivity.class);
		questIntent.putExtra("quest_id", quest.getID());
		questIntent.putExtra("name", quest.getName());
		questIntent.putExtra("category", quest.getCategory());
		questIntent.putExtra("rating", quest.getRating());
		questIntent.putExtra("is_linear", quest.isLinear());
		startActivity(questIntent);
	}


}
