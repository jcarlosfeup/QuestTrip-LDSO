package com.questtrip.view;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.questtrip.api.ApiQuestTrip;
import com.questtrip.api.responses.LoginResponse;
import com.questtrip.api.responses.QuestsByCoordResponse;
import com.questtrip.models.Quest;
import com.questtrip.models.Spot;
import com.questtrip.models.User;
import com.questtrip.models.application.LoggedUser;
import com.questtrip.models.listview.QuestAdapter;
import com.questtrip.view.QuestActivity.MyThreadRunner;
import com.questtrip.database.DatabaseHandler;
import com.questtrip.database.SpotDB;

/**
 * @author Filipe Rodrigues
 *
 */
public class MainActivity extends MapActivity implements LocationListener {

	// User
	private ImageButton login_button = null, nearQuestsRefreshButton = null, searchQuestsButton = null;
	private ProgressDialog loginProgressDialog = null, questsByCoordProgressDialog = null;
	private AlertDialog showLoggedUserInfo = null;
	private int sharedPreferencesMode = MODE_PRIVATE;
	private final String SHAREDPREFERENCES = "queesttrip_login";
	private TableLayout searchMapButton = null;
	private TableLayout questsByNameButton = null;

	// GPS_PROVIDER or NETWORK_PROVIDER
	String provider = LocationManager.GPS_PROVIDER;

	private double mLongitude = 0;
	private double mLatitude = 0;

	// Options
	public static boolean SHOW_MAP = false;
	private boolean changed_background_state = false;


	// Map
	private final int MAP_ZOOM = 15; // Zoom do background
	private MapView mapView;
	private MapController controller;
	LocationManager mLocationManager;
	Thread mThread; // Para fazer update da localiza��o em background


	// Mensagem enviada para o handler quando � necess�rio fazer update da localiza��o
	private static final boolean ENABLED_ONLY = false;
	protected static final int UPDATE_LOCATION = 1;

	// Near Quests - Necess�rio para utilizar ListView sem fazer extend de ListActivity
	Context mContext = null;

	// Quests
	private ListView nearQuestsListView = null;
	private QuestsByCoordResponse questsByCoordResponse = null;
	private TextView nearQuestsHeader = null;
	private TableLayout nearQuests = null;

	// Database
    public static DatabaseHandler db = null;


	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mContext = this;

		initMapView(); // Inicia o controlador de MapView
		initMyLocation(); // Inicia a localiza��o e controla o n�vel de zoom do mapa


		// Thread que actualiza a Localiza��o do GPS - para o background
		initializeLocationAndStartGpsThread();





		// *************** Interface ***************

		nearQuestsListView = (ListView) findViewById(R.id.listView);


		final AlertDialog alertDialog = createLoginDialog();


		// Bot�o de login
		login_button = (ImageButton) findViewById(R.id.login_button);
		this.login_button.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if(getLoggedUser() == null)
					alertDialog.show();
				else{
					showLoggedUserInfo.show();
				}
			}
		});

		// Bot�o para efectuar refresh das "Near Quests"
		nearQuestsRefreshButton = (ImageButton) findViewById(R.id.refreshQuestsByCoord);
		this.nearQuestsRefreshButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				questsByCoordProgressDialog = ProgressDialog.show(mContext, "", "Loading Quests...", true, false);
				new questsByCoordQueryAPITask().execute(Double.toString(mLongitude), Double.toString(mLatitude));
			}
		});


		// Bot�o que permite ocultar as "Near Quests"
		nearQuests = (TableLayout) findViewById(R.id.nearQuestsTable);
		nearQuestsHeader = (TextView) findViewById(R.id.nearQuestsHeader);
		this.nearQuestsHeader.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if(nearQuests.isColumnCollapsed(0))
					nearQuests.setColumnCollapsed(0, false);
				else
					nearQuests.setColumnCollapsed(0, true);
			}
		});
		
		
		// Bot�es que permitem lan�ar a Activity de pesquisa de Quests
		searchQuestsButton = (ImageButton) findViewById(R.id.search_quests);
		this.searchQuestsButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent searchQuests = new Intent(mContext, SearchQuests.class);
				startActivity(searchQuests);
			}
		});
		searchMapButton = (TableLayout) findViewById(R.id.searchMapButton);
		this.searchMapButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent searchQuests = new Intent(mContext, SearchQuests.class);
				startActivity(searchQuests);
			}
		});
		
		final AlertDialog getByName = createGetByNameDialog();
		// Bot�o que permite lancar a pesquisa por nome de Quests
		questsByNameButton = (TableLayout) findViewById(R.id.questsByNameButton);
		this.questsByNameButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				getByName.show();
			}
		});
		

		// Acede � API para verificar se as credenciais guardadas s�o v�lidas
		loadLoginState();

		// Inicia a BD
		db = new DatabaseHandler(this);
		/*Log.d("DB", "Reading all contacts..");
        List<SpotDB> spots = db.getAllSpots();       
        for (SpotDB s : spots) {
            String log = "Id: "+s.getId()+" ,Spot_id: " + s.getSpot_id() + " ,completed: " + s.getCompleted()  + " ,score: " + s.getScore();
        	Log.d("DB", log);
        }*/
	

		// Carrega automaticamente as "Near Quests"
		new questsByCoordQueryAPITask().execute(Double.toString(mLongitude), Double.toString(mLatitude));
	}
	
	
	
	/**
	 * Fun��o que inicializa o Dialog de pesquisa de Quest por nome
	 * @return
	 */
	private AlertDialog createGetByNameDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		// use a custom View defined in xml
		final View view = LayoutInflater.from(this).inflate(R.layout.questbyname_dialog, null);
		builder.setTitle("Quest By Name");
		builder.setView(view);
		builder.setPositiveButton("Search", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				EditText nameToSearch = (EditText)view.findViewById(R.id.nameToSearch);
				String name = nameToSearch.getText().toString();

				Intent questIntent = new Intent(mContext, QuestsByName.class);
				questIntent.putExtra("searchName", name);
				startActivity(questIntent);
			}

		});
		builder.setNegativeButton("Cancel", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {	        	
			}

		});
		final AlertDialog alertDialog = builder.create();
		return alertDialog;
	}



	/**
	 *  AsyncTask que acede � API e vai buscar as Quests pelas Coordenadas actuais
	 *  
	 *  Gera uma QuestsByCoordResponse
	 */
	private class questsByCoordQueryAPITask extends AsyncTask<String, Void, QuestsByCoordResponse> {

		@Override
		protected QuestsByCoordResponse doInBackground(String... params) {
			return ApiQuestTrip.questsByCoord(params[0], params[1]);
		}


		@Override
		protected void onPostExecute(QuestsByCoordResponse result) {
			super.onPostExecute(result);

			questsByCoordResponse = result;
			if (questsByCoordProgressDialog != null) {
				questsByCoordProgressDialog.dismiss();
			}

			if(questsByCoordResponse.getQuests() != null){
				QuestAdapter adapter = new QuestAdapter(mContext,
						R.layout.nearquests_item_row, questsByCoordResponse.getQuests());

				nearQuestsListView = (ListView)findViewById(R.id.listView);

				/*	       if(!nearQuestsHeaderView){ // S� coloca o header 1 vez
					        	nearQuestsHeaderView = true;
						        View header = (View)getLayoutInflater().inflate(R.layout.nearquests_header_row, null);
						        nearQuestsListView.addHeaderView(header); 
					        }
				 */        
				nearQuestsListView.setAdapter(adapter);

				// Coloca o listener que invoca a QuestActivity
				nearQuestsListView.setOnItemClickListener(new OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position,
							long id) {
							startQuestActivity(questsByCoordResponse.getQuests()[position]);
					}
				});
			}
		}

	}

	/**
	 * M�todo que invoca uma QuestActivity
	 * @param quest
	 */
	private void startQuestActivity(Quest quest) {
		Intent questIntent = new Intent(this, QuestActivity.class);
		questIntent.putExtra("quest_id", quest.getID());
		questIntent.putExtra("name", quest.getName());
		questIntent.putExtra("category", quest.getCategory());
		questIntent.putExtra("rating", quest.getRating());
		questIntent.putExtra("is_linear", quest.isLinear());
		startActivity(questIntent);
	}

	

	/**
	 * M�todo que faz load, para a view, dos dados de Utilizador 
	 * @return
	 */
	private void putLoggedUserInfo() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		// use a custom View defined in xml
		final View view = LayoutInflater.from(this).inflate(R.layout.show_logged_dialog, null);
		builder.setView(view);


		final ImageButton login_button = (ImageButton)findViewById(R.id.login_button);
		ImageView userImage = (ImageView)view.findViewById(R.id.userImage);
		TextView login = (TextView)view.findViewById(R.id.loginName);
		TextView username = (TextView)view.findViewById(R.id.username);
		TextView name = (TextView)view.findViewById(R.id.name);


		//Log.d("IMAGEM", loggedUser.getImageLink());

		// Se user tem imagem
		if(getLoggedUser().getImage() != null){ 
			userImage.setImageDrawable(getLoggedUser().getImage());
			login_button.setImageDrawable(getLoggedUser().getImage());
			login_button.setBackgroundResource(R.drawable.table_body_title);
		}
		else{
			Log.d("NO IMAGE", "NO IMAGE");
			login_button.setImageResource(R.drawable.questtriplogo);
		}
		// Preenche os outros campos do dialog
		login.setText(getLoggedUser().getLogin());
		username.setText(getLoggedUser().getUsername());
		name.setText(getLoggedUser().getName());

		builder.setPositiveButton("Ok", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
			}

		});
		builder.setNeutralButton("Private Area", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				Intent privateArea = new Intent(mContext, PrivateArea.class);
				startActivity(privateArea);
			}
		});
		builder.setNegativeButton("Logout", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				setLoggedUser(null);
				login_button.setImageResource(R.drawable.login_icon);
				login_button.setBackgroundColor(Color.TRANSPARENT);

				// Apaga Shared Preferences
				SharedPreferences preferences = getSharedPreferences(SHAREDPREFERENCES, sharedPreferencesMode);
				preferences.edit().remove("loggedState").commit();
			}

		});
		showLoggedUserInfo = builder.create();

	}


	/**
	 * Fun��o que inicializa o Dialog customizado para login
	 * @return
	 */
	private AlertDialog createLoginDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		// use a custom View defined in xml
		final View view = LayoutInflater.from(this).inflate(R.layout.login_dialog, null);
		builder.setView(view);
		builder.setPositiveButton("Login", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				EditText editlogin = (EditText)view.findViewById(R.id.login);
				String login = editlogin.getText().toString();

				EditText editpass = (EditText)view.findViewById(R.id.pass);
				String pass = editpass.getText().toString();

				startProgressDialog();

				new loginQueryAPITask().execute(login, pass);
			}

		});
		builder.setNegativeButton("Cancel", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {	        	
			}

		});
		final AlertDialog alertDialog = builder.create();
		return alertDialog;
	}

	class DownloadUserImageAndFillData extends AsyncTask<User, Void, LoggedUser> {

	    protected LoggedUser doInBackground(User... user) {
	    	LoggedUser tempLogin = null;
	        try {
				tempLogin = new LoggedUser();
				tempLogin.fillLoggedUser(user[0].getLogin(),
						user[0].getUsername(),
						user[0].getFirstName(),
						user[0].getLastName(),
						user[0].getImageLink(),
						user[0].getLoginToken());
				tempLogin.loadImage(); // Download da imagem
				tempLogin.setPassword(user[0].getPassword());
				
				saveLoginSetting(user[0].getLogin(), user[0].getPassword());
				
				setLoggedUser(tempLogin);
	        } catch (Exception e) {
	            return null;
	        }
			return tempLogin;
	    }

	    // Save dos dados e preenchimento das estruturas
	    protected void onPostExecute(LoggedUser user) {
			
			putLoggedUserInfo(); // Carrega informa��o do Utilizador 
			showLoginResult(true);
			saveLoginSetting(getLoggedUser().getLogin(), getLoggedUser().getPassword());
	    }
	 }

	/**
	 *  AsyncTask que acede � API e verifica as credenciais de login
	 */
	private class loginQueryAPITask extends AsyncTask<String, Void, LoginResponse> {

		@Override
		protected LoginResponse doInBackground(String... params) {
			return ApiQuestTrip.login(params[0], params[1]);
		}


		@Override
		protected void onPostExecute(LoginResponse result) {
			super.onPostExecute(result);

			if (loginProgressDialog != null) {
				loginProgressDialog.dismiss();
			}

			if(result.getLoginStat()){ // Utilizador com login feito
			/*	result.getUser().loadImage();
				loggedUser = result.getUser();
				putLoggedUserInfo(); // Carrega informa��o do Utilizador 
				showLoginResult(true);
				saveLoginSetting(loggedUser.getLogin(), loggedUser.getPassword());
			*/
				new DownloadUserImageAndFillData().execute(result.getUser());
			}
			else{
				showLoginResult(false);
			}
		}

	}

	/**
	 * M�todo que permite guardar o login do Utilizador nas preferencias da app
	 * @param name
	 * @param value
	 */
	protected void saveLoginSetting(String name, String pass)
	{
		SharedPreferences  mySharedPreferences ; mySharedPreferences=getSharedPreferences(SHAREDPREFERENCES, sharedPreferencesMode);


		// retrieve an editor to modify the shared preferences
		SharedPreferences.Editor editor = mySharedPreferences.edit();

		/* now store your primitive type values */
		editor.putBoolean("loggedState", true);
		editor.putString("login", name);
		editor.putString("pass", pass);

		//save the changes that you made
		editor.commit();
	}

	/**
	 * M�todo que permite efectuar load das credenciais do Utilizador
	 */
	protected void loadLoginState(){
		SharedPreferences  mySharedPreferences ; mySharedPreferences=getSharedPreferences(SHAREDPREFERENCES, sharedPreferencesMode);
		String login = "", password = "";

		boolean loggedState = mySharedPreferences.getBoolean("loggedState", false);

		if(loggedState){
			Log.d("LOGGING", "IN");
			login = mySharedPreferences.getString("login", "");
			password = mySharedPreferences.getString("pass", "");


			LoginResponse result = ApiQuestTrip.login(login, password);
			if(result.getLoginStat()){ // Utilizador com login feito
				// result.getUser().loadImage();
				
				LoggedUser tempLogin = new LoggedUser();
				tempLogin.fillLoggedUser(result.getUser().getLogin(),
						result.getUser().getUsername(),
						result.getUser().getFirstName(),
						result.getUser().getLastName(),
						result.getUser().getImageLink(),
						result.getUser().getLoginToken());
				tempLogin.loadImage();
				
				setLoggedUser(tempLogin);
				
				putLoggedUserInfo(); // Carrega informa��o do Utilizador 
				saveLoginSetting(result.getUser().getLogin(), result.getUser().getPassword());
			}
			else{
				showLoginResult(false);
			}
		}
	}

	/**
	 * M�todo que visualiza o resultado de login
	 * @param boolean
	 */
	private void showLoginResult(boolean b) {
		if(b){
			//new AlertDialog.Builder(this).setMessage("Login was successful!").show();
			Toast.makeText(this.getBaseContext(), "Login was successful!", Toast.LENGTH_SHORT).show();
		}
		else{
			//new AlertDialog.Builder(this).setMessage("Oops... Something went wrong, please try again.").show();
			Toast.makeText(this.getBaseContext(), "Oops... Something went wrong while checking credentials. Please try to login.", Toast.LENGTH_SHORT).show();
		}
	}

	/**
	 * Start Dialog 
	 */
	private void startProgressDialog() {
		this.loginProgressDialog = ProgressDialog.show(this, "", "Authenticating User...", true, false);
	}	



	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main_menu, menu);
		return true;
	}

	/**
	 * Options Menu
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.launch_options: 

			Intent optionsIntent = new Intent(this, Options_Menu.class);
			startActivity(optionsIntent);

			// Lan�a Dummy Quest	
			/*	Intent questIntent = new Intent(this, QuestActivity.class);
				questIntent.putExtra("quest_id", "1");
				questIntent.putExtra("name", "Dummy Quest");
				questIntent.putExtra("category", "Cenas");
				startActivity(questIntent);
			 */	
			return true;
		}

		return super.onOptionsItemSelected(item);
	}

	private void initMapView() {
		mapView = (MapView) findViewById(R.id.mapview);
		//mapView.setBuiltInZoomControls(true);
		//mapView.setSatellite(false);
		controller = mapView.getController();
	}

	private void initMyLocation() {
		final MyLocationOverlay overlay = new MyLocationOverlay(this, mapView);
		overlay.enableMyLocation();
		//  overlay.enableCompass(); // does not work in emulator
		overlay.runOnFirstFix(new Runnable() {
			public void run() {
				// Zoom in to current location
				controller.setZoom(MAP_ZOOM);
				controller.animateTo(overlay.getMyLocation());
			}
		});
		mapView.getOverlays().add(overlay);
	}

	/**
	 * Sets our location to the last known location and start 
	 *  a separate thread to update GPS location.
	 */
	private void initializeLocationAndStartGpsThread() {
		mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		List<String> providers = mLocationManager.getProviders(ENABLED_ONLY);
		Log.i("Providers", "Enabled providers = " + providers.toString());
		String provider = mLocationManager.getBestProvider(new Criteria(),ENABLED_ONLY);
		Log.i("Best Provider", "Best provider = " + provider);

		setCurrentGpsLocation(null);   
		mThread = new Thread(new MyThreadRunner());
		mThread.start();
	}


	/**
	 * Handles updates in the background.
	 */
	class MyThreadRunner implements Runnable {
		// @Override
		public void run() {
			while (!Thread.currentThread().isInterrupted()) {


				// Trata de actualizar o background
				if(SHOW_MAP != changed_background_state){

					runOnUiThread(new Runnable() {
						public void run() {
							if(SHOW_MAP){
								mapView.setVisibility(View.VISIBLE);
							}
							else{
								mapView.setVisibility(View.INVISIBLE);
							}
						}
					});

					changed_background_state = SHOW_MAP;
				}

				Message m = Message.obtain();
				m.what = 0;
				MainActivity.this.updateHandler.sendMessage(m);
				try {
					Thread.sleep(5);
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
				}
			}
		}
	}

	/**
	 * Sends a message to the update handler with either the current location or 
	 *  the last known location. 
	 * @param location is either null or the current location
	 */
	private void setCurrentGpsLocation(Location location) {
		//	String bestProvider = "";
		if (location == null) {
			mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
			mLocationManager.requestLocationUpdates(
					LocationManager.GPS_PROVIDER, 30000, 0, this); // Every 30000 msecs	
			location = mLocationManager.getLastKnownLocation(provider); 

			if(location == null)
				Toast.makeText(this.getBaseContext(), "UNABLE TO TRACK GPS LOCATION", Toast.LENGTH_SHORT).show();

		}
		try {
			mLongitude = location.getLongitude();
			mLatitude = location.getLatitude();
			//			Log.i(TAG, "<long,lat> = <" + mLongitude + "," + mLatitude);
			Message msg = Message.obtain();
			msg.what = UPDATE_LOCATION;
			MainActivity.this.updateHandler.sendMessage(msg);
		} catch (NullPointerException e) {
			Toast.makeText(this.getBaseContext(), "NULL POINTER IN LOCATION", Toast.LENGTH_SHORT).show();
			//	Log.i("LOCATION NULL", "Null pointer exception " + mLongitude + "," + mLatitude);
		}

	}


	/**
	 * Handles GPS updates.  
	 * Source: Android tutorials
	 * @see http://www.androidph.com/2009/02/app-10-beer-radar.html
	 */
	Handler updateHandler = new Handler() {
		/** Gets called on every message that is received */
		// @Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case UPDATE_LOCATION: {
				//Log.i("UPDATE LOC", "Updated location = " + mLatitude + " " + mLongitude);
				// Actualiza a minha posi��o actual
				GeoPoint point = new GeoPoint((int)(mLatitude * 1E6), (int)(mLongitude * 1E6));
				controller.animateTo(point);

				break;
			}
			}
			super.handleMessage(msg);
		}
	};

	/**
	 * Invoked by the location service when phone's location changes.
	 */
	public void onLocationChanged(Location newLocation) {
		setCurrentGpsLocation(newLocation);  	
	}

	/**
	 * Resets the GPS location whenever the provider is enabled.
	 */
	public void onProviderEnabled(String provider) {
		setCurrentGpsLocation(null);  	
	}
	/**
	 * Resets the GPS location whenever the provider is disabled.
	 */
	public void onProviderDisabled(String provider) {
		Toast.makeText(this.getBaseContext(), "GPS DISABLED", Toast.LENGTH_SHORT).show();
		setCurrentGpsLocation(null);  	
	}
	/**
	 * Resets the GPS location whenever the provider status changes. We
	 * don't care about the details.
	 */
	public void onStatusChanged(String provider, int status, Bundle extras) {
		setCurrentGpsLocation(null);  	
	}

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override 
	public void onResume() {
		mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 1, this);
		super.onResume();
	}

	@Override
	public void onPause() {
		mLocationManager.removeUpdates(this);
		super.onPause();
	}



	public LoggedUser getLoggedUser() {
		return LoggedUser.getLoggedUser();
	}

	public void setLoggedUser(LoggedUser loggedUser) {
		LoggedUser.setLoggedUser(loggedUser);
	}


}
