package com.questtrip.view;

import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;
import com.questtrip.api.ApiQuestTrip;
import com.questtrip.api.responses.QuestsByCoordResponse;
import com.questtrip.api.responses.SpotsByQuestResponse;
import com.questtrip.models.BoundingBox;
import com.questtrip.models.Quest;
import com.questtrip.models.SearchSpotController;
import com.questtrip.models.Spot;
import com.questtrip.models.challenge.Challenge;
import com.questtrip.models.challenge.Question_Option;
import com.questtrip.models.listview.QuestAdapter;


/** 
 * Class onde � tratado todo o ciclo de jogo - Quest
 * 
 * @author Filipe Rodrigues
 *
 */
public class SearchQuests extends MapActivity {
	/** *TODO*
	 * 
	 * Implementar visualiza��o de login
	 */
	
	
	
	// GPS_PROVIDER or NETWORK_PROVIDER
	String provider = LocationManager.GPS_PROVIDER;
	
	// Map
	private MapView mapView;
	private MapController controller;
	LocationManager mLocationManager;
//	Thread mThread; // Para fazer update da localiza��o em background

	private double mLongitude = 0;
	private double mLatitude = 0;
	
	// Mensagem enviada para o handler quando � necess�rio fazer update da localiza��o
	private static final boolean ENABLED_ONLY = false;
	protected static final int UPDATE_LOCATION = 1;
	
	// Near Quests - Necess�rio para utilizar ListView sem fazer extend de ListActivity
	Context mContext = null;

	// Quests
	private ProgressDialog questsByCoordProgressDialog = null;
	private ImageButton searchQuestsRefreshButton = null;
	private ListView searchQuestsListView = null;
	private QuestsByCoordResponse questsByCoordResponse = null;
	private TextView searchQuestsHeader = null;
	private TableLayout searchQuests = null;
	private TableLayout searchQuestsButton = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.search_quests);

		mContext = this;

		initMapView();
		initMyLocation();
		
		initializeLocationAndStartGpsThread();
		
		// *************** Interface ***************
		showLocation(28426365, 77320393);
		
		searchQuestsListView = (ListView) findViewById(R.id.listView);
		
		// Bot�o para efectuar refresh das "Quests near Point"
		searchQuestsRefreshButton = (ImageButton) findViewById(R.id.refreshQuestsByCoord);
		this.searchQuestsRefreshButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				questsByCoordProgressDialog = ProgressDialog.show(mContext, "", "Loading Quests...", true, false);
				new questsByCoordQueryAPITask().execute(Double.toString(mLongitude), Double.toString(mLatitude));
			}
		});


		// Bot�o que permite ocultar as "Near Quests"
		searchQuests = (TableLayout) findViewById(R.id.questsFound);
		searchQuestsHeader = (TextView) findViewById(R.id.questsFoundHeader);
		this.searchQuestsHeader.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if(searchQuests.isColumnCollapsed(0))
					searchQuests.setColumnCollapsed(0, false);
				else
					searchQuests.setColumnCollapsed(0, true);
			}
		});
		
		searchQuestsButton = (TableLayout)findViewById(R.id.searchQuestsButton);
		searchQuestsButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				questsByCoordProgressDialog = ProgressDialog.show(mContext, "", "Loading Quests...", true, false);
				new questsByCoordQueryAPITask().execute(Double.toString(mLongitude), Double.toString(mLatitude));
			}
		});
	}

    // Handles Taps on the Google Map
    Handler h = new Handler(){
        // Invoked by the method onTap()
        // in the class CurrentLocationOverlay
        @Override
            public void handleMessage(Message msg) {
            Bundle data = msg.getData();
 
            // Getting the Latitude of the location
            int latitude = data.getInt("latitude");
            // Getting the Longitude of the location
            int longitude = data.getInt("longitude");
  
            Toast.makeText(mContext, "Latitude: " + latitude / 1E6 + "\nLongitude: " + longitude / 1E6, Toast.LENGTH_SHORT).show();

            mLongitude = longitude / 1E6;
            mLatitude = latitude / 1E6;
            
            // Show the location in the Google Map
            showLocation(latitude,longitude);
        }
    };
    
    private void showLocation(int latitude, int longitude){
 
        // Setting Zoom Controls
//        mapView.setBuiltInZoomControls(true);
 
        // Getting the MapController
        MapController mapController = mapView.getController();
 
        // Getting Overlays of the map
        List<Overlay> overlays = mapView.getOverlays();
 
        // Getting Drawable object corresponding to a resource image
        Drawable drawable = getResources().getDrawable(R.drawable.map_select_marker);
 
        // Creating an ItemizedOverlay
        SearchSpotController locationOverlay = new SearchSpotController(drawable,h);
 
        // Getting the MapController
        MapController mc = mapView.getController();
 
        // Creating an instance of GeoPoint, to display in Google Map
        GeoPoint p = new GeoPoint(
                              latitude,
                              longitude
                         );
 
        // Locating the point in the Google Map
        mc.animateTo(p);
 
        // Creating an OverlayItem to mark the point
        OverlayItem overlayItem = new OverlayItem(p, "Item", "Item");
 
        // Adding the OverlayItem in the LocationOverlay
        locationOverlay.addOverlay(overlayItem);
 
        // Clearing the overlays
        overlays.clear();
 
        // Adding locationOverlay to the overlay
        overlays.add(locationOverlay);
 
        // Redraws the map
        mapView.invalidate();
    }
	


	
	private void initMapView() {
		mapView = (MapView) findViewById(R.id.mapview);
		mapView.setBuiltInZoomControls(true);
		//mapView.setSatellite(false);
		controller = mapView.getController();
	}

	private void initMyLocation() {
	      final MyLocationOverlay overlay = new MyLocationOverlay(this, mapView);
	      overlay.enableMyLocation();
	      overlay.enableCompass(); // does not work in emulator
	      overlay.runOnFirstFix(new Runnable() {
	         public void run() {
	            // Zoom in to current location
	            controller.setZoom(15);
	            controller.animateTo(overlay.getMyLocation());
	         }
	      });
	      
	     // mapView.getOverlays().add(overlay); // Dont show my location
	}

	
	/** *TODO* Remove this
	 * 
	 */
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	//	getMenuInflater().inflate(R.menu.quest_menu, menu);
		return true;
	}
	
	/**
	 * Handles the creation of a new marker on the map.
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.add_new_marker:

				return true;

			case R.id.add_test_poi: // Ao criar um Spot, a BoundingBox � tamb�m criada
				
				return true;
		}
	
		return super.onOptionsItemSelected(item);
	}
	
	
	/**
	 * Sets our location to the last known location and start 
	 *  a separate thread to update GPS location.
	 */
	 private void initializeLocationAndStartGpsThread() {
		mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		List<String> providers = mLocationManager.getProviders(ENABLED_ONLY);
		Log.i("Providers", "Enabled providers = " + providers.toString());
		String provider = mLocationManager.getBestProvider(new Criteria(),ENABLED_ONLY);
		Log.i("Best Provider", "Best provider = " + provider);
	 }


	/* (non-Javadoc)
	 * @see com.google.android.maps.MapActivity#isRouteDisplayed()
	 */
	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
	/**
	 *  AsyncTask que acede � API e vai buscar as Quests pelas Coordenadas actuais
	 *  
	 *  Gera uma QuestsByCoordResponse
	 */
	private class questsByCoordQueryAPITask extends AsyncTask<String, Void, QuestsByCoordResponse> {

		@Override
		protected QuestsByCoordResponse doInBackground(String... params) {
			return ApiQuestTrip.questsByCoord(params[0], params[1]);
		}


		@Override
		protected void onPostExecute(QuestsByCoordResponse result) {
			super.onPostExecute(result);

			questsByCoordResponse = result;
			if (questsByCoordProgressDialog != null) {
				questsByCoordProgressDialog.dismiss();
			}

			if(questsByCoordResponse.getQuests() != null){
				QuestAdapter adapter = new QuestAdapter(mContext,
						R.layout.nearquests_item_row, questsByCoordResponse.getQuests());

				searchQuestsListView = (ListView)findViewById(R.id.listView);

				/*	       if(!nearQuestsHeaderView){ // S� coloca o header 1 vez
					        	nearQuestsHeaderView = true;
						        View header = (View)getLayoutInflater().inflate(R.layout.nearquests_header_row, null);
						        nearQuestsListView.addHeaderView(header); 
					        }
				 */        
				searchQuestsListView.setAdapter(adapter);

				// Coloca o listener que invoca a QuestActivity
				searchQuestsListView.setOnItemClickListener(new OnItemClickListener() {
					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position,
							long id) {
							startQuestActivity(questsByCoordResponse.getQuests()[position]);
					}
				});
			}
		}

	}
	
	/**
	 * M�todo que invoca uma QuestActivity
	 * @param quest
	 */
	private void startQuestActivity(Quest quest) {
		Intent questIntent = new Intent(this, QuestActivity.class);
		questIntent.putExtra("quest_id", quest.getID());
		questIntent.putExtra("name", quest.getName());
		questIntent.putExtra("category", quest.getCategory());
		questIntent.putExtra("rating", quest.getRating());
		questIntent.putExtra("is_linear", quest.isLinear());
		startActivity(questIntent);
	}

}
