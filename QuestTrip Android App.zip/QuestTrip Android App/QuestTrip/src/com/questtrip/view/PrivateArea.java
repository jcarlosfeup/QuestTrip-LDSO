/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.view;



import java.util.ArrayList;
import java.util.List;

import com.questtrip.api.ApiQuestTrip;
import com.questtrip.api.responses.QuestDBResponse;
import com.questtrip.api.responses.SpotsByQuestResponse;
import com.questtrip.database.QuestDB;
import com.questtrip.models.User;
import com.questtrip.models.application.LoggedUser;

import android.app.Activity;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ExpandableListView;
import android.widget.Toast;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * @author Filipe Rodrigues
 *
 */
public class PrivateArea extends ListActivity{
	
	private ImageView userImage = null;
	private TextView name = null, userName = null;
	
	
	private List<QuestDB> quests = null;
	//private QuestDBResponse questsDB = null;
	private ArrayList<QuestDB> completedQuests = null;
	private ArrayList<QuestDB> onprogressQuests = null;
	
	
	// Declaracoes de List
	private ExpandableListView listView = null;
	private ProgressDialog progressDialog;
	private ExpandableListAdapter adapter;
	private final int ITEMS_TO_ADD = 2;
	
	private Context mContext = null;
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.private_area);
		
		mContext = this;
		
		userImage = (ImageView) findViewById(R.id.userImage);
		name = (TextView) findViewById(R.id.showName);
		userName = (TextView) findViewById(R.id.showUsername);
		 
		if(LoggedUser.getLoggedUser() != null){
			
			Log.d("NAO ESTA NULL", "CENAS");
			userImage.setImageDrawable(LoggedUser.getLoggedUser().getImage());
			name.setText(LoggedUser.getLoggedUser().getName());
			userName.setText(LoggedUser.getLoggedUser().getUsername());
		}
		
		// Preenche os arrays com as Quests da DB
	//	fillQuestArrays();
		
		this.progressDialog = ProgressDialog.show(this, "", "Retrieving Server Info", true, false);
		new queryAPITask().execute();
		
		this.listView = (ExpandableListView) findViewById(R.id.listView);		
	}
	
	/**
	 *  AsyncTask to unbundle information received from another activity
	 */
	private class queryAPITask extends AsyncTask<Void, Void, QuestDBResponse> {

		@Override
		protected QuestDBResponse doInBackground(Void... params) {
			return ApiQuestTrip.getUserAllQuests(LoggedUser.getLoggedUser().getLogin());
		}


		@Override
		protected void onPostExecute(QuestDBResponse result) {
			super.onPostExecute(result);
			
		//	questsDB = result;
			
			completedQuests =  new ArrayList<QuestDB>();
			onprogressQuests =  new ArrayList<QuestDB>();
			
			if(result.getDBQuests() != null){
				for(int i = 0; i< result.getDBQuests().length; i++){
					if(result.getDBQuests()[i].isCompleted())
						completedQuests.add(result.getDBQuests()[i]);
					else
						onprogressQuests.add(result.getDBQuests()[i]);
				}
				
				Log.d("QUESTS SIZE", result.getDBQuests().length + "");
				Log.d("COMPLETED SIZE", completedQuests.size() + "");
				Log.d("ONPROGRESS SIZE", onprogressQuests.size() + "");
			}
			
			initializeAdapter();
			setAdapterActions();
			
			if (progressDialog != null) {
				progressDialog.dismiss();
			}
		
		}
	}
	
	
	/**
	 * 
	 */
	private void fillQuestArrays() {
		quests = MainActivity.db.getAllQuests();
		
		completedQuests =  new ArrayList<QuestDB>();
		onprogressQuests =  new ArrayList<QuestDB>();
		
		for(int i = 0; i< quests.size(); i++){
			if(quests.get(i).isCompleted())
				completedQuests.add(quests.get(i));
			else
				onprogressQuests.add(quests.get(i));
		}
		
		Log.d("QUESTS SIZE", quests.size() + "");
		Log.d("COMPLETED SIZE", completedQuests.size() + "");
		Log.d("ONPROGRESS SIZE", onprogressQuests.size() + "");
	}

	/**
	 * Display information on the screen
	 */
	private void setAdapterActions(){
		
		// Add actions
		this.listView.setOnChildClickListener(new OnChildClickListener() {

			@Override
			public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id){
				// Index of the ArrayList that contains the null element that represents the MORE option
				int lastElementIndex = adapter.getChildrenCount(groupPosition) - 1;
				
				// If the selected child is the last element of the list and if the element is null, then the MORE option has been selected
				if (childPosition == lastElementIndex && adapter.getChild(groupPosition, lastElementIndex) == null) {
					int displaySize = adapter.getChildrenCount(groupPosition)-1;
					int searchSize = 0;
					// Check if we are displaying all the received data
					switch (groupPosition) {
						case 0:
							searchSize = completedQuests.size();
							break;
						case 1:
							searchSize = onprogressQuests.size();
							break;
					}
					
					// If we are not displaying all the elements
					if (displaySize < searchSize) {
						// Add the three elements
						for (int i=0; i<ITEMS_TO_ADD; i++) {
							switch (groupPosition) {
								case 0:
									if ((lastElementIndex + i) <= completedQuests.size()-1)
										adapter.addChild(groupPosition, completedQuests.get(lastElementIndex+i));
									break;
								case 1:
									if ((lastElementIndex + i) <= onprogressQuests.size()-1)
										adapter.addChild(groupPosition, onprogressQuests.get(lastElementIndex+i));
									break;
							}
						}
						
						// Check if all the retrieved elements from last.fm are already being displayed, if so, remove the MORE option
						lastElementIndex = adapter.getChildrenCount(groupPosition) - 1;
						switch(groupPosition) {
							case 0:
								if (completedQuests.size() == lastElementIndex) {
									adapter.removeLastElementOfGroup(groupPosition);
								}
								break;
							case 1:
								if (onprogressQuests.size() == lastElementIndex)
									adapter.removeLastElementOfGroup(groupPosition);
								break;
						}
					}
					else
						Toast.makeText(getBaseContext(), "No more results to show", Toast.LENGTH_LONG).show();
					
					// Refresh the adapter
					adapter.notifyDataSetChanged();
				}
				else {
					switch (groupPosition) {
						case 0:
							// Launch Quest Activity Display (COMPLETED)
							Intent questIntent = new Intent(mContext, Quest_Display.class);
							questIntent.putExtra("quest", completedQuests.get(childPosition));
							startActivity(questIntent);
							break;
						case 1:
							// Launch Quest Activity Display (ON PROGRESS)
							Intent questOnProgressIntent = new Intent(mContext, Quest_Display.class);
							questOnProgressIntent.putExtra("quest", onprogressQuests.get(childPosition));
							startActivity(questOnProgressIntent);
							break;
					}
				}
				return true;
			}
		});

		
	}
	
	
	/**
	 *  Initialize the adapter and add the necessary information
	 */
	private void initializeAdapter() {
		ArrayList<String> groups = new ArrayList<String>();
		groups.add("Completed Quests");
		groups.add("On Progress Quests");
		
		// Create a first list with only 5 results of each group
		ArrayList<QuestDB> completed = new ArrayList<QuestDB>();
		ArrayList<QuestDB> onProgress = new ArrayList<QuestDB>();
		
		int quest_limit = 0;
		if(completedQuests.size() > onprogressQuests.size()){
			quest_limit = completedQuests.size();
		}
		else
			quest_limit = onprogressQuests.size();

		for (int pos=0; pos < quest_limit; pos++) {
			if (this.completedQuests != null && pos < this.completedQuests.size())
				completed.add(this.completedQuests.get(pos));
			if (this.onprogressQuests != null && pos < this.onprogressQuests.size())
				onProgress.add(this.onprogressQuests.get(pos));
		}
		
		// Add a control element that will be replaced by the MORE option
/*		if (!tracks.isEmpty())
			tracks.add(null);
		if (!artists.isEmpty())
			artists.add(null);
		if (!albums.isEmpty())
			albums.add(null);
*/		
		// Build the expandable list
		ArrayList<ArrayList<QuestDB>> expandableList = new ArrayList<ArrayList<QuestDB>>();
		expandableList.add(completed);
		expandableList.add(onProgress);

		// Create the ExpandableList adapter and set it
		this.adapter = new ExpandableListAdapter(groups, expandableList);
		this.listView.setAdapter(this.adapter);
	}
	
		

	public class ExpandableListAdapter extends BaseExpandableListAdapter {

	    private ArrayList<String> groups;
		private ArrayList<ArrayList<QuestDB>> children;
	 
	    public ExpandableListAdapter(ArrayList<String> groups, ArrayList<ArrayList<QuestDB>> expandableList) {
	        this.groups = groups;
	        this.children = expandableList;
	    }

	    public void addChild(int groupPosition, QuestDB info) {
	    	// Point to the last valid element in the list
	    	int position = this.children.get(groupPosition).size() - 1;
	    	this.children.get(groupPosition).add(position, info);
	    }
	    
	    public void removeLastElementOfGroup(int groupPosition) {
	    	int position = this.children.get(groupPosition).size()-1;
	    	this.children.get(groupPosition).remove(position);
	    }

	    @Override
	    public Object getChild(int groupPosition, int childPosition) {
	        return this.children.get(groupPosition).get(childPosition);
	    }

	    @Override
	    public long getChildId(int groupPosition, int childPosition) {
	        return childPosition;
	    }
	    
	    // Return a child view. You can load your custom layout here.
	    @Override
	    public View getChildView(int groupPosition, int childPosition, boolean isLastChild,  View convertView, ViewGroup parent) {
	    	QuestDB info = (QuestDB)getChild(groupPosition, childPosition);
	        
	        if (convertView == null) {
	            LayoutInflater infalInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	            convertView = infalInflater.inflate(R.layout.privatearea_options_row, null);
	        }
	        
	        TextView label = (TextView) convertView.findViewById(R.id.label);
	        String url = null;

	        // Check the object's class
	        if (info.isCompleted()) {
	        		label.setText(info.getName() + "\n Score: " + info.getScore());
	        }
	        else if (!info.isCompleted()) {
	        	label.setText(info.getName() + "\n Current Score: " + info.getScore());
	        }
	  /*      else if (info == null) {
	        	label.setText("More...");
	        	url = "more";
	        }
	    */    
	        return convertView;
	    }
	    

	    @Override
	    public int getChildrenCount(int groupPosition) {
	        return this.children.get(groupPosition).size();
	    }


	    @Override
	    public Object getGroup(int groupPosition) {
	        return this.groups.get(groupPosition);
	    }


	    @Override
	    public int getGroupCount() {
	        return this.groups.size();
	    }


	    @Override
	    public long getGroupId(int groupPosition) {
	        return groupPosition;
	    }


	    // Return a group view. You can load your custom layout here.
	    @Override
	    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
	        String group = (String) getGroup(groupPosition);
	        if (convertView == null) {
	            LayoutInflater infalInflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	            convertView = infalInflater.inflate(R.layout.group_layout, null);
	        }
	        TextView tv = (TextView) convertView.findViewById(R.id.tvGroup);
	        tv.setText(group);
	        return convertView;
	    }


	    @Override
	    public boolean hasStableIds() {
	        return true;
	    }


	    @Override
	    public boolean isChildSelectable(int groupPosition, int childPosition) {
	        return true;
	    }
	}

}
