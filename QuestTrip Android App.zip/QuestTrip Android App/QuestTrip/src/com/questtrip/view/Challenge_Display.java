package com.questtrip.view;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import com.questtrip.api.ApiQuestTrip;
import com.questtrip.api.responses.ChallengeResponse;
import com.questtrip.models.challenge.Challenge;
import com.questtrip.models.challenge.Question_Option;
import com.questtrip.models.variables.Variables;
import com.questtrip.view.R.id;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;


/**
 * Activity que permite visualizar um Challenge
 * 
 * @author Filipe Rodrigues
 *
 */
public class Challenge_Display extends ListActivity {
	
	Challenge chg = null;
	private int index = 0;
	
	private ProgressDialog progressDialog;
	private AlertDialog showChallengeState = null;
	
	private TextView spotName;
	private TextView challengeContent, score;
	private LinearLayout optionsContainer;
	private ImageView chgDisplay;
	private Drawable imageDrawable = null;
	
	// Score actual
	private int actualScore = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.challenge_display);
        
        this.challengeContent = (TextView) findViewById(R.id.challengeContent);
        this.optionsContainer = (LinearLayout) findViewById(R.id.optionsContainer);
        this.spotName = (TextView) findViewById(R.id.challenge_title_content);
        this.score = (TextView) findViewById(id.score);
        
		// Extract necessary information
		this.progressDialog = ProgressDialog.show(this, "", "Loading Challenge", true, false);
		new unbundleInformation().execute();
    }
    
	/**
	 * AsyncTask to unbundle information received from another activity
	 */
	private class unbundleInformation extends AsyncTask<Void, Void, ChallengeResponse> {

		@Override
		protected ChallengeResponse doInBackground(Void... params) {
			return unbundleInformation();
		}


		@Override
		protected void onPostExecute(ChallengeResponse result) {
			super.onPostExecute(result);
			
			actualScore = chg.getMaxScore();
			
			if(chg.getChallengeType().equals(Variables.CHALLENGE_QUIZ)){
				Log.d("QUESTION", result.getChallenge().getQuestion());
				chg.setQuestion(result.getChallenge().getQuestion());
				chg.setOptions(result.getChallenge().getOptions());
			}
			else if(chg.getChallengeType().equals(Variables.CHALLENGE_VISIT)){
				chg.setDescription(result.getChallenge().getDescription());
				chg.setComplete(true); // Basta visitar
			}
			
			if (progressDialog != null) {
				progressDialog.dismiss();
			}
			
			// Visualiza o Challenge
			displayChallenge();
		}

	}

	
	/**
	 * [CHECKED] Identify the activity that started the current activity and extracts the information sent
	 * @param info
	 */
	private ChallengeResponse unbundleInformation() {
		Bundle info = getIntent().getExtras();
		this.chg = (Challenge)info.getParcelable("chg");
		this.index = (int)info.getInt("index");
		
		return ApiQuestTrip.getChallenge(chg.getId());
	}
	

	/**
	 * 
	 */
	private void displayChallenge() {
		if(chg != null){
			
			spotName.setText(this.chg.getSpotName());
			
			if(chg.getChallengeType().equals(Variables.CHALLENGE_QUIZ)){
				challengeContent.setText(this.chg.getQuestion());
			}
			else if(chg.getChallengeType().equals(Variables.CHALLENGE_VISIT)){
				challengeContent.setText(this.chg.getDescription());
			}
			
			if(this.chg.getImage() != null){
				new DownloadQuestImage().execute(this.chg.getImage());
				Log.d("IMAGE", this.chg.getImage());
			}
			
			if(chg.getChallengeType().equals(Variables.CHALLENGE_QUIZ) && chg.getOptions() != null) // Visualiza Op��es
				setListAdapter(new IconicAdapter());
			else // Esconde Container
				optionsContainer.setVisibility(View.GONE);
		}
	
		// InternetUtilities.bitmapDownloader(this.artistData.getPhoto(), imgView_artistImage);
	}
	
	private class IconicAdapter extends ArrayAdapter<Question_Option> {

		public IconicAdapter() {
			super(Challenge_Display.this, R.layout.challenge_options_row, R.id.label, chg.getOptions());
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			View row = convertView;

			if (row == null) {
				LayoutInflater inflater = getLayoutInflater();
				row = inflater.inflate(R.layout.challenge_options_row, parent, false);
			}
			int num = position + 1;
			TextView label = (TextView)row.findViewById(R.id.label);
			label.setText( num + ". " + chg.getOptions()[position].getOptionText());
			
			return(row);
		}
	}
	
	protected void onListItemClick(ListView l, View v, int position, long id) {
		super.onListItemClick(l, v, position, id);

		// Verifica se op��o � v�lida
		if(chg.getOptions()[position].isValid()){
			chg.setComplete(true);
			
			
		//	Toast.makeText(this.getBaseContext(), "Correct answer!", Toast.LENGTH_SHORT).show();
		//	getBackToQuest();
			 showChallengeStateDialog();
		}else{ 
			
			if(actualScore > 0)
				actualScore -=  chg.getPenalty();
			
			if(actualScore < 0)
				actualScore = 0;
			
			score.setText("Score: " + actualScore);
		//	Toast.makeText(this.getBaseContext(), "Ooops! Incorrect answer!", Toast.LENGTH_SHORT).show();
			 showChallengeStateDialog();
		}
	}
	
	private void showChallengeStateDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		
		
		if(chg.isComplete()){
			score.setText("Score: " + actualScore);
			builder.setTitle("Congratulations");
			builder.setMessage("Challenge Complete!\nScore: " + actualScore);
			
			builder.setPositiveButton("Return to Quest", new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					getBackToQuest();
				}

			});
		}
		else{
				score.setText("Actual Score: " + actualScore);
				builder.setTitle("Oops");
				builder.setMessage("Wrong Answer!\nActual Score: " + actualScore);
				
				builder.setPositiveButton("Try again", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
					}

				});
		}
		
		
		builder.setNegativeButton("Cancel", new OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
			
			}

		});
		
		
		showChallengeState = builder.show();
	//	showChallengeState.show();
	}
	
	public void getBackToQuest(){
		Intent returnIntent = new Intent();
		
		returnIntent.putExtra("score", actualScore);
		returnIntent.putExtra("index", index);
    	
    	if(chg.isComplete())
    		setResult(RESULT_OK, returnIntent);     
    	else
    		setResult(RESULT_CANCELED, returnIntent);    
    	
    	
    	finish();
	}
	
    public void onBackPressed() {
    	getBackToQuest();

        return;
    } 

    class DownloadQuestImage extends AsyncTask<String, Void, Integer> {

	    protected Integer doInBackground(String... url) {
	        try {
	        	loadImage(url[0]); // Download da imagem
	        } catch (Exception e) {
	            return null;
	        }
			return 1;
	    }

	    // Save dos dados e preenchimento das estruturas
	    protected void onPostExecute(Integer res) {
			if(res == 1){
		        chgDisplay = (ImageView) findViewById(R.id.chgImage);
		        chgDisplay.setBackgroundResource(Color.TRANSPARENT);
		        chgDisplay.setImageDrawable(imageDrawable);
			}
	    }
	 }

	public void loadImage(String url){
		try {
			this.imageDrawable = drawableFromUrl(url);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	@SuppressWarnings("deprecation")
	private Drawable drawableFromUrl(String url) throws IOException {
	    Bitmap x;

	    HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
	    connection.connect();
	    InputStream input = connection.getInputStream();

	    x = BitmapFactory.decodeStream(input);
	    return new BitmapDrawable(x);
	}
}
