/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.view;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import com.questtrip.api.ApiQuestTrip;
import com.questtrip.api.responses.ChallengeResponse;
import com.questtrip.api.responses.RatingResponse;
import com.questtrip.database.QuestDB;
import com.questtrip.models.User;
import com.questtrip.models.application.LoggedUser;
import com.questtrip.models.challenge.Challenge;
import com.questtrip.models.variables.Variables;
import com.questtrip.view.R.id;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @author Filipe Rodrigues
 *
 */
public class Quest_Display extends Activity {
	
	QuestDB quest = null;
	
	private ProgressDialog progressDialog = null, progressDialogVoting = null;
	
	private TextView questName = null;
	private TextView totalSpots = null, completeSpots = null, score = null, questRating = null;
	private ImageView questImage = null;
	private RatingBar minimumRating = null;
	private Button voteButton = null;
	
	private Drawable imageDrawable = null;
	
	private Context mContext = null;

	
	private int myRating = 0;
	private float avgRating = 0.0f;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quest_display);
        
        mContext = this;
        
        this.questName = (TextView) findViewById(R.id.quest_title);
        this.totalSpots = (TextView) findViewById(R.id.totalSpots);
        this.completeSpots = (TextView) findViewById(R.id.completedSpots);
        this.score = (TextView) findViewById(R.id.score);
        this.questRating = (TextView) findViewById(R.id.questRating);
        
        
		minimumRating = (RatingBar)findViewById(R.id.ratingBar);
	    minimumRating.setOnTouchListener(new OnTouchListener()
	    { 
			@Override
			public boolean onTouch(View view, MotionEvent event) {
	            float touchPositionX = event.getX();
	            float width = minimumRating.getWidth();
	            float starsf = (touchPositionX / width) * 5.0f;
	            int stars = (int)starsf + 1;
	            minimumRating.setRating(stars);
	            
	            return true; 
			} 
	    });
	    voteButton = (Button) findViewById(R.id.voteRating);
	    voteButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				progressDialogVoting = ProgressDialog.show(mContext, "", "Sending Vote...", true, false);
				new ratingSendingVote().execute((int)minimumRating.getRating());
			}
		});
	    
        
		// Extract necessary information
		this.progressDialog = ProgressDialog.show(this, "", "Loading Quest", true, false);
		new unbundleInformation().execute();
    }
    
    
    class ratingSendingVote extends AsyncTask<Integer, Void, Integer> {

	    protected Integer doInBackground(Integer... rating) {
	        try {
	        	ApiQuestTrip.questRating(LoggedUser.getLoggedUser().getLogin(), quest.getQuest_id(), rating[0]);
	        } catch (Exception e) {
	            return null;
	        }
			return 1;
	    }

	    // Save dos dados e preenchimento das estruturas
	    protected void onPostExecute(Integer res) {

			if (progressDialogVoting != null) {
				progressDialogVoting.dismiss();
			}
			
			if(res != 1){
	            Toast.makeText(mContext, "Oops... Something went wrong.\nPlease try again" , Toast.LENGTH_SHORT).show();
			}
	    }
	 }

    
    /**
	 * AsyncTask to unbundle information received from another activity and download Quest Image
	 */
	private class unbundleInformation extends AsyncTask<Void, Void, String> {

		@Override
		protected String doInBackground(Void... params) {
			return unbundleInformationAndQueryAPI();
		}


		@Override
		protected void onPostExecute(String url) {
			super.onPostExecute(url);
			
			// Disable do bot�o de voto
	        if(!quest.isCompleted()){
	        	minimumRating.setEnabled(false);
	        	voteButton.setEnabled(false);
	        }

			if(url != null){ // Se houver imagem, lan�a a Task de Download
				new DownloadQuestImage().execute(url);
			}
			
			if (progressDialog != null) {
				progressDialog.dismiss();
			}
			
			
			
			// Visualiza o Challenge
			displayQuest();
		}

	}
	


	/**
	 * 
	 */
	private void displayQuest() {
		questName.setText(quest.getName());
		score.setText("Score: " + quest.getScore());
		totalSpots.setText("Total Spots: " + quest.getTotalSpots());
		completeSpots.setText("Completed Spots: " + quest.getCompleteSpots());
		fillRatingData();
		
		
		minimumRating.setRating(myRating);
		//minimumRating.refreshDrawableState();
	}
	
	/**
	 * 
	 */
	private void fillRatingData() {
		questRating.setText("Rating: " + avgRating);
		minimumRating.setRating(myRating);
	}
	
	/**
	 * Identify the activity that started the current activity and extracts the information sent
	 * @param info
	 */
	private String unbundleInformationAndQueryAPI() {
		Bundle info = getIntent().getExtras();
		this.quest = (QuestDB)info.getParcelable("quest");
		
		// Load do rating e avgrating
		RatingResponse rating = ApiQuestTrip.getQuestRatingAndAVGRating(LoggedUser.getLoggedUser().getLogin(), quest.getQuest_id());
		myRating = rating.getData().getRating();
		avgRating = rating.getData().getAVGRating();
		
		return ApiQuestTrip.getQuestImage(quest.getQuest_id()); 
	}

	
	
	class DownloadQuestImage extends AsyncTask<String, Void, Integer> {

	    protected Integer doInBackground(String... url) {
	        try {
	        	loadImage(url[0]); // Download da imagem
	        } catch (Exception e) {
	            return null;
	        }
			return 1;
	    }

	    // Save dos dados e preenchimento das estruturas
	    protected void onPostExecute(Integer res) {
			if(res == 1){
		        questImage = (ImageView) findViewById(R.id.questimage);
		        questImage.setBackgroundResource(Color.TRANSPARENT);
				questImage.setImageDrawable(imageDrawable);
			}
	    }
	 }

	public void loadImage(String url){
		try {
			this.imageDrawable = drawableFromUrl(url);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	@SuppressWarnings("deprecation")
	private Drawable drawableFromUrl(String url) throws IOException {
	    Bitmap x;

	    HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
	    connection.connect();
	    InputStream input = connection.getInputStream();

	    x = BitmapFactory.decodeStream(input);
	    return new BitmapDrawable(x);
	}
}
