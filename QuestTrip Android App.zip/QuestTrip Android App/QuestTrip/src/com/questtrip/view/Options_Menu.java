/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.view;

import android.app.Activity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;

/**
 * @author Filipe Rodrigues
 *
 */
public class Options_Menu extends Activity{
	
	private CheckBox showMyLocation;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.options_menu);

		
		
		showMyLocation = (CheckBox)findViewById(R.id.motionCheckBox); 
		if(MainActivity.SHOW_MAP){
			showMyLocation.setChecked(true);
		}
		else{
			showMyLocation.setChecked(false);
		}
		
		showMyLocation.setOnCheckedChangeListener(new OnCheckedChangeListener() {
	        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
	        	if (isChecked) { 
	        		MainActivity.SHOW_MAP = true;
        		}
	        	else if(!isChecked){
	        		MainActivity.SHOW_MAP = false;
	        	}
	        }
	    });	
	}
}
