package com.questtrip.view;

import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;
import com.questtrip.api.ApiQuestTrip;
import com.questtrip.api.responses.SpotDBResponse;
import com.questtrip.api.responses.SpotsByQuestResponse;
import com.questtrip.database.QuestDB;
import com.questtrip.database.SpotDB;
import com.questtrip.models.BoundingBox;
import com.questtrip.models.Spot;
import com.questtrip.models.User;
import com.questtrip.models.application.LoggedUser;
import com.questtrip.models.challenge.Challenge;
import com.questtrip.models.challenge.Question_Option;
import com.questtrip.models.variables.Variables;


/** 
 * Class onde � tratado todo o ciclo de jogo - Quest
 * 
 * @author Filipe Rodrigues
 *
 */
public class QuestActivity extends MapActivity implements LocationListener {
	
	
	// Puzzle Declarations
	
	
	// Quest data
	private String name = null;
	private String category = null;
	private String quest_id = null;
	private int rating = 0;
	
	// Quest UI
	private TextView score = null;
	private TextView chgLeft = null;
	private int currentScore = 0;
	private int completeSpots = 0;
	private int totalSpots = 0;
	
	// Para Quests Lineares
	private boolean is_linear = false;
	private int linear_index = 0;
	private SpotsByQuestResponse spotsByQuest = null;
	
	// GPS_PROVIDER or NETWORK_PROVIDER
	String provider = LocationManager.GPS_PROVIDER;
	
	// Markers
	private OverlayController overlayController; // Guarda os spots em determinado Overlay
	private int spotIndex = -1; 
	private List<Overlay> mapOverlays; // Para gerir os Overlays desta MapActivity, cont�m o overlayController
	private Drawable spotCompleteMark, spotEnterMark, spotMark;
	
	// Map
	private MapView mapView;
	private MapController controller;
	LocationManager mLocationManager;
	Thread mThread; // Para fazer update da localiza��o em background

	private double mLongitude = 0;
	private double mLatitude = 0;
	
	// Database
	SpotDBResponse spotDBResponse = null;
	
	// Buttons
//	private ImageButton enter_challenge;
	
	// Controlo de Interface
//	boolean stayingOnSpot = false; // Flag utilizada pela interface, para verificar se Utilizador continua no raio do Spot 

	// Mensagem enviada para o handler quando � necess�rio fazer update da localiza��o
	private static final boolean ENABLED_ONLY = false;
	protected static final int UPDATE_LOCATION = 1;

	private ProgressDialog progressDialog  = null;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.quest_activity);


		initMapView();
		initMyLocation();
		
		
		
		// Overlay Markers
		mapOverlays = mapView.getOverlays();
		spotMark = this.getResources().getDrawable(R.drawable.spotmark);
		overlayController = new OverlayController(spotMark, this);
		spotCompleteMark = this.getResources().getDrawable(R.drawable.spotmarkdone);
		spotEnterMark = this.getResources().getDrawable(R.drawable.spotmarkenter);
		
		
		initializeLocationAndStartGpsThread();
		
		// Unbundle information that this activity received
		this.progressDialog = ProgressDialog.show(this, "", "Retrieving Server Info", true, false);
		new unbundleInformationAndQueryAPITask().execute();
		
		
		// *************** Interface ***************
		
		
		score = (TextView) findViewById(R.id.questScore);
		chgLeft = (TextView) findViewById(R.id.chgLeft);
		
		// *TODO* REMOVE THIS ?
		// Enter Challenge Button
/*		this.enter_challenge = (ImageButton) findViewById(R.id.enter_challenge);
		this.enter_challenge.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				callChallenge();
			}
		});
*/		

		/*
		GeoPoint pointm = new GeoPoint(19240000,-99120000);
		OverlayItem overlayitem = new OverlayItem(pointm, "Hola, Mundo!", "I'm in Mexico City!");
		itemizedoverlay.addOverlay(overlayitem);
		mapOverlays.add(itemizedoverlay);
		*/
	}

	/*
	public static void setChallengeComplete(){
		completeSpot = true;
	}
	*/
	
	/**
	 * Controla se Challenge ficou completo 
	 * *TODO* eventualmente substituir por acesso � DB sqlite de android 
	 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == 1) {
			if(resultCode == RESULT_OK){
				currentScore += data.getIntExtra("score", 0); // Vai buscar o Score
				spotIndex = data.getIntExtra("index", spotIndex); // Vai buscar o Index do Spot completo (devido a poder haver overlap)
				
				completeSpots += 1;
				score.setText(currentScore + " : Score");
				chgLeft.setText(completeSpots + "/" + totalSpots + " Spots");

				// Actualiza OverlayItem
				overlayController.getSpots().get(spotIndex).getChallenge().setComplete(true);
				overlayController.setSpotImage(spotCompleteMark, spotIndex);
				
				if(is_linear){ // Se for uma Quest Linear, incrementa o OverlayItem
					if(linear_index < totalSpots-1){
						linear_index++;
						setNextLinearSpot(spotsByQuest);
					}
				}
				
				if(LoggedUser.getLoggedUser() != null){
					// Adiciona na BD o challenge completo
					MainActivity.db.addSpot(new SpotDB(overlayController.getSpots().get(spotIndex).getChallenge().getId(),1,data.getIntExtra("score", 0)));
					
					// Actualiza na DB a Quest
					MainActivity.db.updateQuest(new QuestDB(quest_id, name, totalSpots, completeSpots, currentScore, rating));
					
					this.progressDialog = ProgressDialog.show(this, "", "Retrieving Server Info", true, false);
					new setSpotCompletedAPI().execute(overlayController.getSpots().get(spotIndex).getChallenge().getId(), 
							LoggedUser.getLoggedUser().getLogin(), data.getIntExtra("score", 0) + "");
				}
			}

			if (resultCode == RESULT_CANCELED) {
			}
		}
	}
	
	/**
	 *  AsyncTask to unbundle information received from another activity
	 */
	private class setSpotCompletedAPI extends AsyncTask<String, Void, Void> {

		@Override
		protected Void doInBackground(String... params) {
			ApiQuestTrip.setSpotCompleted(params[0], params[1], params[2]);
			return null;
		}


		@Override
		protected void onPostExecute(Void v) {
			super.onPostExecute(v);
			
			if (progressDialog != null) {
				progressDialog.dismiss();
			}
		}
	}
	
	
	/**
	 *  AsyncTask to unbundle information received from another activity
	 */
	private class unbundleInformationAndQueryAPITask extends AsyncTask<Void, Void, SpotsByQuestResponse> {

		@Override
		protected SpotsByQuestResponse doInBackground(Void... params) {
			return unbundleInformationAndQueryAPI();
		}


		@Override
		protected void onPostExecute(SpotsByQuestResponse result) {
			super.onPostExecute(result);
			
			chgLeft.setText("0/" + result.getSpots().length + " Spots");
			totalSpots = result.getSpots().length;
			fillOverlayController(result);
			
			if (progressDialog != null) {
				progressDialog.dismiss();
			}
			
			// Insere Quest na DB se o user estiver com login feito, caso n�o exista
			if(LoggedUser.getLoggedUser() != null)
				MainActivity.db.addQuest(new QuestDB(quest_id, name, totalSpots, completeSpots, currentScore, rating));
		}
	}
	
	/**
	 * Extracts the information sent and query API
	 */
	private SpotsByQuestResponse unbundleInformationAndQueryAPI() {
		Bundle info = getIntent().getExtras();

		this.quest_id = info.getString("quest_id");
		this.name = info.getString("name");
		this.category = info.getString("category");
		this.rating = info.getInt("rating");
		this.is_linear = info.getBoolean("is_linear");
		
		Log.d("ID", quest_id);
		Log.d("Name", name);
		Log.d("Category", is_linear + "");
		
		
		// Acede � API e verifica se h� informa��o guardada sobre a Quest
		if(LoggedUser.getLoggedUser() != null){
			spotDBResponse = ApiQuestTrip.getQuestInfo(quest_id, LoggedUser.getLoggedUser().getLogin());
					
			// Em caso positivo, actualiza a DB SQLite
			if(spotDBResponse.getDBSpots() != null){
				updateAndroidDB(spotDBResponse.getDBSpots());
			}
			
		}
	
		return ApiQuestTrip.spotsByQuest(quest_id);
	}
    
	/**
	 * @param dbSpots
	 */
	private void updateAndroidDB(SpotDB[] dbSpots) {
		for(int i = 0; i < dbSpots.length; i++){
			MainActivity.db.addSpot(dbSpots[i]);
		}
	}

	private void fillOverlayController(SpotsByQuestResponse result){
		
		if(!is_linear){
			for(int i = 0; i < result.getSpots().length; i++){
				GeoPoint temp_point = new GeoPoint((int)(result.getSpots()[i].getLatitude() * 1E6), (int)(result.getSpots()[i].getLongitude() * 1E6)); 	
			//	Log.d("RADIUS:", result.getSpots()[i].getRadius() + "");
				Spot overlayitem_temp = new Spot(temp_point, result.getSpots()[i].getName(), result.getSpots()[i].getDescription(), result.getSpots()[i].getRadius());
				
				// Cria Challenge
				Challenge ch = new Challenge(result.getSpots()[i].getChallenge_type(), result.getSpots()[i].getChallengeID(), result.getSpots()[i].getName(), result.getSpots()[i].getImage());
				overlayitem_temp.addChallenge(ch);
				
				overlayController.addOverlay(overlayitem_temp);
				
				
				// Se existe na BD quer dizer que j� foi completado, logo actualiza o overlaycontroller
				if(LoggedUser.getLoggedUser() != null){
					SpotDB spot = MainActivity.db.getSpot(ch.getId());
					if(spot != null){
						overlayController.setSpotImage(spotCompleteMark, i);
						currentScore += spot.getScore();
						completeSpots ++;
						score.setText(currentScore + " : Score");
						chgLeft.setText(completeSpots + "/" + totalSpots + " Spots");
						ch.setComplete(true);
					}
				}
			
			}
		}
		else{
			spotsByQuest = result;
			setNextLinearSpot(result);
		}
		
		mapOverlays.add(overlayController);
	}

	/***
	 * M�todo utilizado nas Quests Lineares, incrementa os OverlayItem
	 * @param result
	 */
	private void setNextLinearSpot(SpotsByQuestResponse result) {
		boolean notInDB = true;
		
		while(notInDB){
			GeoPoint temp_point = new GeoPoint((int)(result.getSpots()[linear_index].getLatitude() * 1E6), (int)(result.getSpots()[linear_index].getLongitude() * 1E6)); 	
		//	Log.d("RADIUS:", result.getSpots()[i].getRadius() + "");
			Spot overlayitem_temp = new Spot(temp_point, result.getSpots()[linear_index].getName(), result.getSpots()[linear_index].getDescription(), result.getSpots()[linear_index].getRadius());
			
			// Cria Challenge
			Challenge ch = new Challenge(result.getSpots()[linear_index].getChallenge_type(), result.getSpots()[linear_index].getChallengeID(), result.getSpots()[linear_index].getName(), result.getSpots()[linear_index].getImage());
			overlayitem_temp.addChallenge(ch);
			
			overlayController.addOverlay(overlayitem_temp);
			
			// Se existe na BD quer dizer que j� foi completado, logo actualiza o overlaycontroller
			if(LoggedUser.getLoggedUser() != null){
				SpotDB spot = MainActivity.db.getSpot(ch.getId());
				if(spot != null){
					overlayController.setSpotImage(spotCompleteMark, linear_index);
					currentScore += spot.getScore();
					completeSpots ++;
					score.setText(currentScore + " : Score");
					chgLeft.setText(completeSpots + "/" + totalSpots + " Spots");
					ch.setComplete(true);
					
					if(linear_index < totalSpots-1)
						linear_index++;
					else
						notInDB = false;
				}
				else // N�o existe na DB
					notInDB = false;
			}
			else // N�o existe na DB
				notInDB = false;
		}
	}

	
	private void initMapView() {
		mapView = (MapView) findViewById(R.id.mapview);
		mapView.setBuiltInZoomControls(true);
		//mapView.setSatellite(false);
		controller = mapView.getController();
	}

	private void initMyLocation() {
	      final MyLocationOverlay overlay = new MyLocationOverlay(this, mapView);
	      overlay.enableMyLocation();
	      overlay.enableCompass(); // does not work in emulator
	      overlay.runOnFirstFix(new Runnable() {
	         public void run() {
	            // Zoom in to current location
	            controller.setZoom(24);
	            controller.animateTo(overlay.getMyLocation());
	         }
	      });
	      mapView.getOverlays().add(overlay);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.quest_menu, menu);
		return true;
	}
	
	
	// *TODO* REMOVE THIS ? 
	/**
	 * Permite lan�ar o Challenge
	 * @param 
	 */
/*	public void callChallenge() {  
		Intent intentChallenge = new Intent(this, Challenge_Display.class); 
		
		// Se houver Spot e o mesmo possuir um Challenge
		if (spotIndex != -1 && overlayController.getSpots().get(spotIndex).hasChallenge()) {
			// Envia o Challenge
			intentChallenge.putExtra("chg", overlayController.getSpots().get(spotIndex).getChallenge());
		}
		
		startActivityForResult(intentChallenge, 1);
	}
*/

	/**
	 * Handles the creation of a new marker on the map.
	 */
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
			case R.id.add_new_marker:
				Log.i("TAG", "<long, lat> = <" + mLongitude + "," + mLatitude + ">");
				GeoPoint point = new GeoPoint((int)(mLatitude * 1E6), (int)(mLongitude * 1E6));
				Spot overlayitem = new Spot(point, "Me", "Hello ");
				overlayController.addOverlay(overlayitem);
				mapOverlays.add(overlayController);
				return true;

			case R.id.add_test_poi: // Ao criar um Spot, a BoundingBox � tamb�m criada
				
			//	GeoPoint point_test = new GeoPoint((int)(41.177660 * 1E6), (int)(-8.596133 * 1E6)); // Interior da FEUP
			//	GeoPoint point_test = new GeoPoint((int)(41.177391 * 1E6), (int)(-8.597190 * 1E6)); // Exterior da FEUP
				GeoPoint point_test = new GeoPoint((int)(41.354136 * 1E6), (int)(-8.733742 * 1E6)); 
				
				Spot overlayitem_test = new Spot(point_test, "Objective", "Objective to reach");
				overlayController.addOverlay(overlayitem_test);
				mapOverlays.add(overlayController);
				
				return true;
		}
	
		return super.onOptionsItemSelected(item);
	}
	
	
	/**
	 * Sets our location to the last known location and start 
	 *  a separate thread to update GPS location.
	 */
	 private void initializeLocationAndStartGpsThread() {
		mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		List<String> providers = mLocationManager.getProviders(ENABLED_ONLY);
		Log.i("Providers", "Enabled providers = " + providers.toString());
		String provider = mLocationManager.getBestProvider(new Criteria(),ENABLED_ONLY);
		Log.i("Best Provider", "Best provider = " + provider);

		setCurrentGpsLocation(null);   
		mThread = new Thread(new MyThreadRunner());
		mThread.start();
	 }
	 
	 
	 /**
	  * Handles location updates in the background.
	  */
	  class MyThreadRunner implements Runnable {
	 	// @Override
	 	public void run() {
	 		while (!Thread.currentThread().isInterrupted()) {
	 			Message m = Message.obtain();
	 			m.what = 0;
	 			QuestActivity.this.updateHandler.sendMessage(m);
	 			try {
	 				Thread.sleep(5);
	 			} catch (InterruptedException e) {
	 				Thread.currentThread().interrupt();
	 			}
	 		}
	 	}
	  }
	
	/**
	 * Sends a message to the update handler with either the current location or 
	 *  the last known location. 
	 * @param location is either null or the current location
	 */
	 private void setCurrentGpsLocation(Location location) {
	//	String bestProvider = "";
		if (location == null) {
			mLocationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
	                mLocationManager.requestLocationUpdates(
			    LocationManager.GPS_PROVIDER, 30000, 0, this); // Every 30000 msecs	
			location = mLocationManager.getLastKnownLocation(provider); 
			
			if(location == null)
				Toast.makeText(this.getBaseContext(), "UNABLE TO TRACK GPS LOCATION", Toast.LENGTH_SHORT).show();

		}
		try {
			mLongitude = location.getLongitude();
			mLatitude = location.getLatitude();
//			Log.i(TAG, "<long,lat> = <" + mLongitude + "," + mLatitude);
			Message msg = Message.obtain();
			msg.what = UPDATE_LOCATION;
			QuestActivity.this.updateHandler.sendMessage(msg);
		} catch (NullPointerException e) {
			Toast.makeText(this.getBaseContext(), "NULL POINTER IN LOCATION", Toast.LENGTH_SHORT).show();
			Log.i("LOCATION NULL", "Null pointer exception " + mLongitude + "," + mLatitude);
		}

	 }

	 
	 /**
	 * Handles GPS updates.  
	 * Source: Android tutorials
	 * @see http://www.androidph.com/2009/02/app-10-beer-radar.html
	 */
	 Handler updateHandler = new Handler() {
		/** Gets called on every message that is received */
		// @Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
				case UPDATE_LOCATION: {
					Log.i("UPDATE LOC", "Updated location = " + mLatitude + " " + mLongitude);
				
					
				/*	GeoPoint point = new GeoPoint((int)(mLatitude * 1E6), (int)(mLongitude * 1E6));
					OverlayItem overlayitem = new OverlayItem(point, "Me", "Hello ");
					itemizedoverlay.addOverlay(overlayitem);
				*/	
					// Actualiza a minha posi��o actual
					GeoPoint point = new GeoPoint((int)(mLatitude * 1E6), (int)(mLongitude * 1E6));
					controller.animateTo(point);
					
					
					// Verifica as BoundingBox de Spots
					if(!overlayController.getSpots().isEmpty()){
						for(int i = 0; i < overlayController.getSpots().size(); i++){
							
							if(mLatitude > overlayController.getSpots().get(i).getBoundingBox().minPoint().getLatitude() && 
								mLongitude > overlayController.getSpots().get(i).getBoundingBox().minPoint().getLongitude() &&
								mLatitude < overlayController.getSpots().get(i).getBoundingBox().maxPoint().getLatitude() && 
								mLongitude < overlayController.getSpots().get(i).getBoundingBox().maxPoint().getLongitude()
								// S� mostra os que n�o est�o completos
								&& !overlayController.getSpots().get(i).getChallenge().isComplete()){
									// Mostrar Challenge Button
									if(!overlayController.getSpots().get(i).isStayingOnSpot() || spotIndex != i){
										showArrivedSpotMessage();
									//	stayingOnSpot = true;
										
										// Para controlo de entrada em Spot
										overlayController.setSpotImage(spotEnterMark, i); 
										overlayController.getSpots().get(i).setStayingOnSpot(true);
										
										spotIndex = i;
									}

							//		enter_challenge.setVisibility(View.VISIBLE);
							}
							else{
								if(spotIndex == i && !overlayController.getSpots().get(i).isStayingOnSpot()){ // Saiu do Spot em que estava							
							//		enter_challenge.setVisibility(View.GONE);
									//stayingOnSpot = false;
									
									// Para controlo de entrada em Spot
									overlayController.setSpotImage(spotMark, i); // Coloca a Mark original
									overlayController.getSpots().get(i).setStayingOnSpot(false);
									
									spotIndex = -1;
									if(overlayController.getSpots().get(i).getChallenge().isComplete()){
										Log.d("SPOT COMPLETE", "CENAS");
										//overlayController.setSpotCompleteImage(spotCompleteMark, spotIndex);
									}
								}
							}
						}
					}
					
					break;
				}
		        }
			super.handleMessage(msg);
		}

	 };

	/**
	 * Invoked by the location service when phone's location changes.
	 */
	 public void onLocationChanged(Location newLocation) {
		setCurrentGpsLocation(newLocation);  	
	 }
	 
	protected void showArrivedSpotMessage() {
		Toast.makeText(this.getBaseContext(), "Objective reached, try the Challenge!", Toast.LENGTH_SHORT).show();
	}

	/**
	 * Resets the GPS location whenever the provider is enabled.
	 */
	 public void onProviderEnabled(String provider) {
		setCurrentGpsLocation(null);  	
	 }
	/**
	 * Resets the GPS location whenever the provider is disabled.
	 */
	 public void onProviderDisabled(String provider) {
		Toast.makeText(this.getBaseContext(), "GPS DISABLED", Toast.LENGTH_SHORT).show();
		setCurrentGpsLocation(null);  	
	 }
	/**
	 * Resets the GPS location whenever the provider status changes. We
	 * don't care about the details.
	 */
	 public void onStatusChanged(String provider, int status, Bundle extras) {
		setCurrentGpsLocation(null);  	
	 }

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override 
	public void onResume() {
		mLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 1, this);
		super.onResume();
	}

	@Override
	public void onPause() {
		mLocationManager.removeUpdates(this);
		super.onPause();
	}
	

}
