/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api.responses;

import com.questtrip.database.QuestDB;
import com.questtrip.database.SpotDB;

/**
 * @author Filipe Rodrigues
 *
 */
public class QuestDBResponse {
	boolean success = false;
	String info = "";
	private QuestDB[] data = null;
	
	public QuestDBResponse(boolean b, String i, QuestDB[] quests){
		this.success = b;
		this.info = i;
		
		if(success)
			this.data = quests;
	}
	
	public QuestDB[] getDBQuests(){
		if(success && data.length > 0 && data[0].getQuest_id() != null)
			return data;
		
		return null;
	}

}
