/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api.responses;

/**
 * @author Filipe Rodrigues
 *
 */
public class QuestImageResponse {
	boolean success = false;
	String info = "";
	private QuestImage data = null;
	
	public QuestImageResponse(boolean b, String i, QuestImage url){
		this.success = b;
		this.info = i;
		
		if(success)
			this.data = url;
	}
	
	public String getImage(){
		if(success)
			return data.image;
		
		return null;
	}

	
	public class QuestImage {
		String image = null;

	}
}
