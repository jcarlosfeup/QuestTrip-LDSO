/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api.responses;

import com.questtrip.models.Quest;

/**
 * @author Filipe Rodrigues
 *
 */
public class QuestsByNameResponse {
	boolean success = false;
	String info = "";
	private Quest[] data = null;
	
	public QuestsByNameResponse(boolean b, String i, Quest[] quests){
		this.success = b;
		this.info = i;
		
		if(success)
			this.data = quests;
	}
	
	public Quest[] getQuests(){
		if(success)
			return data;
		
		return null;
	}
}
