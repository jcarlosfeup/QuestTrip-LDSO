/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api.responses;

import com.questtrip.database.SpotDB;
import com.questtrip.models.Spot;

/**
 * @author Filipe Rodrigues
 *
 */
public class SpotDBResponse {
	boolean success = false;
	String info = "";
	private SpotDB[] data = null;
	
	public SpotDBResponse(boolean b, String i, SpotDB[] spots){
		this.success = b;
		this.info = i;
		
		if(success)
			this.data = spots;
	}
	
	public SpotDB[] getDBSpots(){
		if(success && data.length > 0 && data[0].getSpot_id() != null)
			return data;
		
		return null;
	}

}
