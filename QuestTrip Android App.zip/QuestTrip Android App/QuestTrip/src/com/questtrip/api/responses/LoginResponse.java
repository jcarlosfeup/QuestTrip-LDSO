/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api.responses;

import com.questtrip.models.User;


/**
 * @author Filipe Rodrigues
 *
 */
public class LoginResponse {
	
	boolean success = false;
	String info = "";
	User data = null;
	
	public LoginResponse(boolean b, String i, User d){
		this.success = b;
		this.info = i;
		
		if(success)
			this.data = d;
	}

	public User getUser(){
		return data;
	}
	
	public boolean getLoginStat(){
		return success;
	}
}
