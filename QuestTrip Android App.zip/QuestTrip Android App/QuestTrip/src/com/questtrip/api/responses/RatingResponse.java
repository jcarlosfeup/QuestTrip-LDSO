/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api.responses;

import com.questtrip.models.User;

/**
 * @author Filipe Rodrigues
 *
 */
public class RatingResponse {
	
	boolean success = false;
	String info = "";
	RatingAndAVGRating data = null;
	
	public RatingResponse(boolean b, String i, RatingAndAVGRating d){
		this.success = b;
		this.info = i;
		
		if(success)
			this.data = d;
	}
	
	public RatingAndAVGRating getData(){
		return this.data;
	}


	public class RatingAndAVGRating {
		private int rating = 0;
		private float avg = 0.0f;
		public float getAVGRating() {
			return avg;
		}
		public void setAVGRating(float avg) {
			this.avg = avg;
		}
		public int getRating() {
			return rating;
		}
		public void setRating(int rating) {
			this.rating = rating;
		}
		
	}
}
