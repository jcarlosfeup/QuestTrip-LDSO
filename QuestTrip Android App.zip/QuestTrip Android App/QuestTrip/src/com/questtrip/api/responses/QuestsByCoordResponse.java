/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api.responses;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.questtrip.models.Quest;

/**
 * @author Filipe Rodrigues
 *
 */
public class QuestsByCoordResponse {
	boolean success = false;
	String info = "";
	private Quest[] data = null;
	
	public QuestsByCoordResponse(boolean b, String i, Quest[] quests){
		this.success = b;
		this.info = i;
		
		if(success)
			this.data = quests;
	}
	
	public Quest[] getQuests(){
		if(success)
			return data;
		
		return null;
	}

}
