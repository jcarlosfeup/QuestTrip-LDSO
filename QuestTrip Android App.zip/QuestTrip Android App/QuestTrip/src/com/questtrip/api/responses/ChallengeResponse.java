/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api.responses;

import com.questtrip.models.challenge.Challenge;

/**
 * @author Filipe Rodrigues
 *
 */
public class ChallengeResponse {
	boolean success = false;
	String info = "";
	private Challenge data = null;
	
	public ChallengeResponse(boolean b, String i, Challenge ch){
		this.success = b;
		this.info = i;
		
		if(success)
			this.data = ch;
	}

	public Challenge getChallenge(){return this.data;}
}
