/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api.responses;

import com.questtrip.models.Spot;

/**
 * @author Filipe Rodrigues
 *
 */
public class SpotsByQuestResponse {
	boolean success = false;
	String info = "";
	private Spot[] data = null;
	
	public SpotsByQuestResponse(boolean b, String i, Spot[] spots){
		this.success = b;
		this.info = i;
		
		if(success)
			this.data = spots;
	}
	
	public Spot[] getSpots(){
		if(success)
			return data;
		
		return null;
	}

}
