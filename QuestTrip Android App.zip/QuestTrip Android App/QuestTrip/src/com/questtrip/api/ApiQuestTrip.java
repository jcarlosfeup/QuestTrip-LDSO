/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.api;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import android.net.Uri;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.questtrip.api.responses.ChallengeResponse;
import com.questtrip.api.responses.LoginResponse;
import com.questtrip.api.responses.QuestDBResponse;
import com.questtrip.api.responses.QuestImageResponse;
import com.questtrip.api.responses.QuestsByCoordResponse;
import com.questtrip.api.responses.QuestsByNameResponse;
import com.questtrip.api.responses.RatingResponse;
import com.questtrip.api.responses.SpotDBResponse;
import com.questtrip.api.responses.SpotsByQuestResponse;
import com.questtrip.models.Quest;
import com.questtrip.models.User;
import com.questtrip.models.challenge.Challenge;
import com.questtrip.models.variables.Variables;

/**
 * @author Filipe Rodrigues
 *
 */

public class ApiQuestTrip {


	public static HttpResponse makePostRequest(String uri, String json) {
		try {
			HttpPost httpPost = new HttpPost(uri);
			httpPost.setEntity(new StringEntity(json));
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			return new DefaultHttpClient().execute(httpPost);

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * [DEPRECATED]
	 * @param uri
	 * @param mLatitude
	 * @param mLongitude
	 * @return
	 */
	/*	public static HttpResponse makeGetRequest(String uri, String mLatitude, String mLongitude) {
		try {
			 JSONObject obj = new JSONObject();
				LinkedHashMap  coord = new LinkedHashMap();
				LinkedHashMap  m2 = new LinkedHashMap ();
				LinkedList l1 = new LinkedList();

			  obj.put("method", "questsByCoords");
			  coord.put("latitude", mLatitude);
			  coord.put("longitude", mLongitude);
			  obj.put("quest", coord);


			HttpParams params = new BasicHttpParams();
		//	params.s



			HttpGet httpGet = new HttpGet(uri);
			httpGet.setHeader("Accept", "application/json");
			httpGet.setHeader("Content-type", "application/json");
			return new DefaultHttpClient().execute(httpGet);

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	 */
	public static ChallengeResponse getChallenge(String challenge_id){
		Map method = new HashMap<String, String>();
		Map<String, String> chgID = new HashMap<String, String>();


		//  "{\"method\": \"getChallenge\", \"challenge\":{\"id\":\"1\"}}"
		chgID.put("id", challenge_id);

		method.put("method", "getChallenge");
		method.put("challenge", chgID);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/challenges", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);

		// Create Object from JSON String
		//	QuestsByCoordResponse  res = gson.fromJson(response_json, QuestsByCoordResponse.class);

		return gson.fromJson(response_json, ChallengeResponse.class);
	}

	public static SpotsByQuestResponse spotsByQuest(String quest_id){

		Map method = new HashMap<String, String>();
		Map quest = new HashMap<String, Map>();
		Map<String, String> questID = new HashMap<String, String>();

		questID.put("id", quest_id);

		method.put("method", "spotsByQuest");
		method.put("quest", questID);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/quests", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);

		// Create Object from JSON String
		//	QuestsByCoordResponse  res = gson.fromJson(response_json, QuestsByCoordResponse.class);

		return gson.fromJson(response_json, SpotsByQuestResponse.class);
	}

	public static QuestsByCoordResponse questsByCoord(String mLongitude, String mLatitude){

		Map method = new HashMap<String, String>();
		Map quest = new HashMap<String, Map>();
		Map<String, String> coordinates = new HashMap<String, String>();

		coordinates.put("latitude", mLatitude);
		coordinates.put("longitude", mLongitude);

		method.put("method", "questsByCoords");
		method.put("quest", coordinates);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/quests", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);

		// Create Object from JSON String
		//	QuestsByCoordResponse  res = gson.fromJson(response_json, QuestsByCoordResponse.class);

		return gson.fromJson(response_json, QuestsByCoordResponse.class);
	}


	public static LoginResponse login(String login, String pass){

		// Efectuar acesso � API e parse do JSON
		Map user = new HashMap<String, Map>();
		Map<String, String> log = new HashMap<String, String>();

		log.put("email", login);
		log.put("password", pass);
		user.put("user", log);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(user, Map.class);
		Log.d("JSON", json);
		HttpResponse loginState = makePostRequest(Variables.API_URL + "api/v1/sessions", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = loginState.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);

		// Create Object from JSON String
		LoginResponse res = gson.fromJson(response_json, LoginResponse.class);

		res.getUser().setPassword(pass);

		//	User logged = new User("Patinhas", "cenas", "cenas", "cenas", "http://pensandogrande.blob.core.windows.net/uploads/2012/06/tio-patinhas.jpg", "Rua S�samo"); 
		return res;
	}


	private static String convertStreamToString(InputStream is) {
		ByteArrayOutputStream oas = new ByteArrayOutputStream();
		copyStream(is, oas);
		String t = oas.toString();
		try {
			oas.close();
			oas = null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return t;
	}

	private static void copyStream(InputStream is, OutputStream os)
	{
		final int buffer_size = 1024;
		try
		{
			byte[] bytes=new byte[buffer_size];
			for(;;)
			{
				int count=is.read(bytes, 0, buffer_size);
				if(count==-1)
					break;
				os.write(bytes, 0, count);
			}
		}
		catch(Exception ex){}
	}

	/**
	 * @param quest_id
	 * @return
	 */
	public static String getQuestImage(String quest_id) {

		Map method = new HashMap<String, String>();
		Map quest = new HashMap<String, Map>();
		Map<String, String> questID = new HashMap<String, String>();

		questID.put("id", quest_id);

		method.put("method", "getImage");
		method.put("quest", questID);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/quests", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);


		QuestImageResponse res = gson.fromJson(response_json, QuestImageResponse.class);

		return Variables.API_URL + res.getImage();
	}


	public static void questRating(String email, String quest_id, int rating) {
		Map method = new HashMap<String, String>();
		Map quest = new HashMap<String, Map>();
		Map<String, String> params = new HashMap<String, String>();

		params.put("email", email);
		params.put("quest_id", quest_id);
		params.put("rating", String.valueOf(rating));

		method.put("method", "rating");
		method.put("quest", params);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/quests", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);

		// Create Object from JSON String gson.fromJson(response_json, QuestsByCoordResponse.class);
		//	QuestsByCoordResponse  res = gson.fromJson(response_json, QuestsByCoordResponse.class);
	}


	public static RatingResponse getQuestRatingAndAVGRating(String email, String quest_id) {


		Map method = new HashMap<String, String>();
		Map quest = new HashMap<String, Map>();
		Map<String, String> params = new HashMap<String, String>();

		params.put("email", email);
		params.put("quest_id", quest_id);

		method.put("method", "getRating");
		method.put("quest", params);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/quests", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);

		// Create Object from JSON String gson.fromJson(response_json, QuestsByCoordResponse.class);
		return gson.fromJson(response_json, RatingResponse.class);
	}

	/**
	 * @param string
	 * @param string2
	 * @param string3
	 * @return
	 */
	public static void setSpotCompleted(String chd_id, String login, String score) {
		Map method = new HashMap<String, String>();
		Map quest = new HashMap<String, Map>();
		Map<String, String> params = new HashMap<String, String>();

		params.put("spot_id", chd_id);
		params.put("email", login);
		params.put("score", score);

		method.put("method", "setSpotCompleted");
		method.put("spot", params);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/spots", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);
	}

	public static SpotDBResponse getQuestInfo(String quest_id, String login){

		Map method = new HashMap<String, String>();
		Map quest = new HashMap<String, Map>();
		Map<String, String> params = new HashMap<String, String>();

		params.put("quest_id", quest_id);
		params.put("email", login);

		method.put("method", "getQuestInfo");
		method.put("quest", params);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/quests", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);

		//  Create Object from JSON String
		//	QuestsByCoordResponse  res = gson.fromJson(response_json, QuestsByCoordResponse.class);

		return gson.fromJson(response_json, SpotDBResponse.class);
	}

	/**
	 * @param login
	 * @return
	 */
	public static QuestDBResponse getUserAllQuests(String login) {

		Map method = new HashMap<String, String>();
		Map quest = new HashMap<String, Map>();
		Map<String, String> params = new HashMap<String, String>();
		params.put("email", login);

		method.put("method", "getUserAllQuests");
		method.put("quest", params);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/quests", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);

		//  Create Object from JSON String
		//	QuestsByCoordResponse  res = gson.fromJson(response_json, QuestsByCoordResponse.class);

		return gson.fromJson(response_json, QuestDBResponse.class);
	}
	
	public static QuestsByNameResponse questsByName(String name){

		Map method = new HashMap<String, String>();
		Map quest = new HashMap<String, Map>();
		
		Map<String, String> params = new HashMap<String, String>();
		params.put("name", name);

		method.put("method", "questsByName");
		method.put("quest", params);

		Gson gson = new Gson();
		String json = new GsonBuilder().create().toJson(method, Map.class);

		Log.d("JSON", json);

		// Efectuar acesso � API e parse do JSON
		HttpResponse queryQuests = makePostRequest(Variables.API_URL + "api/v1/quests", json);


		// Convert data response do JSON String
		InputStream is = null;
		try {
			is = queryQuests.getEntity().getContent();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		String response_json = convertStreamToString(is);

		Log.d("RESPONSE", response_json);

		// Create Object from JSON String
		//	QuestsByCoordResponse  res = gson.fromJson(response_json, QuestsByCoordResponse.class);

		return gson.fromJson(response_json, QuestsByNameResponse.class);
	}
}
