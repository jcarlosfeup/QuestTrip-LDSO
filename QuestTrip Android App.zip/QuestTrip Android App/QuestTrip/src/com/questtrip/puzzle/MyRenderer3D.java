package com.questtrip.puzzle;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Collections;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import com.questtrip.view.R;


import android.content.Context;
import android.graphics.Bitmap;
import android.opengl.GLSurfaceView.Renderer;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.Toast;

public class MyRenderer3D implements Renderer {
	private Context mContext; 

	
	// Puzzle pieces
	private int PUZZLE_SIDE = 3; // 2 ; 3 ; 4
	private Bitmap image = null;
	
	// Snake
	Vector<Vector<Body_Square> > puzzle = null;
	Body_Square square = null;

	// Camera Limits
	private float size_cam = 0;
	private float margin_limit; // CHANGE MAP SIZE ;    
	private float camDistanceFixed = size_cam; // CHANGE MAP SIZE ;  

	// Som
	Sound soundManager;

	int width, height;
	float aspect, zFar;

	// Flag para controlar actualizacoes de ciclo de jogo
	boolean actualizaCicloDeJogo = false;

	// Flag de final de jogo
	boolean GAME_OVER = false;


	// Bloco colocado
	Random rand = new Random();


	private long STATE_CHECK = 110; // Check state a cada STATE_CHECK millis
	String head_key;

	// Flags de controlo de movimento do player
	private boolean newMovement = false;
	private int movement = 0; // 0 = esquerda ; 1 = cima ; 2 = direita ; 3 = baixo
	private Cursor cursor = new Cursor(0,0);
	

	// Time Counter
	long finalTime = 0;
	long iniTime = 0;
	boolean verifInitialTime = false;


	// Para movimento de camera
	public float mAngleX = 0.0f;
	public float mAngleY = 0.0f;
	public float mAngleZ = 0.0f; 
	private boolean movingCamera = true;
	@SuppressWarnings("unused")
	private boolean viewChanged = false;
	private float mPreviousX; 
	private float mPreviousY; 
	private final float TOUCH_SCALE_FACTOR = 0.6f; 


	// Variaveis Anima��o Camera
	float ang_rot_cam_x = 0.0f, ang_rot_cam_y = 0.0f;


	// Play Field
	PlayMap3D map = null;



	/* 
	 * The initial light values for ambient and diffuse
	 * as well as the light position ( NEW ) 
	 */
	private float[] lightAmbient = {1.0f, 1.0f, 1.0f, 1.0f};
	private float[] lightDiffuse = {1.0f, 1.0f, 1.0f, 1.0f};
	private float[] lightPosition = {0.0f, 0.0f, 0.0f, 1.0f};

	/* The buffers for our light values ( NEW ) */
	private FloatBuffer lightAmbientBuffer;
	private FloatBuffer lightDiffuseBuffer;
	private FloatBuffer lightPositionBuffer;


	public MyRenderer3D(Context context, int width, int height, Bitmap img, int s) { 
		mContext = context; 
		
		this.width = width;
		this.height = height;
		
		this.image = img;
		this.PUZZLE_SIDE = s;

		switch(Start_Game.MAP_SIZE){ // Small = 11.0f ; Normal = 17.0f ; Big = 23.0f
		case 0:
			size_cam = 3.0f;
			PUZZLE_SIDE = 2; // 2 ; 3 ; 4
			break;
		case 1:
			size_cam = 5.0f;	
			PUZZLE_SIDE = 3; // 2 ; 3 ; 4
			break;
		case 2:
			size_cam = 6.0f;
			PUZZLE_SIDE = 4; // 2 ; 3 ; 4
			break;
		}

		switch(Start_Game.MAP_SIZE){ // Slow = 150 ; Normal = 100 ; Fast = 50
		case 0:
			STATE_CHECK = 150;
			break;
		case 1:
			STATE_CHECK = 100;
			break;
		case 2:
			STATE_CHECK = 50;
			break;
		}

		initializeMapSizeParameters(); // INICIALIZA OS PARAMETROS UTILIZADOS PARA MUDAR TAMANHO DO MAPA


		ByteBuffer byteBuf = ByteBuffer.allocateDirect(lightAmbient.length * 4);
		byteBuf.order(ByteOrder.nativeOrder());
		lightAmbientBuffer = byteBuf.asFloatBuffer();
		lightAmbientBuffer.put(lightAmbient);
		lightAmbientBuffer.position(0);

		byteBuf = ByteBuffer.allocateDirect(lightDiffuse.length * 4);
		byteBuf.order(ByteOrder.nativeOrder());
		lightDiffuseBuffer = byteBuf.asFloatBuffer();
		lightDiffuseBuffer.put(lightDiffuse);
		lightDiffuseBuffer.position(0);

		byteBuf = ByteBuffer.allocateDirect(lightPosition.length * 4);
		byteBuf.order(ByteOrder.nativeOrder());
		lightPositionBuffer = byteBuf.asFloatBuffer();
		lightPositionBuffer.put(lightPosition);
		lightPositionBuffer.position(0);




		initSounds();
		//	block = new BodySquareProperties(6.0f, 2.0f, false, false, false, false, false);


	
		puzzle = new Vector<Vector<Body_Square> >();
		
		int x_increment = 0, y_increment = 0, puzzleOrder = 0;
		for(int y = 0; y < PUZZLE_SIDE; y++, y_increment-=2){
			Vector<Body_Square> temp = new Vector<Body_Square>(PUZZLE_SIDE);
			puzzle.add(temp);
			for(int x = 0; x < PUZZLE_SIDE; x++, x_increment+=2){						
				puzzle.get(y).add(new Body_Square(PUZZLE_SIDE, puzzleOrder));
				
				puzzle.get(y).get(x).setPosition(x_increment, y_increment, 0);
				
				puzzleOrder++;
			}
			x_increment = 0;
		}
		shufflePuzzle();
		
		map = new PlayMap3D(size_cam);
	}
	
	private void shufflePuzzle(){
		int numPecas = PUZZLE_SIDE*PUZZLE_SIDE;
		Vector<Vector<Body_Square> > shuffle = new Vector<Vector<Body_Square> >();
		
		for(int i = 0; i < PUZZLE_SIDE; i++){
			shuffle.add(new Vector<Body_Square>(PUZZLE_SIDE));
		//	for(int j = 0; j < PUZZLE_SIDE; j++)
		//		shuffle.get(i).add(null);
			
		//	Log.d("TAMANHO INSIDE "+i, shuffle.get(i).size()+"");
		}

		
		/**
		 *  1 - Vai buscar todas as posi��es, excepto do cursor vazio
		 *  2 - Preenche array com os indices todos
		 */
		Vector<Integer> indexVec = new Vector<Integer>();
		int value = 1;
		Vector<Coord> positions = new Vector<Coord>();
		for(int y = 0; y < PUZZLE_SIDE; y++){
			for(int x = 0; x < PUZZLE_SIDE; x++){	
					positions.add(new Coord(puzzle.get(y).get(x).getX(), puzzle.get(y).get(x).getY(), puzzle.get(y).get(x).getZ()));
					
					if(value < PUZZLE_SIDE*PUZZLE_SIDE)
						indexVec.add(value);
					value++;
			}
		}
		
		// Shuffle dos indices
		Collections.shuffle(indexVec);
		// Coloca o cursor vazio no shuffleVec
		Body_Square vazio = new Body_Square(PUZZLE_SIDE, puzzle.get(0).get(0).getPuzzleOrder());
		vazio.setPosition(0, 0, 0);
		shuffle.get(0).add(vazio);
		
		
		int x_increment = 0, y_increment = 0;
		int index = 0;
		for(int y = 0; y < PUZZLE_SIDE; y++, y_increment-=2){
			for(int x = 0; x < PUZZLE_SIDE; x++, x_increment+=2){	
				if(x == 0 && y == 0){} // Nao conta o cursor
				else{
					int puzzleIndex = indexVec.get(index);
					
					Body_Square temp = new Body_Square(PUZZLE_SIDE, puzzleIndex);
					// Coloca a posi��o do cursor
					temp.setPosition(x_increment, y_increment, 0);
					
					shuffle.get(y).add(temp);
					
					index++;
				}
			}
			x_increment = 0;
		}

		
		puzzle.clear();
		puzzle = (Vector<Vector<Body_Square>>) shuffle.clone();
	}

	private void initializeMapSizeParameters(){
		// Camera
		camDistanceFixed = size_cam/3; // CHANGE MAP SIZE ;   Se MapSize = 17 => camDistanceFixed = 17

		// Board Limits
		margin_limit = size_cam + 1.0f; // CHANGE MAP SIZE ;       Se MapSize = 17 => margin_limit = 18
	}


	private void initSounds() {
		soundManager = new Sound();
		soundManager.initSounds(mContext);
		soundManager.addSound(1, R.raw.tada);
	}


	public void onSurfaceCreated(GL10 gl, EGLConfig config) { 
		/*	
		//And there'll be light!
		gl.glLightfv(GL10.GL_LIGHT0, GL10.GL_AMBIENT, lightAmbientBuffer);		//Setup The Ambient Light ( NEW )
	//	gl.glLightfv(GL10.GL_LIGHT0, GL10.GL_DIFFUSE, lightDiffuseBuffer);		//Setup The Diffuse Light ( NEW )
	//	gl.glLightfv(GL10.GL_LIGHT0, GL10.GL_POSITION, lightPositionBuffer);	//Position The Light ( NEW )
		gl.glEnable(GL10.GL_LIGHT0);	
		 */	


		//Blending
		gl.glColor4f(1.0f, 1.0f, 1.0f, 0.95f);				//Full Brightness. 50% Alpha ( NEW )
		gl.glBlendFunc(GL10.GL_DST_COLOR, GL10.GL_ONE_MINUS_SRC_ALPHA);		//Set The Blending Function For Translucency ( NEW )

		//Settings
		gl.glDisable(GL10.GL_DITHER);				//Disable dithering
		gl.glEnable(GL10.GL_TEXTURE_2D);			//Enable Texture Mapping
		gl.glShadeModel(GL10.GL_SMOOTH); 			//Enable Smooth Shading
		gl.glClearColor(0.2f, 0.8f, 1.0f, 0.0f); /* blue sky */		
		gl.glClearDepthf(1.0f); 					//Depth Buffer Setup
		gl.glEnable(GL10.GL_DEPTH_TEST); 			//Enables Depth Testing
		gl.glDepthFunc(GL10.GL_LEQUAL); 			//The Type Of Depth Testing To Do

		gl.glEnable(GL10.GL_CULL_FACE);
		gl.glCullFace(GL10.GL_BACK);

		//Really Nice Perspective Calculations
		gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, GL10.GL_NICEST); 


		//Load the texture for the cube once during Surface creation
		//body.loadGLTexture(gl, this.mContext);
		for(int i = 0; i < PUZZLE_SIDE; i++){
			for(int j = 0; j < PUZZLE_SIDE; j++){
				puzzle.get(i).get(j).loadGLTexture(gl, this.mContext, image);
			}
		}
		map.loadGLTexture(gl, this.mContext);
	} 


	public void onDrawFrame(GL10 gl) {
		gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
		
//		Log.d("POSITION", puzzle.get(cursor.getY()).get(cursor.getX()).getPuzzleOrder()+"");
		// Move Camera
		chooseCamera(gl);

		// Desenha Mapa
		map.draw(gl);
		
		// Desenha Puzzle
		for(int i = 0; i < PUZZLE_SIDE; i++){
			for(int j = 0; j < PUZZLE_SIDE; j++){	
				
				if(cursor.getX() == j && cursor.getY() == i){
					// N�o desenha, pois � o cursor vazio
				}
				else{
					gl.glPushMatrix();
					gl.glTranslatef(puzzle.get(i).get(j).getX(), puzzle.get(i).get(j).getY(), puzzle.get(i).get(j).getZ());
					
					puzzle.get(i).get(j).draw(gl);
					gl.glPopMatrix();
				}
			}
		}

		// Actualizacao da variavel de movimento
		if(!GAME_OVER){
			if(!verifInitialTime){
				verifInitialTime = true;
				iniTime = System.currentTimeMillis();
				finalTime = System.currentTimeMillis();
			}
			else
				finalTime = System.currentTimeMillis();

			if((finalTime - iniTime) >= STATE_CHECK && !actualizaCicloDeJogo){

				actualizaCicloDeJogo = true;
				if(newMovement){
					newMovement = false;
					
					switch(movement){
						case 0:{ // Peca da Esquerda
							if(validMovement(0)){
								// m�todo que troca as c�lulas da matriz
								makeMovement(gl, 0);
							}
						}
						break;
						case 1:{ // Peca de Cima
							if(validMovement(1)){
								// m�todo que troca as c�lulas da matriz
								makeMovement(gl, 1);
							}
						}
						break;
						case 2:{ // Peca da Direita
							if(validMovement(2)){
								// m�todo que troca as c�lulas da matriz
								makeMovement(gl, 2);
							}
						}
						break;
						case 3:{ // Peca de Baixo
							if(validMovement(3)){
								// m�todo que troca as c�lulas da matriz
								makeMovement(gl, 3);
							}
						}
						break;
					}
				}

				checkGameOver();

				finalTime = 0;
				iniTime = 0;
				verifInitialTime = false;
				actualizaCicloDeJogo = false;
			}
		}


		gl.glLoadIdentity();
	}

	
	private void makeMovement(GL10 gl, int movement) {
		switch(movement){
			case 0:{ // Peca da Esquerda
				Body_Square origem = new Body_Square(PUZZLE_SIDE, puzzle.get(cursor.getY()).get(cursor.getX()-1).getPuzzleOrder());
				// Coloca a posi��o do cursor
				origem.setPosition(puzzle.get(cursor.getY()).get(cursor.getX()).getX(), 
									puzzle.get(cursor.getY()).get(cursor.getX()).getY(), 
									puzzle.get(cursor.getY()).get(cursor.getX()).getZ());
				origem.loadGLTexture(gl, mContext, image);
				
				Body_Square vazio = new Body_Square(PUZZLE_SIDE, puzzle.get(cursor.getY()).get(cursor.getX()).getPuzzleOrder());
				// Coloca a nova posi��o do cursor
				vazio.setPosition(puzzle.get(cursor.getY()).get(cursor.getX()-1).getX(), 
						puzzle.get(cursor.getY()).get(cursor.getX()-1).getY(), 
						puzzle.get(cursor.getY()).get(cursor.getX()-1).getZ());
				vazio.loadGLTexture(gl, mContext, image);
				
				// Troca os elementos no Vector
				puzzle.get(cursor.getY()).set(cursor.getX(), origem);
				puzzle.get(cursor.getY()).set(cursor.getX()-1, vazio);
				
				//origem.setPosition(10, 2, 5);
				
				cursor.decX();
	
			} break;
			case 1:{ // Peca de Cima
				Body_Square origem = new Body_Square(PUZZLE_SIDE, puzzle.get(cursor.getY()-1).get(cursor.getX()).getPuzzleOrder());
				// Coloca a posi��o do cursor
				origem.setPosition(puzzle.get(cursor.getY()).get(cursor.getX()).getX(), 
									puzzle.get(cursor.getY()).get(cursor.getX()).getY(), 
									puzzle.get(cursor.getY()).get(cursor.getX()).getZ());
				origem.loadGLTexture(gl, mContext, image);
				
				Body_Square vazio = new Body_Square(PUZZLE_SIDE, puzzle.get(cursor.getY()).get(cursor.getX()).getPuzzleOrder());
				// Coloca a nova posi��o do cursor
				vazio.setPosition(puzzle.get(cursor.getY()-1).get(cursor.getX()).getX(), 
						puzzle.get(cursor.getY()-1).get(cursor.getX()).getY(), 
						puzzle.get(cursor.getY()-1).get(cursor.getX()).getZ());
				vazio.loadGLTexture(gl, mContext, image);
				
				// Troca os elementos no Vector
				puzzle.get(cursor.getY()).set(cursor.getX(), origem);
				puzzle.get(cursor.getY()-1).set(cursor.getX(), vazio);
				
				//origem.setPosition(10, 2, 5);
				
				cursor.decY();
			} break;
			case 2:{ // Peca da Direita
				Body_Square origem = new Body_Square(PUZZLE_SIDE, puzzle.get(cursor.getY()).get(cursor.getX()+1).getPuzzleOrder());
				// Coloca a posi��o do cursor
				origem.setPosition(puzzle.get(cursor.getY()).get(cursor.getX()).getX(), 
									puzzle.get(cursor.getY()).get(cursor.getX()).getY(), 
									puzzle.get(cursor.getY()).get(cursor.getX()).getZ());
				origem.loadGLTexture(gl, mContext, image);
				
				Body_Square vazio = new Body_Square(PUZZLE_SIDE, puzzle.get(cursor.getY()).get(cursor.getX()).getPuzzleOrder());
				// Coloca a nova posi��o do cursor
				vazio.setPosition(puzzle.get(cursor.getY()).get(cursor.getX()+1).getX(), 
						puzzle.get(cursor.getY()).get(cursor.getX()+1).getY(), 
						puzzle.get(cursor.getY()).get(cursor.getX()+1).getZ());
				vazio.loadGLTexture(gl, mContext, image);
				
				// Troca os elementos no Vector
				puzzle.get(cursor.getY()).set(cursor.getX(), origem);
				puzzle.get(cursor.getY()).set(cursor.getX()+1, vazio);
				
				//origem.setPosition(10, 2, 5);
				
				cursor.incX();
			} break;
			case 3:{ // Peca de Baixo
				Body_Square origem = new Body_Square(PUZZLE_SIDE, puzzle.get(cursor.getY()+1).get(cursor.getX()).getPuzzleOrder());
				// Coloca a posi��o do cursor
				origem.setPosition(puzzle.get(cursor.getY()).get(cursor.getX()).getX(), 
									puzzle.get(cursor.getY()).get(cursor.getX()).getY(), 
									puzzle.get(cursor.getY()).get(cursor.getX()).getZ());
				origem.loadGLTexture(gl, mContext, image);
				
				Body_Square vazio = new Body_Square(PUZZLE_SIDE, puzzle.get(cursor.getY()).get(cursor.getX()).getPuzzleOrder());
				// Coloca a nova posi��o do cursor
				vazio.setPosition(puzzle.get(cursor.getY()+1).get(cursor.getX()).getX(), 
						puzzle.get(cursor.getY()+1).get(cursor.getX()).getY(), 
						puzzle.get(cursor.getY()+1).get(cursor.getX()).getZ());
				vazio.loadGLTexture(gl, mContext, image);
				
				// Troca os elementos no Vector
				puzzle.get(cursor.getY()).set(cursor.getX(), origem);
				puzzle.get(cursor.getY()+1).set(cursor.getX(), vazio);
				
				//origem.setPosition(10, 2, 5);
				
				cursor.incY();
			} break;
		}		
	}

	private boolean validMovement(int movement){
		
		switch(PUZZLE_SIDE){
			case 2:{ // Tamanho do Puzzle
				switch(movement){
					case 0:{ // Peca da Esquerda
						if(cursor.getX() == 1)
							return true;
					} break;
					case 1:{ // Peca de Cima
						if(cursor.getY() == 1)
							return true;
					} break;
					case 2:{ // Peca da Direita
						if(cursor.getX() == 0)
							return true;
					} break;
					case 3:{ // Peca da Baixo
						if(cursor.getY() == 0)
							return true;
					} break;
				}
			}
			break;
			case 3:{
				switch(movement){
					case 0:{ // Peca da Esquerda
						if(cursor.getX() != 0)
							return true;
					} break;
					case 1:{ // Peca de Cima
						if(cursor.getY() != 0)
							return true;
					} break;
					case 2:{ // Peca da Direita
						if(cursor.getX() != 2)
							return true;
					} break;
					case 3:{ // Peca da Baixo
						if(cursor.getY() != 2)
							return true;
					} break;
				}
			}
			break;
			case 4:{
				switch(movement){
				case 0:{ // Peca da Esquerda
					if(cursor.getX() != 0)
						return true;
				} break;
				case 1:{ // Peca de Cima
					if(cursor.getY() != 0)
						return true;
				} break;
				case 2:{ // Peca da Direita
					if(cursor.getX() != 3)
						return true;
				} break;
				case 3:{ // Peca da Baixo
					if(cursor.getY() != 3)
						return true;
				} break;
			}
			}
			break;
		}
		
		return false;
	}

	private void chooseCamera(GL10 gl) {
		if(!getMovingCamera()){
			gl.glMatrixMode(GL10.GL_MODELVIEW);
			gl.glLoadIdentity();

			gl.glTranslatef(-PUZZLE_SIDE/2, PUZZLE_SIDE/2, -(camDistanceFixed + margin_limit));
			gl.glRotatef(0, 1, 0, 0);			// Final = 0�
			gl.glRotatef(0, 0, 1, 0); 					// Final = 0�	

			gl.glRotatef(mAngleX, 1, 0, 0);
			gl.glRotatef(mAngleY, 0, 1, 0);
			gl.glRotatef(mAngleZ, 0, 0, 1);

		}
		else{
			gl.glMatrixMode(GL10.GL_MODELVIEW);
			gl.glLoadIdentity();

			gl.glTranslatef(-PUZZLE_SIDE/2, PUZZLE_SIDE/2, -(camDistanceFixed + margin_limit));
			gl.glRotatef(ang_rot_cam_x, 1, 0, 0);			// Final = 0�
			gl.glRotatef(ang_rot_cam_y, 0, 1, 0); 					// Final = 0�	

			gl.glRotatef(mAngleX, 1, 0, 0);
			gl.glRotatef(mAngleY, 0, 1, 0);
			gl.glRotatef(mAngleZ, 0, 0, 1);	
		}
	}



	private void checkGameOver() {
		
		int verif = 0;
		// Desenha Puzzle
		for(int i = 0; i < PUZZLE_SIDE; i++){
			for(int j = 0; j < PUZZLE_SIDE; j++){	
				if(puzzle.get(i).get(j).getPuzzleOrder() != verif){
					return;
				}
				verif++;
			}
		}
		
		GAME_OVER = true;
	}



	public void onSurfaceChanged(GL10 gl, int width, int height) { 
		gl.glViewport(0, 0, width, height);
		aspect = (float)width / height;

		zFar = 130; // Num ecra de 480*800, ZFar = 150

		gl.glMatrixMode(GL10.GL_PROJECTION);

		gl.glLoadIdentity();
		gl.glFrustumf(-aspect, aspect, -1.0f, 1.0f, 1.0f, zFar);

		gl.glMatrixMode(GL10.GL_MODELVIEW); 	//Select The Modelview Matrix
		gl.glLoadIdentity(); 					//Reset The Modelview Matrix

	} 


	public boolean onTouchEvent(MotionEvent e) { 
		float x = e.getX();
		float y = e.getY();
		switch (e.getAction()) { 
		case MotionEvent.ACTION_MOVE: 
			float dx = x - mPreviousX; 
			float dy = y - mPreviousY; 

			mAngleY = (mAngleY + (int)(dx * TOUCH_SCALE_FACTOR) + 360) % 360; 
			mAngleX = (mAngleX + (int)(dy * TOUCH_SCALE_FACTOR) + 360) % 360; 
			break; 
		} 

		mPreviousX = x; 
		mPreviousY = y; 

		viewChanged = true;
		return true; 
	}


	public void cameraReset() {
		mAngleX = 0.0f; 
		mAngleY = 0.0f;
		mAngleZ = 0.0f; 

		viewChanged = true;
	}

	public boolean isNewMovement() {
		return newMovement;
	}



	public void setNewMovement(boolean newMovement, int mov) {
		this.newMovement = newMovement;
		this.movement = mov;
	}

	public void cameraChange() {
		if(getMovingCamera())
			setMovingCamera(false);
		else
			setMovingCamera(true);

	}



	public boolean getMovingCamera() {
		return movingCamera;
	}



	public void setMovingCamera(boolean lookAtView) {
		this.movingCamera = lookAtView;
	}



}
