package com.questtrip.puzzle;


import com.questtrip.view.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.Chronometer;
import android.widget.Chronometer.OnChronometerTickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Start_Game extends Activity {
	public static final int MAP_SIZE = 1;

	// HUD
	TextView secondsPassed;
	long startTime;
	long countUp;
	private ImageButton cameraReset, buttonLeft, buttonRight, buttonTop, buttonDown;
	private boolean game_over_sound_played = false;
	private int CONTROL_BUTTON_WIDTH = 0;

	private GLSurfaceView mView; 
	private MyRenderer3D mRenderer3D; 
	int width = 0;
	int height = 0;

	Chronometer stopWatch;

	// Ranking Submission
	AlertDialog.Builder alert;
	EditText inputName;
	Context ctx;
	Intent rankingIntent = null;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ctx = this;

		//	this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		// Rank Submission
		alert = new AlertDialog.Builder(this);
		inputName = new EditText(this);

		WindowManager w = getWindowManager();
		Display d = w.getDefaultDisplay();

		width = d.getWidth();
		height = d.getHeight();


		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		mView = new GLSurfaceView(this); 


		Bundle info = getIntent().getExtras();
		Bitmap image = info.getParcelable("image");
		int size = info.getInt("size");

		mRenderer3D = new MyRenderer3D(this, width, height, image, size); 
		mView.setRenderer(mRenderer3D); 


		// HUD
		setContentView( R.layout.main );
		LinearLayout openGLLayout = (LinearLayout)findViewById(R.id.openGLLayout);
		openGLLayout.addView(mView);

		CONTROL_BUTTON_WIDTH = width/6;
		buttonLeft = (ImageButton)findViewById(R.id.button_left);
		buttonLeft.getLayoutParams().width = CONTROL_BUTTON_WIDTH;

		buttonRight = (ImageButton)findViewById(R.id.button_right);
		buttonRight.getLayoutParams().width = CONTROL_BUTTON_WIDTH;

		buttonTop = (ImageButton)findViewById(R.id.button_top);
		buttonTop.getLayoutParams().width = CONTROL_BUTTON_WIDTH;
		
		buttonDown = (ImageButton)findViewById(R.id.button_down);
		buttonDown.getLayoutParams().width = CONTROL_BUTTON_WIDTH;

		makeLeftButtonAction();
		makeRightButtonAction();
		makeTopButtonAction();
		makeDownButtonAction();




		// HUD - Camera Reset
		cameraReset = (ImageButton)findViewById(R.id.camera_reset);
		this.cameraReset.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				mRenderer3D.cameraReset(); 
				
			}
		});




		// HUD - Seconds Counter
		secondsPassed = (TextView)findViewById(R.id.secondsPassed);
		stopWatch = (Chronometer) findViewById(R.id.chrono);
		startTime = SystemClock.elapsedRealtime();
		stopWatch.setOnChronometerTickListener(new OnChronometerTickListener(){
			public void onChronometerTick(Chronometer arg0) {
				if(!mRenderer3D.GAME_OVER){
					countUp = (SystemClock.elapsedRealtime() - arg0.getBase()) / 1000;
					String asText = String.valueOf(countUp); 
					secondsPassed.setText(asText);
				}
				else{
				
					if(!game_over_sound_played){
						mRenderer3D.soundManager.playSound(1);
						game_over_sound_played = true;
					}
					
					createLoginDialog().show();
					stopWatch.stop();
				}
			}
		});
		stopWatch.start();


	}
	
	/**
	 * Fun��o que inicializa o Dialog customizado de Game Over
	 * @return
	 */
	private AlertDialog createLoginDialog() {
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		// use a custom View defined in xml
		final View view = LayoutInflater.from(this).inflate(R.layout.game_over_puzzle_dialog, null);
		builder.setView(view);
		builder.setTitle("Congratulations");
		builder.setPositiveButton("Ok", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {

			//	startProgressDialog();

			//	new loginQueryAPITask().execute(login, pass);
			}

		});
		builder.setNegativeButton("Cancel", new OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {	        	
			}

		});
		final AlertDialog alertDialog = builder.create();
		return alertDialog;
	}

	private void makeRightButtonAction() {
		this.buttonRight.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				mRenderer3D.setNewMovement(true, 2);
			}
		});

	}

	private void makeLeftButtonAction() {
		this.buttonLeft.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				mRenderer3D.setNewMovement(true, 0);
			}
		});
	}
	
	private void makeTopButtonAction() {
		this.buttonTop.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				mRenderer3D.setNewMovement(true, 1);
			}
		});

	}

	private void makeDownButtonAction() {
		this.buttonDown.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				mRenderer3D.setNewMovement(true, 3);
			}
		});
	}


	public boolean onTouchEvent(MotionEvent event) {
		return mRenderer3D.onTouchEvent(event);
	}
	
	public void getBackToChoose_Game(){
    	if(mRenderer3D.GAME_OVER)
    		setResult(RESULT_OK);     
    	else
    		setResult(RESULT_CANCELED);    
    	
    	
    	finish();
	}
	
    public void onBackPressed() {
    	getBackToChoose_Game();

        return;
    } 

}