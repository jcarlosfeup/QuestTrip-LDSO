package com.questtrip.puzzle;



public class Coord {
	private float x = 0.0f, y = 0.0f, z = 0.0f;
	
	public Coord(float x, float y){
		this.setX(x);
		this.setY(y);
	}

	public Coord(float x, float y, float z) {
		this.x = x;
		this.y = y;
		this.setZ(z);
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public void incValues(float x2, float y2) {
		x += x2;
		y += y2;	
	}

	public void incValues(float x2, float y2, float z2) {
		x += x2;
		y += y2;
		setZ(getZ() + z2);
	}

	public float getZ() {
		return z;
	}

	public void setZ(float z) {
		this.z = z;
	}
	

}
