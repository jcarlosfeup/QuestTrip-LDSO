package com.questtrip.puzzle;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.opengles.GL10;

import com.questtrip.view.R;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLUtils;


public class PlayMap3D {

	/** The buffer holding the vertices */
	private FloatBuffer vertexBuffer, vertexBufferImposters;
	/** The buffer holding the texture coordinates */
	private FloatBuffer textureBuffer, textureBufferImposters;
	/** The buffer holding the indices */
	private ByteBuffer indexBuffer, indexBufferImposters;
	/** The buffer holding the normals */
	private FloatBuffer normalBuffer;

	/** Our texture pointer */
	private int[] textures = new int[2];
	
	private float imposterDistance = 50.0f;
	
	private float size = 0;// CHANGE MAP SIZE
	
	
	private float verticesImposter[] = {
			// Vertices according to faces
			-imposterDistance, -imposterDistance, imposterDistance, //Vertex 0
    		imposterDistance, -imposterDistance, imposterDistance,  //v1
    		-imposterDistance, imposterDistance, imposterDistance,  //v2
    		imposterDistance, imposterDistance, imposterDistance,   //v3
    		
    		imposterDistance, -imposterDistance, imposterDistance,	//...
    		imposterDistance, -imposterDistance, -imposterDistance,    		
    		imposterDistance, imposterDistance, imposterDistance,
    		imposterDistance, imposterDistance, -imposterDistance,
    		
    		imposterDistance, -imposterDistance, -imposterDistance,
    		-imposterDistance, -imposterDistance, -imposterDistance,    		
    		imposterDistance, imposterDistance, -imposterDistance,
    		-imposterDistance, imposterDistance, -imposterDistance,
    		
    		-imposterDistance, -imposterDistance, -imposterDistance,
    		-imposterDistance, -imposterDistance, imposterDistance,    		
    		-imposterDistance, imposterDistance, -imposterDistance,
    		-imposterDistance, imposterDistance, imposterDistance,
    		
    		-imposterDistance, -imposterDistance, -imposterDistance,
    		imposterDistance, -imposterDistance, -imposterDistance,    		
    		-imposterDistance, -imposterDistance, imposterDistance,
    		imposterDistance, -imposterDistance, imposterDistance,
    		
    		-imposterDistance, imposterDistance, imposterDistance,
    		imposterDistance, imposterDistance, imposterDistance,    		
    		-imposterDistance, imposterDistance, -imposterDistance,
    		imposterDistance, imposterDistance, -imposterDistance,
								};


	/** The initial vertex definition */
	private float vertices[] = null;

	/** The initial normals for the lighting calculations */	
	private float normals[] = {
						//Normals
						0.0f, 0.0f, 1.0f, 						
						0.0f, 0.0f, -1.0f, 
						0.0f, 1.0f, 0.0f, 
						0.0f, -1.0f, 0.0f, 
						
						0.0f, 0.0f, 1.0f, 
						0.0f, 0.0f, -1.0f, 
						0.0f, 1.0f, 0.0f, 
						0.0f, -1.0f, 0.0f,
						
						0.0f, 0.0f, 1.0f, 
						0.0f, 0.0f, -1.0f, 
						0.0f, 1.0f, 0.0f, 
						0.0f, -1.0f, 0.0f,
						
						0.0f, 0.0f, 1.0f, 
						0.0f, 0.0f, -1.0f, 
						0.0f, 1.0f, 0.0f, 
						0.0f, -1.0f, 0.0f,
						
						0.0f, 0.0f, 1.0f, 
						0.0f, 0.0f, -1.0f, 
						0.0f, 1.0f, 0.0f, 
						0.0f, -1.0f, 0.0f,
						
						0.0f, 0.0f, 1.0f, 
						0.0f, 0.0f, -1.0f, 
						0.0f, 1.0f, 0.0f, 
						0.0f, -1.0f, 0.0f,
											};

	/** The initial texture coordinates (u, v) */	
	private float texture[] = {
						//Mapping coordinates for the vertices
						0.0f, 0.0f, 
						0.0f, 2.0f, 
						2.0f, 0.0f, 
						2.0f, 2.0f,
			
						0.0f, 0.0f, 
						0.0f, 2.0f, 
						2.0f, 0.0f, 
						2.0f, 2.0f,
			
						0.0f, 0.0f, 
						0.0f, 2.0f, 
						2.0f, 0.0f, 
						2.0f, 2.0f,
			
						0.0f, 0.0f, 
						0.0f, 2.0f, 
						2.0f, 0.0f, 
						2.0f, 2.0f,
			
						0.0f, 0.0f, 
						0.0f, 2.0f, 
						2.0f, 0.0f, 
						2.0f, 2.0f,
			
						0.0f, 0.0f, 
						0.0f, 2.0f, 
						2.0f, 0.0f, 
						2.0f, 2.0f,
									};
	
	private float textureImposters[] = {
			//Mapping coordinates for the vertices
			0.0f, 0.0f, 
			0.0f, 2.0f, 
			2.0f, 0.0f, 
			2.0f, 2.0f,

			0.0f, 0.0f, 
			0.0f, 2.0f, 
			2.0f, 0.0f, 
			2.0f, 2.0f,

			0.0f, 0.0f, 
			0.0f, 2.0f, 
			2.0f, 0.0f, 
			2.0f, 2.0f,

			0.0f, 0.0f, 
			0.0f, 2.0f, 
			2.0f, 0.0f, 
			2.0f, 2.0f,

			0.0f, 0.0f, 
			0.0f, 2.0f, 
			2.0f, 0.0f, 
			2.0f, 2.0f,

			0.0f, 0.0f, 
			0.0f, 2.0f, 
			2.0f, 0.0f, 
			2.0f, 2.0f,
						};

	/** The initial indices definition */
	private byte indices[] = {
						// Faces definition
						0, 1, 3, 0, 3, 2, 		// Face front
						4, 5, 7, 4, 7, 6, 		// Face right
						8, 9, 11, 8, 11, 10, 	// ...
						12, 13, 15, 12, 15, 14, 
						16, 17, 19, 16, 19, 18, 
						20, 21, 23, 20, 23, 22, 
												};
	
	
	private byte indicesImposters[] = {
			// Faces definition
			3, 1, 0, 2, 3, 0, 		// Face front
			7, 5, 4, 6, 7, 4, 		// Face right
			11, 9, 8, 10, 11, 8, 	// ...
			15, 13, 12, 14, 15, 12, 
			19, 17, 16, 18, 19, 16, 
			23, 21, 20, 22, 23, 20, 
									};

	/**
	 * The Cube constructor.
	 * 
	 * Initiate the buffers.
	 * @param size 
	 */
	public PlayMap3D(float s) {
		this.size = s;
		
		initializeVertices();
		
		
		//
		ByteBuffer byteBuf = ByteBuffer.allocateDirect(vertices.length * 4);
		ByteBuffer byteBufImposters = ByteBuffer.allocateDirect(verticesImposter.length * 4);
		
		byteBuf.order(ByteOrder.nativeOrder());
		vertexBuffer = byteBuf.asFloatBuffer();
		vertexBuffer.put(vertices);
		vertexBuffer.position(0);
		byteBufImposters.order(ByteOrder.nativeOrder());
		vertexBufferImposters = byteBufImposters.asFloatBuffer();
		vertexBufferImposters.put(verticesImposter);
		vertexBufferImposters.position(0);

		//
		byteBuf = ByteBuffer.allocateDirect(texture.length * 4);
		byteBuf.order(ByteOrder.nativeOrder());
		textureBuffer = byteBuf.asFloatBuffer();
		textureBuffer.put(texture);
		textureBuffer.position(0);
		byteBuf = ByteBuffer.allocateDirect(texture.length * 4);
		byteBuf.order(ByteOrder.nativeOrder());
		textureBuffer = byteBuf.asFloatBuffer();
		textureBuffer.put(texture);
		textureBuffer.position(0);
		byteBufImposters = ByteBuffer.allocateDirect(textureImposters.length * 4);
		byteBufImposters.order(ByteOrder.nativeOrder());
		textureBufferImposters = byteBufImposters.asFloatBuffer();
		textureBufferImposters.put(textureImposters);
		textureBufferImposters.position(0);
		byteBufImposters = ByteBuffer.allocateDirect(textureImposters.length * 4);
		byteBufImposters.order(ByteOrder.nativeOrder());
		textureBufferImposters = byteBufImposters.asFloatBuffer();
		textureBufferImposters.put(textureImposters);
		textureBufferImposters.position(0);

		//
		byteBuf = ByteBuffer.allocateDirect(normals.length * 4);
		byteBuf.order(ByteOrder.nativeOrder());
		normalBuffer = byteBuf.asFloatBuffer();
		normalBuffer.put(normals);
		normalBuffer.position(0);

		indexBuffer = ByteBuffer.allocateDirect(indices.length);
		indexBuffer.put(indices);
		indexBuffer.position(0);
		indexBufferImposters = ByteBuffer.allocateDirect(indicesImposters.length);
		indexBufferImposters.put(indicesImposters);
		indexBufferImposters.position(0);
	}

	private void initializeVertices() {
		vertices = new float[]{
				// Vertices according to faces
				-size, -size, size, //Vertex 0
	    		size, -size, size,  //v1
	    		-size, size, size,  //v2
	    		size, size, size,   //v3
	    		
	    		size, -size, size,	//...
	    		size, -size, -size,    		
	    		size, size, size,
	    		size, size, -size,
	    		
	    		size, -size, -size,
	    		-size, -size, -size,    		
	    		size, size, -size,
	    		-size, size, -size,
	    		
	    		-size, -size, -size,
	    		-size, -size, size,    		
	    		-size, size, -size,
	    		-size, size, size,
	    		
	    		-size, -size, -size,
	    		size, -size, -size,    		
	    		-size, -size, size,
	    		size, -size, size,
	    		
	    		-size, size, size,
	    		size, size, size,    		
	    		-size, size, -size,
	    		size, size, -size,
									};
		
	}

	/**
	 * The object own drawing function.
	 * Called from the renderer to redraw this instance
	 * with possible changes in values.
	 * 
	 * @param gl - The GL Context
	 * @param filter - Which texture filter to be used
	 */
	public void draw(GL10 gl) {
		//Bind the texture according to the set texture filter
		gl.glBindTexture(GL10.GL_TEXTURE_2D, textures[0]);

		//Enable the vertex, texture and normal state
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glEnableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glEnableClientState(GL10.GL_NORMAL_ARRAY);

		
		
		//Set the face rotation
		gl.glFrontFace(GL10.GL_CCW);
		
	/*	//Point to our buffers
		gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
		gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, textureBuffer);
		gl.glNormalPointer(GL10.GL_FLOAT, 0, normalBuffer);

		//Draw the vertices as triangles, based on the Index Buffer information		
		gl.glBindTexture(GL10.GL_TEXTURE_2D, textures[1]);   //use texture of ith face
		indexBuffer.position(0);                          //select ith face
		gl.glDrawElements(GL10.GL_TRIANGLES, 36, GL10.GL_UNSIGNED_BYTE, indexBuffer); // Desenha topo
		
	*/	
		// IMPOSTERS **********************************************************
		//Point to our buffers
		gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBufferImposters);
		gl.glTexCoordPointer(2, GL10.GL_FLOAT, 0, textureBufferImposters);
		gl.glNormalPointer(GL10.GL_FLOAT, 0, normalBuffer);

		//Draw the vertices as triangles, based on the Index Buffer information		
		gl.glBindTexture(GL10.GL_TEXTURE_2D, textures[1]);   //use texture of ith face
		indexBufferImposters.position(0);                          //select ith face
		gl.glDrawElements(GL10.GL_TRIANGLES, 36, GL10.GL_UNSIGNED_BYTE, indexBufferImposters); // Desenha topo
		
		
		
		
		//Disable the client state before leaving
		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glDisableClientState(GL10.GL_TEXTURE_COORD_ARRAY);
		gl.glDisableClientState(GL10.GL_NORMAL_ARRAY);
		
		gl.glBindTexture(GL10.GL_TEXTURE_2D, 0); // Bind the default (empty) texture
	}

	/**
	 * Load the textures
	 * 
	 * @param gl - The GL Context
	 * @param context - The Activity context
	 */
	public void loadGLTexture(GL10 gl, Context context) {
		

		//Generate there texture pointer
		gl.glGenTextures(1, textures, 0);
		
		InputStream is = context.getResources().openRawResource(R.drawable.skyimposter3d);
		Bitmap bitmap = null;
		try {
			//BitmapFactory is an Android graphics utility for images
			bitmap = BitmapFactory.decodeStream(is);

		} finally {
			//Always clear and close
			try {
				is.close();
				is = null;
			} catch (IOException e) {
			}
		}
		//Create Nearest Filtered Texture and bind it to texture 0
		gl.glBindTexture(GL10.GL_TEXTURE_2D, textures[1]);
		gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_NEAREST);
		gl.glTexParameterf(GL10.GL_TEXTURE_2D, GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_NEAREST);
		GLUtils.texImage2D(GL10.GL_TEXTURE_2D, 0, bitmap, 0);
		
		
		
		//Clean up
		bitmap.recycle();
	}

}
