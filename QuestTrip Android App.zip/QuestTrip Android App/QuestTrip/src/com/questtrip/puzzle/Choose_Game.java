package com.questtrip.puzzle;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import com.questtrip.api.ApiQuestTrip;
import com.questtrip.api.responses.ChallengeResponse;
import com.questtrip.database.QuestDB;
import com.questtrip.database.SpotDB;
import com.questtrip.models.application.LoggedUser;
import com.questtrip.models.challenge.Challenge;
import com.questtrip.models.variables.Variables;
import com.questtrip.view.MainActivity;
import com.questtrip.view.R;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class Choose_Game extends Activity{

	Intent startGameIntent = null;

	private ImageButton normal_button = null;

	private int index = 0;
	private Challenge chg = null;
	private String image = null;
	private int size = 3;
	private Bitmap imageBitmap = null;
	private boolean puzzleComplete = false;

	private ProgressDialog progressDialog = null;

	// Options
	private Context mainContext = null;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.choose_game);
		//this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		mainContext = this;


		startGameIntent = new Intent(this, Start_Game.class);

		// Buttons  
		this.normal_button = (ImageButton) findViewById(R.id.normalbutton);


		// Triggers
		this.normal_button.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {

				startGameIntent.putExtra("image", imageBitmap);
				startGameIntent.putExtra("size", size);
				
				Toast.makeText(mainContext, "Launching Puzzle", Toast.LENGTH_LONG).show();
				startActivityForResult(startGameIntent, 1);
			}
		});

		this.progressDialog = ProgressDialog.show(this, "", "Retrieving Puzzle from Server", true, false);
		
		new unbundleInformation().execute();
	//	new DownloadQuestImage().execute(this.image);
	}
	
	/**
	 * AsyncTask to unbundle information received from another activity
	 */
	private class unbundleInformation extends AsyncTask<Void, Void, ChallengeResponse> {

		@Override
		protected ChallengeResponse doInBackground(Void... params) {
			return unbundleInformation();
		}


		@Override
		protected void onPostExecute(ChallengeResponse result) {
			super.onPostExecute(result);
			
			image = result.getChallenge().getImage();
			size = result.getChallenge().getSize();
			
			Log.d("URL IMAGEM", image);
			new DownloadQuestImage().execute(image);
		}

	}

	
	/**
	 * [CHECKED] Identify the activity that started the current activity and extracts the information sent
	 * @param info
	 */
	private ChallengeResponse unbundleInformation() {
		Bundle info = getIntent().getExtras();
		this.chg = (Challenge)info.getParcelable("chg");
		this.index = (int)info.getInt("index");
		
		return ApiQuestTrip.getChallenge(chg.getId());
	}
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == 1) {
			if(resultCode == RESULT_OK){
				puzzleComplete = true;
			}

			if (resultCode == RESULT_CANCELED) {
				//puzzleComplete = false;
			}
		}
	}
	
	public void getBackToQuest(){
		Intent returnIntent = new Intent();
		
		returnIntent.putExtra("score", 100);
		returnIntent.putExtra("index", index);
    	
    	if(puzzleComplete)
    		setResult(RESULT_OK, returnIntent);     
    	else
    		setResult(RESULT_CANCELED, returnIntent);    
    	
    	
    	finish();
	}
	
    public void onBackPressed() {
    	getBackToQuest();

        return;
    } 

	class DownloadQuestImage extends AsyncTask<String, Void, Integer> {

		protected Integer doInBackground(String... url) {
			try {
				loadImage(url[0]); // Download da imagem
			} catch (Exception e) {
				return null;
			}
			return 1;
		}

		// Save dos dados e preenchimento das estruturas
		protected void onPostExecute(Integer res) {
			if (progressDialog != null) {
				progressDialog.dismiss();
			}
		}
	}

	public void loadImage(String url){
		try {
			this.imageBitmap = drawableFromUrl(url);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	private Bitmap drawableFromUrl(String url) throws IOException {
		Bitmap x;

		HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
		connection.connect();
		InputStream input = connection.getInputStream();

		x = BitmapFactory.decodeStream(input);
		return x;
	}
}