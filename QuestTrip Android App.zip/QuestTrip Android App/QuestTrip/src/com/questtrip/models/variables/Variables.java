/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.models.variables;

/**
 * @author Filipe Rodrigues
 *
 */
public class Variables {
	
	public static final String API_URL = "https://questtrip.herokuapp.com/";
	
	public static final String CHALLENGE_VISIT = "Visit";
	public static final String CHALLENGE_QUIZ = "Quiz";
	public static final String CHALLENGE_PUZZLE = "Puzzle";

}
