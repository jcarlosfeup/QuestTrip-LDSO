package com.questtrip.models;

/**
 * * Class que cria uma "Box" em redor de determinado Spot, com um determinado "radius"
 * 
 * @author Filipe Rodrigues
 *
 */
public class BoundingBox {
	
	private int radius = 5;
	
	private GPSCoord minPoint = null, maxPoint = null;
    
   	public BoundingBox(final double pLatitude, final double pLongitude, final int pDistanceInMeters) { 

   		if(pDistanceInMeters != -1)
   			radius = pDistanceInMeters;
   		
   		
        final double latRadian = Math.toRadians(pLatitude); 

        final double degLatKm = 110.574235; 
        final double degLongKm = 110.572833 * Math.cos(latRadian); 
        final double deltaLat = radius / 1000.0 / degLatKm; 
        final double deltaLong = radius / 1000.0 / degLongKm; 

        final double minLat = pLatitude - deltaLat; 
        final double minLong = pLongitude - deltaLong;         
        final double maxLat = pLatitude + deltaLat; 
        final double maxLong = pLongitude + deltaLong; 
        
        
        minPoint = new GPSCoord(minLat, minLong);
        maxPoint = new GPSCoord(maxLat, maxLong);
    } 

   	
   	public GPSCoord minPoint(){return minPoint;}
   	public GPSCoord maxPoint(){return maxPoint;}
}
