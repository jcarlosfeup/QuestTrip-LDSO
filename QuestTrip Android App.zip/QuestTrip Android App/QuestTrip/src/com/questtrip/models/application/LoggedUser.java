/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.models.application;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import com.questtrip.models.variables.Variables;

import android.app.Application;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

/**
 * @author Filipe Rodrigues
 *
 */
public class LoggedUser extends Application{
	
	private static LoggedUser loggedUser = null;
	
	private String email = null;
	private String username = null, first_name = null, last_name = null;
	private String image = null;
	private String remember_token = null;
	private Drawable imageDrawable = null;
	
	private String password = null;
	
	@Override
	public void onCreate() {
		super.onCreate();
		
	//	loggedUser = this;
	}

	public void fillLoggedUser(String email, String username, String first_name, String last_name, String image, String remember_token){
		this.email = email;
		this.username = username;
		this.first_name = first_name;
		this.last_name = last_name;
		this.image = Variables.API_URL + image;
		this.remember_token = remember_token;
	}

	public static LoggedUser getLoggedUser() {
		return loggedUser;
	}

	public void loadImage(){
		try {
			this.imageDrawable = drawableFromUrl(image);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}

	/**
	 * @return
	 */
	public String getLogin() {
		return email;
	}


	/**
	 * @return
	 */
	public Drawable getImage() {
		return imageDrawable;
	}
	
	public String getUsername(){
		return username;
	}
	
	public String getName(){
		return first_name + " " + last_name;
	}
	
	public String getLoginToken(){
		return remember_token;
	}
	
	public void setPassword(String p){
		this.password = p;
	}

	@SuppressWarnings("deprecation")
	private Drawable drawableFromUrl(String url) throws IOException {
	    Bitmap x;

	    HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
	    connection.connect();
	    InputStream input = connection.getInputStream();

	    x = BitmapFactory.decodeStream(input);
	    return new BitmapDrawable(x);
	}

	/**
	 * @return
	 */
	public String getImageLink() {
		return image;
	}

	public String getPassword() {
		return password;
	}


	/**
	 * @param loggedUser
	 */
	public static void setLoggedUser(LoggedUser loggedUser) {
		LoggedUser.loggedUser = loggedUser;
	}
}

