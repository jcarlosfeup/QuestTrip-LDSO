package com.questtrip.models;

/**
 * Class utilizada para guardar as Coordenadas do GPS
 * 
 * @author Filipe Rodrigues
 *
 */
public class GPSCoord {
	
	private double lat = 0, longit = 0;
	
	public GPSCoord(double lat, double longit){
		this.lat = lat;
		this.longit = longit;
	}
	
	
	public double getLatitude(){return lat;}
	public double getLongitude(){return longit;}

}
