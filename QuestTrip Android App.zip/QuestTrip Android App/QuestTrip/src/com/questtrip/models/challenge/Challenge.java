package com.questtrip.models.challenge;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

import com.questtrip.models.variables.Variables;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;


/**
 * Challenge encontrado no Spot, pode ser apenas um Destino, uma Question ou *TODO* um Puzzle/Jogo 
 * 
 * @author Sub
 *
 */
public class Challenge implements Parcelable {
	private String spotName = "Challenge";
	private String id = null, challenge_type = null;
	private String type = null; // 0 - Destino	;	1 - Question	;	2 - Puzzle
	private String question = null;
	private String description = null;
	private Question_Option[] answers = null;
	private String puzzle_image = null;
	private int complete = 0;
	private int size = 3;
	
	private int maxScore = 100;
	
	public Challenge(String type){
		this.type = type;
	}
	public Challenge(String type, String id, String spot, String image){
		this.type = type;
		this.setId(id);
		this.spotName = spot;
		
		this.setImage(image);
	}
	private Challenge(Parcel source) {
		this.type = source.readString();
		this.setId(source.readString());
		this.question = source.readString();
		this.setDescription(source.readString());
	//	this.answers = new ArrayList<Question_Option>();
		
		 Object[] tempAnswers = source.readArray(Question_Option.class.getClassLoader());
		 
		 if(tempAnswers != null){
			 answers = new Question_Option[tempAnswers.length];
	         for (int i = 0; i < tempAnswers.length; i++) {
	        	 answers[i] = (Question_Option) tempAnswers[i];
	         }
		 }

		this.spotName = source.readString();
		this.complete = source.readInt();
		this.setImage(source.readString());
	}
	
	public int getMaxScore(){return maxScore;}
	
	// M�todo que devolve o valor a descontar no Max Score
	public int getPenalty(){return maxScore/answers.length;}
	
	public String getSpotName(){return spotName;}
	
	public String getChallengeType(){
		return type;
	}
	
	public void setQuestion(String q){
		this.question = q;
	}
	
	public void addOptions(Question_Option[] opt){
		this.answers = opt;
	}
	public void addOption(Question_Option opt){
	/*	if(this.answers == null)
			answers = new LinkedList<Question_Option>();
			
		answers.add(opt);
	*/}

	public Question_Option[] getOptions(){return this.answers;}
	public void setOptions(Question_Option[] answers){this.answers = answers;}
	
	/* (non-Javadoc)
	 * @see android.os.Parcelable#describeContents()
	 */
	@Override
	public int describeContents() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see android.os.Parcelable#writeToParcel(android.os.Parcel, int)
	 */
	@Override
	public void writeToParcel(Parcel dest, int flag) {
		dest.writeString(this.type);
		dest.writeString(this.getId());
		dest.writeString(this.question);
		dest.writeString(this.getDescription());
		dest.writeArray(this.answers);	
		dest.writeString(this.spotName);
		dest.writeInt(this.complete);
		dest.writeString(this.getImage());
	}
	
	/**
	 * Regenerate the object. All Parcelables must have a CREATOR that implements this two methods
	 */
	public static final Parcelable.Creator<Challenge> CREATOR = new Parcelable.Creator<Challenge>() {

		@Override
		public Challenge createFromParcel(Parcel source) {
			return new Challenge(source);
		}

		@Override
		public Challenge[] newArray(int size) {
			return new Challenge[size];
		}
		
	};
	
	public String getQuestion(){return question;}
	public boolean isComplete(){if(this.complete == 1) return true; else return false;}
	public void setComplete(boolean b){if(b) this.complete = 1; else this.complete = 0;}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getImage() {
		return Variables.API_URL + puzzle_image;
	}
	public void setImage(String image) {
		this.puzzle_image = image;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	
}
