package com.questtrip.models.challenge;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Op��o utilizada quando o Challenge se trata de uma Question
 * 
 * @author Filipe Rodrigues
 *
 */
public class Question_Option implements Parcelable {
	String id = null;
	boolean is_correct = false; // Flag de verifica��o da op��o
	String option = null;
	
	public Question_Option(boolean v, String q){
		this.is_correct = v;
		this.option = q;
	}
	
	private Question_Option(Parcel source) {
		byte convBool = source.readByte();
		if (convBool == 1) {
			this.is_correct = true;
		} else {
			this.is_correct = false;
		}
	
		this.option = source.readString();
		this.id = source.readString();
	}

	/* (non-Javadoc)
	 * @see android.os.Parcelable#describeContents()
	 */
	@Override
	public int describeContents() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see android.os.Parcelable#writeToParcel(android.os.Parcel, int)
	 */
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		
		byte convBool = -1; // Para converter boolean
		if (this.is_correct) {
		    convBool = 1;
		} else {
		    convBool = 0;
		}
		
		dest.writeByte(convBool);
		dest.writeString(this.option);
		dest.writeString(this.id);
	}

	/**
	 * Regenerate the object. All Parcelables must have a CREATOR that implements this two methods
	 */
	public static final Parcelable.Creator<Question_Option> CREATOR = new Parcelable.Creator<Question_Option>() {

		@Override
		public Question_Option createFromParcel(Parcel source) {
			return new Question_Option(source);
		}

		@Override
		public Question_Option[] newArray(int size) {
			return new Question_Option[size];
		}
		
	};
	
	public String getOptionText(){return option;}
	public boolean isValid(){return is_correct;}
	
}
