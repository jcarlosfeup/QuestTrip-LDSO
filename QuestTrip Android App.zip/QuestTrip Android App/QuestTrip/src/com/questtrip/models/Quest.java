/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.models;

/**
 * @author Filipe Rodrigues
 *
 */
public class Quest {
	private String id = null;
	private String name = null;
	private String category = null;
	private float rating = 0;
	private boolean is_linear = false;

	
	
	public Quest(String category, String id, String name, int rating, boolean is_linear){
		this.setCategory(category);
		this.id = id;
		this.name = name;
		this.setRating(rating);
		this.setLinear(is_linear);
	}
	
	
	/**
	 * Construtor utilizado na visualiza��o da ListView customizada
	 * @param n
	 */
	public Quest(String n){
		this.name = n;
	}
	
	public String getName(){
		return this.name;
	}

	public String getID() {
		return id;
	}


	public void setID(String id) {
		this.id = id;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public float getRating() {
		return rating;
	}


	public void setRating(int rating) {
		this.rating = rating;
	}


	public boolean isLinear() {
		return is_linear;
	}


	public void setLinear(boolean is_linear) {
		this.is_linear = is_linear;
	}
	
}
