package com.questtrip.models;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.OverlayItem;
import com.questtrip.models.challenge.Challenge;

/**
 * Class que representa um Spot
 * 
 * @author Filipe Rodrigues
 *
 */
public class Spot extends OverlayItem{
	
	BoundingBox boundingBox = null; // Box com determinado raio � volta de Spot
	private String latitude = null, longitude = null, id = null, description = null, image = null;
	private String name = null;
	private String challenge_id = null;
	private String challenge_type = null;
	private int radius = -1;
	private Challenge chg = null;
	private boolean stayingOnSpot = false;
	private int sequenceOrder = 0;
	
	public Spot(GeoPoint point, String title, String content) {
		super(point, title, content);
		
		boundingBox = new BoundingBox(point.getLatitudeE6()/1E6, point.getLongitudeE6()/1E6, -1);
	}
	
	public Spot(GeoPoint point, String title, String content, int radius) {
		super(point, title, content);
		
		boundingBox = new BoundingBox(point.getLatitudeE6()/1E6, point.getLongitudeE6()/1E6, radius);
	}
	
	public void setBoundingBox(){
		boundingBox = new BoundingBox(Double.parseDouble(latitude), Double.parseDouble(longitude), -1);
	}
	
	public void addChallenge(Challenge c){this.chg = c;}
	public Challenge getChallenge(){return chg;}
	public BoundingBox getBoundingBox(){return boundingBox;}
	public double getLatitude(){return Double.parseDouble(latitude);}
	public double getLongitude(){return Double.parseDouble(longitude);}
	
	public boolean hasChallenge(){if(chg == null) return false; else return true;}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int getTypeInt(){
		if(getChallenge_type().equals("Visit"))
			return 0;
		else if(getChallenge_type().equals("Quiz"))
			return 1;
		else return 2;
	}

	public String getChallenge_type() {
		return challenge_type;
	}

	public void setChallenge_type(String challenge_type) {
		this.challenge_type = challenge_type;
	}

	public String getChallengeID() {
		return challenge_id;
	}

	public void setChallengeID(String challenge_id) {
		this.challenge_id = challenge_id;
	}
	
	public String getSpotID(){
		return this.id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	public boolean isStayingOnSpot(){return stayingOnSpot;}
	
	public void setStayingOnSpot(boolean b){stayingOnSpot = b;}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
}
