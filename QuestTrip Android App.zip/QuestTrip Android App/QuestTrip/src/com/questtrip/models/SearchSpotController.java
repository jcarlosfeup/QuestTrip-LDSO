/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.models;

import java.util.ArrayList;
import java.util.List;

import android.app.Application;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

/**
 * @author Filipe Rodrigues
 *
 */
public class SearchSpotController extends ItemizedOverlay<OverlayItem>{
	
	private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
    private Handler handler;


	public SearchSpotController(Drawable defaultMarker, Handler h) {
	    super(boundCenterBottom(defaultMarker));

	    this.handler = h;
	}
	
	@Override
    public boolean onTap(GeoPoint p, MapView map) {
 
        List<Overlay> overlays = map.getOverlays();
 
        // Creating a Message object to send to Handler
        Message message = new Message();
 
        // Creating a Bundle object ot set in Message object
        Bundle data = new Bundle();
 
        // Setting latitude in Bundle object
        data.putInt("latitude", p.getLatitudeE6());
 
        // Setting longitude in the Bundle object
        data.putInt("longitude", p.getLongitudeE6());
 
        // Setting the Bundle object in the Message object
        message.setData(data);
 
        // Sending Message object to handler
        handler.sendMessage(message);
 
        return super.onTap(p, map);
    }
	
	// Executed, when populate() method is called
    @Override
    protected OverlayItem createItem(int arg0) {
        return mOverlays.get(arg0);
    }
 
    @Override
    public int size() {
        return mOverlays.size();
    }
 
    public void addOverlay(OverlayItem overlay){
        mOverlays.add(overlay);
        populate(); // Invokes the method createItem()
    }
}
