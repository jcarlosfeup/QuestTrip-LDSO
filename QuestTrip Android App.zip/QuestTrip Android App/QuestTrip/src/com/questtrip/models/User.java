/**
 * 
 * @author Filipe Rodrigues
 */
package com.questtrip.models;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.app.Application;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;

/**
 * @author Filipe Rodrigues
 *
 */
public class User {

	private String email = null;
	private String username = null, first_name = null, last_name = null;
	private String image = null;
	private String remember_token = null;
	private String password = null;

	/**
	 * @return
	 */
	public String getLogin() {
		return email;
	}



	public String getUsername(){
		return username;
	}
	
	public String getName(){
		return first_name + " " + last_name;
	}
	public String getFirstName(){
		return first_name;
	}
	
	public String getLastName(){
		return last_name;
	}
	
	public String getLoginToken(){
		return remember_token;
	}
	
	public void setPassword(String p){
		this.password = p;
	}

	/**
	 * @return
	 */
	public String getImageLink() {
		return image;
	}

	public String getPassword() {
		return password;
	}

}
